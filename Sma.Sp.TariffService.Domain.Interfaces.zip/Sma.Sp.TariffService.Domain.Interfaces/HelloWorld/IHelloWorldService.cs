// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IMyMicroserviceService.cs" company="SMA Solar Technology AG, 34266 Niestetal, Germany">
//   Copyright (c) SMA Solar Technology AG, 34266 Niestetal, Germany.  All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System.Threading.Tasks;
using Sma.Sp.TariffService.Domain.Entities.HelloWorld;

namespace Sma.Sp.TariffService.Domain.Interfaces.HelloWorld
{
    /// <summary></summary>
    public interface IHelloWorldService
    {
        /// <summary>
        /// Finds the editable plants of user.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        Task<FindPlantsResponse> FindEditablePlantsOfUser(FindPlantRequest request);

        /// <summary>
        /// Creates the world.
        /// </summary>
        /// <param name="worldsName">Name of the worlds.</param>
        /// <param name="plantId">The plant identifier.</param>
        /// <returns></returns>
        Task<long> CreateWorld(string worldsName, long plantId);

        /// <summary>
        /// Gets the world.
        /// </summary>
        /// <param name="worldsId">The worlds identifier.</param>
        /// <returns></returns>
        Task<World> GetWorld(long worldsId);

        /// <summary>
        /// Deletes the world.
        /// </summary>
        /// <param name="worldsId">The worlds identifier.</param>
        /// <returns></returns>
        Task DeleteWorld(long worldsId);
    }
}
