// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IAssetRepo.cs" company="SMA Solar Technology AG, 34266 Niestetal, Germany">
//   Copyright (c) SMA Solar Technology AG, 34266 Niestetal, Germany.  All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System.Collections.Generic;
using System.Threading.Tasks;
using Sma.Sp.TariffService.Domain.Entities.HelloWorld;

namespace Sma.Sp.TariffService.Domain.Interfaces.HelloWorld
{
    /// <summary>Provides the asset repo interface.</summary>
    public interface IAssetRepo
    {
        /// <summary>
        /// Gets plant names, filtered by "searchText"
        /// </summary>
        /// <param name="plantIds">The plant ids.</param>
        /// <param name="searchText">The search text.</param>
        /// <returns>
        /// A plant by its given id.
        /// </returns>
        Task<IEnumerable<Plant>> GetPlants(IEnumerable<long> plantIds, string searchText);
    }
}
