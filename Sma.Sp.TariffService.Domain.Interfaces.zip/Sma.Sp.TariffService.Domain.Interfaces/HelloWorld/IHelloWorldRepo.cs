﻿using System.Threading.Tasks;
using Sma.Sp.TariffService.Domain.Entities.HelloWorld;

namespace Sma.Sp.TariffService.Domain.Interfaces.HelloWorld
{
    public interface IHelloWorldRepo
    {
        Task<World> GetWorld(long worldId);
        Task<World> InsertWorld(string worldName, long plantId);
        Task DeleteWorld(long worldId);
    }
}
