﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Sma.Sp.Common;

namespace Sma.Sp.TariffService.Domain.Interfaces.HelloWorld
{
    public interface IAuthorizationRepo
    {
        /// <summary>
        /// Gets the explicitly assigned plants of user.
        /// Plants which are assigned to user directly.
        /// Plants which are assigned to user indirectly by plant group.
        /// Plants which belong to user.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns></returns>
        Task<IEnumerable<long>> GetExplicitlyAssignedPlantsOfUser(long userId);
        /// <summary>
        /// returns passed plantIds reduced by that plants to which the user lacks the required rights.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="plantIds">The plant ids.</param>
        /// <param name="requiredApiPrivileges">The required API privileges.</param>
        /// <returns></returns>
        Task<IEnumerable<long>> FilterPlantsByPrivileges(long userId, IEnumerable<long> plantIds, IEnumerable<ApiPrivileges> requiredApiPrivileges);
    }
}
