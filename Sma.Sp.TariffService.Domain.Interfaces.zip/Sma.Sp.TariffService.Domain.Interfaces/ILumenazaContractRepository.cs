using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Sma.Sp.TariffService.Domain.Entities.Dtos;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.PriceObject;

namespace Sma.Sp.TariffService.Domain.Interfaces
{  //its an interface for ILumenazaContractRepository where all methods and variable are defined which should be implemented after implementing
   //interface the methods and functions are of type HttpResponseMessage ,task and etc..
    public interface ILumenazaContractRepository
    {
        Task<object> GetPrice(PriceRequest priceRequest);
        Task<object> GetPriceCo2Avoidance(PriceCo2Request priceCo2Request);
        Task<object> GetProvider();
        HttpResponseMessage ParsingApiReturnCodes(ContractObjectDto contractObjDto, bool IsSuccessStatusCode );
        HttpResponseMessage ParsingApiReturnCodes(bool IsSuccessStatusCode, HttpStatusCode status);
    }
}