using System;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using SMA.Logging;
using Sma.Sp.AuthenticationService.Api.Interfaces.UserAuths.Models;
using Sma.Sp.Libraries.WebApiBaseClient.Common.Resource;
using Sma.Sp.AuthenticationService.Api.Interfaces.UserTokens.Model;
using Sma.Sp.MailManagement.Api.Interfaces.Mail.Models;
using Sma.Sp.AuthenticationService.Api.Interfaces.UserAuths;

namespace Sma.Sp.TariffService.Infrastructure.SunnyPortal
{  //this is the main service to Authenticate users getting tokens , validations for users by reading configuration ;its having paramitrized construtor from 
   // which it reads all other configuration and also implemeting methods from interface .
    public class SmaAuthenticationService : ISmaAuthenticationService
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private readonly string _baseUrl;
        private readonly string _mailUrl;
        private readonly IUserAuthResource _userAuthResource;
        private UserAuthResource userAuthResource;

        public SmaAuthenticationService(IConfiguration configuration , IUserAuthResource userAuthResource)
        {
            _configuration = configuration;
            _httpClient = new HttpClient();
             _userAuthResource = userAuthResource;
            _baseUrl = _configuration["InfrastructureConfiguration:SMAUserAuthResourceEndPoint"];
            _mailUrl = _configuration["InfrastructureConfiguration:SMAEmailResourceEndPoint"];
        }
        
        public async Task<long> Create(CreateUserRequest userRequest)
        {
            try
            {
               
                   userAuthResource= new AuthenticationService.Api.Interfaces.UserAuths.UserAuthResource(_httpClient, _baseUrl,
                        ClientContentType.Json);
                
                var createdId = await userAuthResource.Create(userRequest);
                this.Log().Log(LogLevel.Info, new
                {
                    createdUserId = createdId
                });
                
                return createdId;
            }
            catch (Exception ex)
            {   
                throw;
            }
        }

        public async Task<UserCredentialsResponse> GetUserById(long userId)
        {
            try
            {
                userAuthResource=
                    new AuthenticationService.Api.Interfaces.UserAuths.UserAuthResource(_httpClient, _baseUrl,
                        ClientContentType.Json);

                var userCredentialsResponse = await userAuthResource.GetUserById(userId);

                return userCredentialsResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<UserTokenResponse> GetActivationTokenById(long userId)
        {
            try
            {
                var tokenResource =
                    new AuthenticationService.Api.Interfaces.UserTokens.UserTokenResource(_httpClient, _baseUrl, ClientContentType.Json);
                UserTokenResponse tokenResponse = await tokenResource.Get(Purpose.Activation, userId);

                return tokenResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<Boolean> SendActivationMail(UserActivationEmailRequest emailRequest)
        {
            try
            {
                var mailResource =
                    new MailManagement.Api.Interfaces.Mail.MailResource(_httpClient, _mailUrl, ClientContentType.Json);
                await mailResource.SendUserActivationMail(emailRequest);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }

}

