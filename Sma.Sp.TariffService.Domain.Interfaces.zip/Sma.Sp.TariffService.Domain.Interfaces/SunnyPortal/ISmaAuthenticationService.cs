using System;
using System.Threading.Tasks;
using Sma.Sp.AuthenticationService.Api.Interfaces.UserAuths.Models;
using Sma.Sp.AuthenticationService.Api.Interfaces.UserTokens.Model;
using Sma.Sp.MailManagement.Api.Interfaces.Mail.Models;

namespace Sma.Sp.TariffService.Infrastructure.SunnyPortal
{ // Interface ISmaAuthenticationService is having function   declare which are used for authentication, activation and are of type TASk which is Sync or Async.
    public interface ISmaAuthenticationService
    {
        Task<long> Create(CreateUserRequest userRequest);
        Task<UserCredentialsResponse> GetUserById(long userId);
        Task<UserTokenResponse> GetActivationTokenById(long userId);
        Task<Boolean> SendActivationMail(UserActivationEmailRequest activationEmailRequest);

    }
}