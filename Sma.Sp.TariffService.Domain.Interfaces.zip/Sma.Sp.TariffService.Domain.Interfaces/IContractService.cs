using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Sma.Sp.TariffService.Api.Interfaces.Mobile;
using Sma.Sp.TariffService.Api.Interfaces.Tariff;
using Sma.Sp.TariffService.Domain.Entities;
using Sma.Sp.TariffService.Domain.Entities.Dtos;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.ConsumersObject;

namespace Sma.Sp.TariffService.Domain.Interfaces
{
	public interface IContractService
    { //its an interface for IContractService where all methods and variable are defined which should be implemented after implementing
      //interface the methods and functions are of type bool,list ,task and etc..
        /// <summary>
        /// Create a new contract to Lumenaza service
        /// </summary>
        /// <param name="requestConsumers"></param>
        /// <returns></returns>
        Task<ResponseConsumersObject> CreateNewContract(int contractMasterId, LumenazaConsumersRequestObject requestConsumers);
        Task<ContractObjectDto> GetConsumerContracts(string externalUserId);
        Task<ContractDetails> GetConsumerContractById(string externalUserId, string contractId);
        Task<ProductDetails> GetConsumerContractProducts(string externalUserId, string contractId);
        Task<bool> IsDatabaseOnlineAsync();
        int CreateNewContractLocally(CreateContractRequest request);
        Task CheckIncompleteContracts();
        ContractMasterData GetUser(int id);
        ContractMasterData GetUser(string email);
        List<PreliminaryContractModel> GetNeedReSentContract(DateTime? contractAge);
        bool IsValid(string meterId, string lastName,
            string street, string city, string house, string zipcode);

        //Move domain logic to service
        Task<ContractObjectDto> GetUserByIDLogic(int userId);
        Task<ResponseConsumersObject> CreateContractLogic(int contractMasterId, RequestCreateContractObject requestCreateContractObject);
        Task<HttpResponseMessage> CreateUnverifiedContractLogic(RequestUnverifiedSavingsObject request);
    }
}