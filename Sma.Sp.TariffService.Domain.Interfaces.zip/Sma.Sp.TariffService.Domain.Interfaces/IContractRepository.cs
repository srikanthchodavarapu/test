using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Sma.Sp.TariffService.Domain.Entities;

namespace Sma.Sp.TariffService.Domain.Interfaces
{//its an interface for IContractRepository where all methods and variable are defined which should be implemented after implementing
    //interface the methods and functions are of type bool,list ,task and etc..
    public interface IContractRepository
    {
        Task<bool> IsCanConnect();
        int Create(CreateContractRequest request);
        void RemoveBankInformation(int masterId);
        void UpdateStatus(int masterId, string status);
        void UpdateInternalUserId(int masterId, string userId);
        void UpdateExternalData(int masterId, string externalUserId, string externalContractId);

        List<PreliminaryContractModel> GetNeedReSentContract(DateTime? contractAge);
        ContractMasterData GetContractMasterData(int userId); 
        ContractMasterData GetByEmail(string email);
        List<ContractMasterData> GetIncompleteUsers();
        List<ContractMasterData> GetByUserId(string userId);

        bool IsValid(string meterId, string lastName,
            string street, string city, string house, string zipcode);
    }
}