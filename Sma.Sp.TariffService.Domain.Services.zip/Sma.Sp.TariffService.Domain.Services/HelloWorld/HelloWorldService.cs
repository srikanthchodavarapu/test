// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MyMicroserviceService.cs" company="SMA Solar Technology AG, 34266 Niestetal, Germany">
//   Copyright (c) SMA Solar Technology AG, 34266 Niestetal, Germany.  All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System.Linq;
using System.Threading.Tasks;
using Sma.Sp.Common;
using Sma.Sp.TariffService.Domain.Entities.HelloWorld;
using Sma.Sp.TariffService.Domain.Interfaces.HelloWorld;

namespace Sma.Sp.TariffService.Domain.Services.HelloWorld
{
    /// <summary></summary>
    public class HelloWorldService : IHelloWorldService
    {
        private readonly IAssetRepo _assetRepo;
        private readonly IAuthorizationRepo _authorizationRepo;
        private readonly IHelloWorldRepo _helloWorldRepo;

        /// <summary>
        /// Initializes a new instance of the <see cref="HelloWorldService"/> class.
        /// </summary>
        /// <param name="assetRepo">The asset repo.</param>
        /// <param name="authorizationRepo">The authorization repo.</param>
        /// <param name="helloWorldRepo"></param>
        public HelloWorldService(
            IAssetRepo assetRepo,
            IAuthorizationRepo authorizationRepo,
            IHelloWorldRepo helloWorldRepo)
        {
            _assetRepo = assetRepo;
            _authorizationRepo = authorizationRepo;
            _helloWorldRepo = helloWorldRepo;
        }

        /// <summary>
        /// Finds the editable plants of user.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        public async Task<FindPlantsResponse> FindEditablePlantsOfUser(FindPlantRequest request)
        {
            var plantIds = (await _authorizationRepo.GetExplicitlyAssignedPlantsOfUser(request.UserId).ConfigureAwait(false)).ToList();
            plantIds = (await _authorizationRepo
                        .FilterPlantsByPrivileges(userId: request.UserId, 
                                                  plantIds: plantIds, 
                                                  requiredApiPrivileges: new[] {ApiPrivileges.Api_Put_Plant})
                        .ConfigureAwait(false)).ToList();

            var plants = (await _assetRepo.GetPlants(plantIds, request.PlantNameQuery).ConfigureAwait(false))
                        .Select(x =>new Plant(x.PlantId, x.PlantName));

            return new FindPlantsResponse(plants);
        }

        /// <summary>
        /// Creates the world.
        /// </summary>
        /// <param name="worldsName">Name of the worlds.</param>
        /// <param name="plantId">The plant identifier.</param>
        /// <returns></returns>
        public async Task<long> CreateWorld(string worldsName, long plantId)
        {
            
            return (await _helloWorldRepo.InsertWorld(worldName: worldsName, plantId: plantId).ConfigureAwait(false)).WorldId;
        }

        /// <summary>
        /// Gets the world.
        /// </summary>
        /// <param name="worldsId">The worlds identifier.</param>
        /// <returns></returns>
        public async Task<World> GetWorld(long worldsId)
        {
            return await _helloWorldRepo.GetWorld(worldsId).ConfigureAwait(false);
        }

        /// <summary>
        /// Deletes the world.
        /// </summary>
        /// <param name="worldsId">The worlds identifier.</param>
        /// <returns></returns>
        public async Task DeleteWorld(long worldsId)
        {
            await _helloWorldRepo.DeleteWorld(worldsId);
        }
    }
}

