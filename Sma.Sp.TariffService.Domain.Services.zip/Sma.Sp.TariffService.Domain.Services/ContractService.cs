using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.ConsumersObject;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.TokenObject;
using Sma.Sp.TariffService.Domain.Interfaces;
using Microsoft.Extensions.Options;
using Sma.Sp.AuthenticationService.Api.Interfaces.UserAuths;
using Sma.Sp.TariffService.Domain.Entities;
using Sma.Sp.TariffService.Api.Interfaces.Tariff;
using Sma.Sp.AuthenticationService.Api.Interfaces.UserAuths.Models;
using Sma.Sp.TariffService.Infrastructure.SunnyPortal;
using SMA.Logging;
using Sma.Sp.MailManagement.Api.Interfaces.Mail.Models;
using Sma.Sp.TariffService.Web.Service.Models.Mapping;
using Sma.Sp.TariffService.Api.Interfaces;
using Newtonsoft.Json.Linq;
using System.Linq;
using Sma.Sp.TariffService.Domain.Entities.Utilities;
using Newtonsoft.Json;
using System.Text;
using System.Net.Http.Formatting;
using Sma.Sp.TariffService.Api.Interfaces.Mobile;
using Sma.Sp.TariffService.Domain.Entities.Dtos;

namespace Sma.Sp.TariffService.Domain.Services
{
	/*its an main service  in which all crud operations like Update,delete,Get are used to work on crud functionality
	 * authentication is also done here constructor contains all parametrs for configuration and authentication 
	 IContractService has also been implemented here to override the methods .This is the main service to get all contract details
	by ID, and by other parameters*/
	public class ContractService : IContractService
	{
		private ISmaAuthenticationService _smaAuthenticationService;
		private ICreateContractRequestMapper _createContractRequestMapper;
		private IConsumerObjectMapper _consumerObjectMapper;
		private readonly IContractRepository _contractRepository;
		private readonly IUserAuthResource _userAuthResource;
		private readonly ILumenazaContractRepository _lumenazaContractRepository;
		private IConfiguration _configuration;
		private HttpClient _httpClient;
		private TokenObject _accessToken;
		private ConfigSettings configSettings;

		/// <summary>
		/// 
		/// </summary>
		/// <param name="contractRepository"></param>
		/// <param name="userAuthResource"></param>
		/// <param name="configuration"></param>
		/// <param name="lumenazaLogintestService"></param>

		public ContractService(ISmaAuthenticationService smaAuthenticationService, ICreateContractRequestMapper createContractRequestMapper, IConsumerObjectMapper consumerObjectMapper, IContractRepository contractRepository, IUserAuthResource userAuthResource, ILumenazaContractRepository lumenazaContractRepository, IConfiguration configuration, IOptions<ConfigSettings> options)
		{
			_smaAuthenticationService = smaAuthenticationService;
			_createContractRequestMapper = createContractRequestMapper;
			_consumerObjectMapper = consumerObjectMapper;
			_contractRepository = contractRepository;
			_userAuthResource = userAuthResource;
			_lumenazaContractRepository = lumenazaContractRepository;
			_configuration = configuration;
			configSettings = options.Value;
			// Proxy configuration
			var httpHandler = new HttpClientHandler();
			if (Convert.ToBoolean(_configuration["InfrastructureConfiguration:WebProxy:Enable"]))
			{
				httpHandler.UseProxy = true;
				httpHandler.Proxy = new WebProxy(
					_configuration["InfrastructureConfiguration:WebProxy:Host"],
					Convert.ToInt32(_configuration["InfrastructureConfiguration:WebProxy:Port"]));
			}

			_httpClient = new HttpClient(httpHandler);
			Task.Run(this.Authenticate).Wait();
		}

		public async Task<bool> IsDatabaseOnlineAsync()
		{
			try
			{
				// TODO: JW: Minor: Prefer either 'IsConnectionPossible' or 'CanConnect' (see https://docs.microsoft.com/en-us/dotnet/standard/design-guidelines/names-of-type-members)
				// TODO: JW: Minor: This call doesn't really add value. That a database is involved, is subject of the repository. Let your repository throw a SQL Exception if it's impossible to open the database, the exception middleware will translate that into a 500 (Internal server error) - same result as it will currently have, but much easier code and hidden dependencies.
				return await _contractRepository.IsCanConnect();
			}
			catch (Exception exception)
			{
				throw exception;
			}
		}
		public int CreateNewContractLocally(CreateContractRequest request)
		{
			return _contractRepository.Create(request);
		}
		private void UpdateInternalUserId(int masterId, string userId)
        {
			_contractRepository.UpdateInternalUserId(masterId, userId);
        }
		private void UpdateExternalData(int masterId, string externalUserId, string externalContractId)
		{
			_contractRepository.UpdateExternalData(masterId, externalUserId, externalContractId);
		}
		private void UpdateStatus(int masterId, string status)
		{
			_contractRepository.UpdateStatus(masterId, status);
		}
		private void RemoveBankInfo(int masterId)
		{
			_contractRepository.RemoveBankInformation(masterId);
		}
		public ContractMasterData GetUser(int id)
		{
			return _contractRepository.GetContractMasterData(id);
		}
		public ContractMasterData GetUser(string email)
		{
			return _contractRepository.GetByEmail(email);
		}
		public List<PreliminaryContractModel> GetNeedReSentContract(DateTime? contractAge)
		{
			return _contractRepository.GetNeedReSentContract(contractAge);
		}
		public bool IsValid(string meterId, string lastName, string street, string city, string house,
			string zipcode)
		{
			return _contractRepository.IsValid(meterId, lastName, street, city, house, zipcode);
		}
		public async Task<ResponseConsumersObject> CreateNewContract(int contractMasterId, LumenazaConsumersRequestObject requestConsumers)
		{
			var data = GetUser(requestConsumers.email);
			var path = GetPathByCreateOrAdd(data?.UserId);
			var requestContent = Extension.ConvertToFormContentUrlEncoded(requestConsumers);

			var responseMessage = new HttpResponseMessage();

			try
			{
				responseMessage = await _httpClient.PostAsJsonAsync(path, requestConsumers);
				
				var responseConsumer = new ResponseConsumersObject();

				if (responseMessage.IsSuccessStatusCode)
                {
					var responseObj = await responseMessage.Content.ReadAsAsync<object>();
					var json = JObject.Parse(responseObj.ToString());

					var externalUserId = json.SelectToken("consumer_id").Value<string>();
					var externalContractId = json.SelectToken("contract_id").Value<string>();

					this.Log().Log(LogLevel.Info, new
					{
						userId = externalUserId,
						contractId = externalContractId
					});

					UpdateExternalData(contractMasterId, externalUserId, externalContractId);
					UpdateStatus(contractMasterId, ContractMasterDataStatus.Complete);
					RemoveBankInfo(contractMasterId);

					responseConsumer.ConsumerId = externalUserId;
					responseConsumer.ContractId = json.SelectToken("contract_id").Value<string>();

					return responseConsumer;
				}
				else
				{
					// If response is bad request
					if (responseMessage.StatusCode == HttpStatusCode.BadRequest)
					{
						var badRequestResponse = await responseMessage.Content.ReadAsStringAsync();

						this.Log().Log(LogLevel.Warning,
							new
							{
								errorType = "LumenazaApiCallFailed",
								statusCode = responseMessage.StatusCode,
								content = badRequestResponse
							});

						UpdateStatus(contractMasterId, ContractMasterDataStatus.Cancelled);
						RemoveBankInfo(contractMasterId);

						var returnObject = JsonConvert.DeserializeObject(badRequestResponse);
						return responseConsumer;
					}

					var errorResponse = await responseMessage.Content.ReadAsStringAsync();

					this.Log().Log(LogLevel.Warning,
						new
						{
							errorType = "LumenazaApiCallFailed",
							statusCode = responseMessage.StatusCode,
							content = errorResponse
						});

					UpdateStatus(contractMasterId, ContractMasterDataStatus.InComplete);

					return responseConsumer;
				}
			}
			catch (Exception exception)
			{
				throw exception;
			}
		}
		public async Task<ContractObjectDto> GetConsumerContracts(string externalUserId)
		{
			var contractObjDto = new ContractObjectDto();
			contractObjDto.contractObject = new Dictionary<string, Dictionary<string, object>[]>();
			var response = await _httpClient.GetAsync("v3/consumers/" + externalUserId + "/contracts/");
			var responseObj = await response.Content.ReadAsAsync<object>();
			if (response.IsSuccessStatusCode)
			{
				var jsonObject = JObject.Parse(responseObj.ToString());
				if (!jsonObject.HasValues)
				{
					_lumenazaContractRepository.ParsingApiReturnCodes(contractObjDto, response.IsSuccessStatusCode);
					return contractObjDto;
				}

				foreach (var child in jsonObject.Children<JProperty>())
				{
					if (child.Name.ToString() == "contract_ids")
					{
						JArray contracIdArray = JArray.Parse(child.Value.ToString());
						List<Dictionary<string, object>> listofContractDetails = new List<Dictionary<string, object>> { };
						foreach (var contractId in contracIdArray)
						{
							var contractDictionary = new Dictionary<string, object>();

							contractDictionary.Add("contractId", contractId);

							// make an individual call to collect data for contract
							var productDetails =
								await GetConsumerContractProducts(externalUserId,
									contractId.ToString());

							contractDictionary.Add("productDetails", Helper.RenameKeysToCamelCase(JObject.Parse(JsonConvert.SerializeObject(productDetails))));

							var contractDetails =
						 		await GetConsumerContractById(externalUserId,
									contractId.ToString());

							contractDictionary.Add("contractDetails", Helper.RenameKeysToCamelCase(JObject.Parse(JsonConvert.SerializeObject(contractDetails))));

							listofContractDetails.Add(contractDictionary);
						}
						contractObjDto.contractObject.Add("contracts", listofContractDetails.ToArray());
					}
				}
			}
			else if (response.StatusCode == HttpStatusCode.NotFound)
			{
				_lumenazaContractRepository.ParsingApiReturnCodes(contractObjDto, response.IsSuccessStatusCode);
				return contractObjDto;
			}
			return contractObjDto;
		}

		public async Task<ContractDetails> GetConsumerContractById(string externalUserId, string contractId)
		{
			var response = await _httpClient.GetAsync("v3/consumers/" +
											  externalUserId + "/contracts/" + contractId + "/");
			var contract = new ContractDetails();

			if (response.IsSuccessStatusCode)
            {
				contract = await GetContractDetails(response);
            }

			return contract;
		}
		public async Task<ProductDetails> GetConsumerContractProducts(string externalUserId, string contractId)
		{
			var response = await _httpClient.GetAsync("v3/consumers/" + externalUserId + "/contracts/" + contractId +
											 "/product/");
			var product = new ProductDetails();

			if (response.IsSuccessStatusCode)
			{
				product = await GetProductDetails(response);
			}

			return product;
		}
		private async Task Authenticate()
		{
			var endPoint = configSettings.EndPoint;
			var grantType = configSettings.GrantType;
			var userName = configSettings.UserName;
			var password = configSettings.Password;
			var clientId = configSettings.ClientId;
			var clientSecret = configSettings.ClientSecret;

			_httpClient.BaseAddress =
				new Uri(endPoint);
			_httpClient.DefaultRequestHeaders.Accept.Clear();
			_httpClient.DefaultRequestHeaders.Add("Authorization", "Basic " + System.Convert.ToBase64String(
				System.Text.Encoding.GetEncoding("ISO-8859-1")
					.GetBytes(clientId + ":" + clientSecret)));

			var requestContent = new FormUrlEncodedContent(new[]
			{
				new KeyValuePair<string, string>("grant_type", grantType),
				new KeyValuePair<string, string>("username", userName),
				new KeyValuePair<string, string>("password", password),
				new KeyValuePair<string, string>("client_id", clientId),
				new KeyValuePair<string, string>("client_secret", clientSecret),
			});

			var response = await _httpClient.PostAsync("oauth/token/", requestContent);

			if (response.IsSuccessStatusCode)
			{
				var tokenObject = await response.Content.ReadAsAsync<TokenObject>();

				_httpClient.DefaultRequestHeaders.Accept.Clear();
				_httpClient.DefaultRequestHeaders.Authorization =
					new AuthenticationHeaderValue("Bearer", tokenObject.AccessToken);


				// TODO: JW: Major: Since this service is configured as 'scoped' in startup, each request to a controller with this class will lead to a token request to lumenaza. Consider implementing a singleton with token management (ie. refreshing tokens)
				_accessToken = tokenObject;
			}
		}
		public string GetPathByCreateOrAdd(long? externalUserId)
		{
			if (externalUserId == null) return "v3/consumers/create/";
			return "v3/consumers/" + externalUserId + "/add_contract/";
		}

		//Domain Logic from controller to its dedicated service
		public async Task<HttpResponseMessage> CreateUnverifiedContractLogic(RequestUnverifiedSavingsObject request)
		{
			if (request.Contract.SubscriptionReason == "E03"
			   && String.IsNullOrEmpty(request.Contract.PreviousProvider))
			{
				const string text = "If your subscription_reason is E03. The previous_provider field is required.";
				var result = new ResponseDetails(text);
				return new HttpResponseMessage { Content = new StringContent("ClientReceivedBadRequestException: " + result), StatusCode = System.Net.HttpStatusCode.BadRequest };
			}

			// Insert information into app database

			var contractCreatedId = CreateNewContractLocally(_createContractRequestMapper.Transform(request));

			long createdUserId = 0;

			// Create a user to SMA
			try
			{
				createdUserId = await _smaAuthenticationService.Create(new CreateUserRequest
				{
					Identifier = request.User.Email,
					Password = request.User.Password,
					City = request.User.Address.City,
					Country = request.User.Address.Country,
					Street = request.User.Address.Street,
					Title = request.User.Title,
					CompanyName = request.Contract.CompanyName,
					CultureName = request.User.Culture,
					FirstName = request.User.FirstName,
					LastName = request.User.LastName,
					PhoneNumber = request.User.Address.PhoneNumber,
					StreetNumber = request.User.Address.StreetNo,
					ZipCode = request.User.Address.ZipCode,
					CustomerType = (request.Contract.IsBusiness) ? UserCustomerType.Commercial : UserCustomerType.Private
				});

				this.Log().Log(LogLevel.Info, new
				{
					createdUserId = createdUserId
				});

				var createdUserActivationToken = await _smaAuthenticationService.GetActivationTokenById(createdUserId);

				this.Log().Log(LogLevel.Info, new
				{
					createdUserActivationToken = createdUserActivationToken.Token
				});

				var activationEmail = await _smaAuthenticationService.SendActivationMail(new UserActivationEmailRequest
				{
					ReceiverDisplayName = request.User.FirstName + " " + request.User.LastName,
					UserIdentifier = createdUserId.ToString(),
					ReceiverAddress = request.User.Email,
					Token = createdUserActivationToken.Token,
					DateTimeUtc = DateTime.UtcNow,
					CultureName = request.User.Culture
				});

				this.Log().Log(LogLevel.Info, new
				{
					activationEmail = activationEmail
				});

				UpdateInternalUserId(contractCreatedId, createdUserId.ToString());
			}
			catch (Exception ex)
			{
				this.Log().Log(LogLevel.Warning, new
				{
					createUserFailed = true,
					errorMessage = ex.Message
				});
			}

			try
			{
				UpdateStatus(contractCreatedId, ContractMasterDataStatus.InComplete);

				//#<--
				return new HttpResponseMessage { Content = new StringContent("userId: " + createdUserId), StatusCode = System.Net.HttpStatusCode.OK };
			}
			catch (Exception exception)
			{
				throw exception;
			}
		}
		public async Task<ContractObjectDto> GetUserByIDLogic(int userId)
		{
			var contractObjDto = new ContractObjectDto();
			var userResult = GetUser(userId);

			if (userResult == null)
			{
				contractObjDto.httpResponse = new HttpResponseMessage();
				contractObjDto.httpResponse.Content = new StringContent("Message: " + "User Id not found!");
				contractObjDto.httpResponse.StatusCode = HttpStatusCode.NotFound;
				return contractObjDto;
			}
				
			if (userResult.ExternalUserId == null)
			{
				contractObjDto.httpResponse = new HttpResponseMessage();
				contractObjDto.httpResponse.Content = new StringContent("Message: " + "No consumer id found for this userId!");
				contractObjDto.httpResponse.StatusCode = HttpStatusCode.NotFound;
				return contractObjDto;
			}			

			var externalUserId = userResult.ExternalUserId;
			contractObjDto = await GetConsumerContracts(externalUserId); 
			return contractObjDto;
		}
		private async Task<ProductDetails> GetProductDetails(HttpResponseMessage productDetails)
		{
			var priceList = new Dictionary<string, float>();
			var feeList = new Dictionary<string, float>();

			var productResponseString = await productDetails.Content.ReadAsAsync<object>();
			var projectObject = JObject.Parse(productResponseString.ToString());

			var product = new ProductDetails
			{
				Name = projectObject.Properties().FirstOrDefault(p => p.Name == "name")?.Value.ToString(),
				WorkingPrice = float.Parse(projectObject.Properties().FirstOrDefault(p => p.Name == "working_prices")?.Value.Children<JProperty>().FirstOrDefault().Value.ToString()),
				BaseFee = float.Parse(projectObject.Properties().FirstOrDefault(p => p.Name == "base_fees")?.Value.Children<JProperty>().FirstOrDefault().Value.ToString())
			};

			return product;
		}
		private async Task<ContractDetails> GetContractDetails(HttpResponseMessage contractDetails)
		{
			var meterId = new List<string>();

			var contractResponseObj = await contractDetails.Content.ReadAsAsync<object>();
			var contractObj = JObject.Parse(contractResponseObj.ToString());

			var delivAddress = new Address
			{
				street = contractObj.Properties().FirstOrDefault(p => p.Name == "deliv_address_street")?.Value
					.ToString(),
				houseNumber = contractObj.Properties().FirstOrDefault(p => p.Name == "deliv_address_house_number")
					?.Value.ToString(),
				city = contractObj.Properties().FirstOrDefault(p => p.Name == "deliv_address_city")?.Value.ToString(),
				zipcode = contractObj.Properties().FirstOrDefault(p => p.Name == "deliv_address_zipcode")?.Value
					.ToString(),
				addressAddition = contractObj.Properties().FirstOrDefault(p => p.Name == "deliv_address_addition")
					?.Value.ToString(),
			};

			meterId.Add(contractObj.Properties().FirstOrDefault(p => p.Name == "meter_id")?.Value.ToArray<JToken>().FirstOrDefault().ToString());

			var contract = new ContractDetails
			{
				annualConsumption = int.Parse(contractObj.Properties()
					.FirstOrDefault(p => p.Name == "annual_consumption")?.Value.ToString()),
				monthlyAmount = (!string.IsNullOrEmpty(contractObj.Properties()
					.FirstOrDefault(p => p.Name == "current_monthly_installment_amount")?.Value.ToString()))
					? float.Parse(contractObj.Properties()
						.FirstOrDefault(p => p.Name == "current_monthly_installment_amount")?.Value.ToString())
					: (float?)null,

				deliveryStartDate = (!string.IsNullOrEmpty(contractObj.Properties()
					.FirstOrDefault(p => p.Name == "preferred_delivery_start")?.Value.ToString()))
					? DateTime.Parse(contractObj.Properties().FirstOrDefault(p => p.Name == "preferred_delivery_start")
						?.Value.ToString())
					: (DateTime?)null,

				registrationStatus = "complete",
				meterId = meterId,
				marketLocation = contractObj.Properties().FirstOrDefault(p => p.Name == "market_location")?.Value
					.ToString(),
				deliveryAddress = delivAddress
			};

			return contract;
		}
		public async Task<ResponseConsumersObject> CreateContractLogic(int contractMasterId, RequestCreateContractObject requestCreateContractObject)
		{
			return await CreateNewContract(contractMasterId, _consumerObjectMapper.Transform(requestCreateContractObject));
		}


		/// <summary>
		/// Check Incomplete create contract record
		/// If contract have been created more than 30 days then the status changes to Cancelled
		/// If contract will be creating successfully then the status changes to Complete
		/// </summary>
		/// <returns></returns>
		public async Task CheckIncompleteContracts()
		{
			// Get all re-create contract
			var contractMasterList = GetNeedReSentContract(null);
			this.Log().Log(LogLevel.Info, new
			{
				preliminaryContractsCount = contractMasterList.Count,
				type = "CRON"
			});

			foreach (var contract in contractMasterList)
			{
				try
				{
					if ((contract.Master.CreatedDateTime - DateTime.Now).TotalDays < -30)
					{

						UpdateStatus(contract.Master.Id, ContractMasterDataStatus.Cancelled);
						RemoveBankInfo(contract.Master.Id);
					}
					else
					{
						long userId = contract.Master.UserId ?? 0;
						bool isUserActivated = _userAuthResource.GetUserById(userId).Result.Activated;

						if (userId != 0 && isUserActivated)
						{
							var response = await CreateNewContract(contract.Master.Id,
								new LumenazaConsumersRequestObject
								{
									accounting_email = contract.Entity.Email,
									annual_consumption = contract.Data.AnnualConsumption.ToString(),
									bank_data_first_name = contract.BankData.FirstName,
									bank_data_iban = contract.BankData.Iban,
									bank_data_last_name = contract.BankData.LastName,
									bill_address_addition = (contract.BillAddress.Addition == "" ? null : contract.BillAddress.Addition),
									bill_address_city = contract.BillAddress.City,
									bill_address_house_number = contract.BillAddress.HouseNumber,
									bill_address_street = contract.BillAddress.Street,
									bill_address_zipcode = contract.BillAddress.Zipcode,
									birthday = contract.Entity.Birthday,
									company_name = contract.Entity.CompanyName,
									consumption_before_battery_installation =
										contract.Data.ConsumptionBeforeBatteryInstallation.ToString(),
									deliv_address_addition = (contract.DeliveryAddress.Addition == "" ? null : contract.DeliveryAddress.Addition),
									deliv_address_city = contract.DeliveryAddress.City,
									deliv_address_house_number = contract.DeliveryAddress.HouseNumber,
									deliv_address_street = contract.DeliveryAddress.Street,
									deliv_address_zipcode = contract.DeliveryAddress.Zipcode,
									email = contract.Entity.Email,
									first_name = contract.Entity.FirstName,
									former_supplier_contract_terminated =
										Convert.ToBoolean(contract.Data.FormerSupplierContractTerminated),
									former_supplier_contract_termination_date =
										contract.Data.FormerSupplierContractTerminationDate,
									former_supplier_first_name = contract.Data.FormerSupplierFirstName,
									former_supplier_last_name = contract.Data.FormerSupplierLastName,
									is_business = contract.Entity.IsBusiness,
									is_small_business = contract.Entity.IsSmallBusiness,
									last_name = contract.Entity.LastName,
									meter_id = contract.Data.MeterId,
									meter_role = contract.Data.MeterRole,
									meteringpoint_id = (contract.Data.MeteringpointId == "" ? null : contract.Data.MeteringpointId),
									order_date = contract.Data.OrderDate,
									payment_method = contract.BankData.PaymentMethod,
									preferred_delivery_start = contract.Data.PreferredDeliveryStart,
									previous_provider = (contract.Data.PreviousProvider == "" ? null : contract.Data.PreviousProvider),
									saas_contract_id = contract.Data.SaasContractId,
									saas_customer_id = contract.Data.SaasCustomerId,
									salutation = contract.Entity.Salutation,
									sepa_date = contract.BankData.SepaDateUtc,
									sepa_reference = contract.BankData.SepaReference,
									subscription_reason = contract.Data.SubscriptionReason,
									tariff_type = contract.Data.TariffType,
									tax_number = contract.Entity.TaxNumber,
									telephone = (contract.Entity.Telephone == "" ? null : contract.Entity.Telephone),
									third_party_salespartner = contract.Data.ThirdPartySalespartner,
									title = contract.Entity.Title,
									username = contract.Entity.Username,
								}
							);

							this.Log().Log(LogLevel.Info, new
							{
								userId = userId,
								consumerId = response.ConsumerId,
								contractId = response.ContractId
							});

						}

					}
				}
				catch (Exception e)
				{

				}
			}
		}


	}
}