using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using SMA.Logging;
using Sma.Sp.Libraries.WebApiBaseClient.Common.Exceptions;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.PriceObject;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.TokenObject;
using Sma.Sp.TariffService.Domain.Entities.MarketPartners;
using Sma.Sp.TariffService.Domain.Interfaces;
using Microsoft.Extensions.Options;
using Sma.Sp.TariffService.Domain.Entities.Dtos;

namespace Sma.Sp.TariffService.Domain.Services
{ //its LumenazaContractRepository use to declare and execute all functions like getprices,getcontracts ,Authentication and etc.
	public class LumenazaContractRepository : ILumenazaContractRepository
	{
		private IConfiguration _configuration;
		private HttpClient _httpClient;
		private TokenObject _accessToken;
		private ConfigSettings configSettings;

		/// <summary>
		/// 
		/// </summary>
		/// <param name="lumenazaLoginService"></param>
		/// <param name="configuration"></param>
		/// <param name="lumenazaLogintestService"></param>
		public LumenazaContractRepository(IConfiguration configuration, IOptions<ConfigSettings> options)
		{
			_configuration = configuration;
			configSettings = options.Value;
			// Proxy configuration
			var httpHandler = new HttpClientHandler();
			if (Convert.ToBoolean(_configuration["InfrastructureConfiguration:WebProxy:Enable"]))
			{
				httpHandler.UseProxy = true;
				httpHandler.Proxy = new WebProxy(
					_configuration["InfrastructureConfiguration:WebProxy:Host"],
					Convert.ToInt32(_configuration["InfrastructureConfiguration:WebProxy:Port"]));
			}

			_httpClient = new HttpClient(httpHandler);
			Task.Run(this.Authenticate).Wait();
		}

		public async Task<object> GetPrice(PriceRequest priceRequest)
		{
			var query = "zipcode=" + priceRequest.zipcode +
						"&consumption=" + priceRequest.consumption +
						"&tariff_type=" + priceRequest.tariffType;
			if (priceRequest.isBusiness == true)
			{
				query += "&is_business=" + priceRequest.isBusiness;
			}

			query += (priceRequest.deliverStreets == false)
				? "&deliver_streets=false"
				: "&deliver_streets=" + priceRequest.deliverStreets;
			if (priceRequest.htConsumptionPart != default)
				query += "&ht_consumption_part=" + priceRequest.htConsumptionPart;
			if (priceRequest.street != default) query += "&street=" + priceRequest.street;
			if (priceRequest.houseNumber != default) query += "&house_number=" + priceRequest.houseNumber;
			if (priceRequest.city != default) query += "&city=" + priceRequest.city;

			var response = await _httpClient.GetAsync("v3/prices/?" + query);

			if (!response.IsSuccessStatusCode && !(response.StatusCode == HttpStatusCode.Ambiguous))
				throw new ClientReceivedInternalServerErrorException();

			var result = await response.Content.ReadAsStringAsync();
			JObject oResult = JObject.Parse(result);

			var streetsObject = oResult.GetValue("streets");
			if (streetsObject != null) return oResult;

			var tariffsObject = oResult.GetValue("tariffs");
			var costArray = tariffsObject.First.Value<JArray>("costs");
			var costList = new List<CostDTO> { };

			foreach (var costItem in costArray)
			{
				var costName = costItem.Value<string>("name");
				if (costName != "sma_commission") { 
					costList.Add(new CostDTO
					{
						costPerUnitNetto = costItem.Value<float>("cost_per_unit_netto"),
						name = costName,
						displayName = costItem.Value<string>("display_name"),
						unit = costItem.Value<string>("unit")
					});
				}
			}

			PriceResponse priceResponse = new PriceResponse {
				consumption = ((int)oResult.GetValue("consumption")),
				isBusiness = ((bool)oResult.GetValue("is_business")),
				tariffs = new TariffDTO
				{
					basePrice = oResult.GetValue("tariffs").First.Value<float>("base_price"),
					price = oResult.GetValue("tariffs").First.Value<float>("price"),
					basePriceYearly = oResult.GetValue("tariffs").First.Value<float>("base_price_yearly"),
					amount = oResult.GetValue("tariffs").First.Value<float>("amount"),
					totalAmount = oResult.GetValue("tariffs").First.Value<float>("total_amount"),
					totalAmountYearly = oResult.GetValue("tariffs").First.Value<float>("total_amount_yearly"),
					tariffType = oResult.GetValue("tariffs").First.Value<string>("tariff_type"),
					costs = costList
				},
				localeUtility = new LocaleUtility {
					LocalUtilityYearPrice = oResult.GetValue("locale_utility").Value<float>("local_utility_year_price"),
					LocatUtilityName = oResult.GetValue("locale_utility").Value<String>("locat_utility_name")
				}
		};

            return priceResponse;

		}

		public async Task<object> GetPriceCo2Avoidance(PriceCo2Request priceCo2Request)
		{
			var query = "consumption=" + priceCo2Request.consumption;

			if (priceCo2Request.year != 0) query += "&year=" + priceCo2Request.year;

			var response = await _httpClient.GetAsync("v3/prices/get_co2_savings/?" + query);

			if (!response.IsSuccessStatusCode)
			{
				this.Log().Log(LogLevel.Error, new
				{
					code = response.StatusCode,
					message = response.Content
				});
				throw new ClientReceivedInternalServerErrorException();
			}

			var responseObj = await response.Content.ReadAsAsync<object>();
			return responseObj;
		}

		public async Task<object> GetProvider()
		{
			var response = await _httpClient.GetAsync("v3/marketpartners/provider/");

			if (!response.IsSuccessStatusCode)
			{
				this.Log().Log(LogLevel.Error, new
				{
					code = response.StatusCode,
					message = response.Content
				});
				throw new ClientReceivedUnknownStatusException(response.StatusCode);
			}

			var data = await response.Content.ReadAsAsync<List<JArray>>();
			var result = data.Select(_ => new Provider() { Id = _[0].ToString(), Name = _[1].ToString() });
			return result;
		}

		public HttpResponseMessage ParsingApiReturnCodes(ContractObjectDto contractObjDto, bool IsSuccessStatusCode)
		{
			if (IsSuccessStatusCode)
			{
				contractObjDto.httpResponse = new HttpResponseMessage();
				contractObjDto.httpResponse.Content = new StringContent("Message: " + "No contracts found for this userId!");
				contractObjDto.httpResponse.StatusCode = HttpStatusCode.NotFound;
				return contractObjDto.httpResponse;
			}
			else
			{
				contractObjDto.httpResponse = new HttpResponseMessage();
				contractObjDto.httpResponse.StatusCode = HttpStatusCode.NotFound;
				return contractObjDto.httpResponse;
			}
		}

		public HttpResponseMessage ParsingApiReturnCodes(bool IsSuccessStatusCode, HttpStatusCode status)
		{
			if (IsSuccessStatusCode)
			{
				return new HttpResponseMessage { Content = new StringContent("Message: " + " Contract successfully created!"), StatusCode = System.Net.HttpStatusCode.OK }; //Content =  Helper.RenameKeysToCamelCase(responseObj)
			}
			else if (status == HttpStatusCode.BadRequest)
			{
				return new HttpResponseMessage { Content = new StringContent("ClientReceivedBadRequestException"), StatusCode = System.Net.HttpStatusCode.BadRequest }; //, Content = Helper.RenameKeysToCamelCase(returnObject)
			}
			else
			{
				return new HttpResponseMessage { Content = new StringContent("Message: " + "Contract creation incomplete, transfer pending!"), StatusCode = System.Net.HttpStatusCode.OK };
			}
		}
		private async Task Authenticate()
		{
			var endPoint = configSettings.EndPoint;
			var grantType = configSettings.GrantType;
			var userName = configSettings.UserName;
			var password = configSettings.Password;
			var clientId = configSettings.ClientId;
			var clientSecret = configSettings.ClientSecret;

			_httpClient.BaseAddress =
				new Uri(endPoint);
			_httpClient.DefaultRequestHeaders.Accept.Clear();
			_httpClient.DefaultRequestHeaders.Add("Authorization", "Basic " + System.Convert.ToBase64String(
				System.Text.Encoding.GetEncoding("ISO-8859-1")
					.GetBytes(clientId + ":" + clientSecret)));

			var requestContent = new FormUrlEncodedContent(new[]
			{
				new KeyValuePair<string, string>("grant_type", grantType),
				new KeyValuePair<string, string>("username", userName),
				new KeyValuePair<string, string>("password", password),
				new KeyValuePair<string, string>("client_id", clientId),
				new KeyValuePair<string, string>("client_secret", clientSecret),
			});

			var response = await _httpClient.PostAsync("oauth/token/", requestContent);

			if (response.IsSuccessStatusCode)
			{
				var tokenObject = await response.Content.ReadAsAsync<TokenObject>();
				
				_httpClient.DefaultRequestHeaders.Accept.Clear();
				_httpClient.DefaultRequestHeaders.Authorization =
					new AuthenticationHeaderValue("Bearer", tokenObject.AccessToken);


				// TODO: JW: Major: Since this service is configured as 'scoped' in startup, each request to a controller with this class will lead to a token request to lumenaza. Consider implementing a singleton with token management (ie. refreshing tokens)
				_accessToken = tokenObject;
			}
		}
	}
}
