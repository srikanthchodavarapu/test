

IF (N'$(Environment)' = N'Development')
BEGIN
    PRINT 'Setting up logins for development ...'

    IF NOT EXISTS ( SELECT * FROM sys.syslogins WHERE [name] = N'SMA\SMA_CMS_SYSTEM')
        CREATE LOGIN [SMA\SMA_CMS_SYSTEM] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]

    IF NOT EXISTS ( SELECT * FROM sys.syslogins WHERE [name] = N'SMA\SVC.TFSbuild.tfs03')
        CREATE LOGIN [SMA\SVC.TFSbuild.tfs03] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]

    IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE [name] = N'user4PortalGrpTariffService')
    BEGIN
        IF EXISTS (SELECT * FROM sys.syslogins WHERE [name] = N'SMA\SMA_CMS_SYSTEM' AND sysadmin = 1) /* SMA\SMA_CMS_SYSTEM is sys_admin*/
            CREATE USER user4PortalGrpTariffServicee WITHOUT LOGIN
        ELSE IF EXISTS (SELECT * FROM sys.databases WHERE [name] = DB_NAME() AND SUSER_SNAME( owner_sid ) =  N'SMA\SMA_CMS_SYSTEM') /* SMA\SMA_CMS_SYSTEM is db_owner*/
            CREATE USER user4PortalGrpTariffService WITHOUT LOGIN
        ELSE
            CREATE USER user4PortalGrpTariffService FOR LOGIN [SMA\SMA_CMS_SYSTEM] WITH DEFAULT_SCHEMA=[dbo]
    END

    IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE [name] = N'user4TfsBuild')
        CREATE USER [user4TfsBuild] FOR LOGIN [SMA\SVC.TFSbuild.tfs03] WITH DEFAULT_SCHEMA=[dbo]

    IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE [name] = N'user4Splunk')
        CREATE USER [user4Splunk] WITHOUT LOGIN;
END
GO
