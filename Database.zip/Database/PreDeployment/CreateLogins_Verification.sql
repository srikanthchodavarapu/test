

IF (N'$(Environment)' = N'Verification')
BEGIN
    PRINT 'Setting up logins for Verification ...'

    IF NOT EXISTS ( SELECT * FROM sys.syslogins WHERE [name] = N'PORTAL\GRP-SQL-I-TariffService')
        CREATE LOGIN [PORTAL\GRP-SQL-I-TariffService] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
    
    IF NOT EXISTS ( SELECT * FROM sys.syslogins WHERE [name] = N'PORTAL\SVC-Splunk')
        CREATE LOGIN [PORTAL\SVC-Splunk]  FROM WINDOWS WITH DEFAULT_LANGUAGE = [us_english];

    IF NOT EXISTS (SELECT * FROM sys.syslogins WHERE [name] = N'VER\SVC-57-Octo-Deploy')
    BEGIN
        CREATE LOGIN [VER\SVC-57-Octo-Deploy] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
        ALTER SERVER ROLE [sysadmin] ADD MEMBER [VER\SVC-57-Octo-Deploy]
    END

    IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE [name] = N'user4PortalGrpTariffService')
        CREATE USER [user4PortalGrpTariffService] FOR LOGIN [PORTAL\GRP-SQL-I-TariffService] WITH DEFAULT_SCHEMA=[dbo]

    IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE [name] = N'user4Splunk')
        CREATE USER [user4Splunk] FOR LOGIN [PORTAL\SVC-Splunk];

    --GRANT VIEW SERVER STATE TO [user4Splunk]
    --GRANT VIEW DATABASE STATE TO [user4Splunk]
END
GO
