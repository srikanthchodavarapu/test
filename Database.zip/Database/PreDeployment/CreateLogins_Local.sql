
IF (N'$(Environment)' = N'Local')
BEGIN
	PRINT 'Setting up local logins ...'
	DECLARE @userName as nvarchar(128)
	DECLARE @sqlString as nvarchar(max)
	IF DEFAULT_DOMAIN() = 'SMA'
	BEGIN
		SET @userName = N'SMA\SMA_CMS_SYSTEM'
	END
	ELSE
	BEGIN
		SET @userName = N'IIS APPPOOL\Backend'
	END	

	IF NOT EXISTS (SELECT * FROM sys.syslogins WHERE [name] =  @userName)
		BEGIN
			SET @sqlString = 'CREATE LOGIN [' + @userName + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]';
			EXECUTE sp_executesql @sqlString
		END		

	IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE [name] = N'user4PortalGrpTariffService')
	BEGIN
		IF EXISTS (SELECT * FROM sys.syslogins WHERE [name] = @userName AND sysadmin = 1) /* local user is sys_admin*/
			CREATE USER user4PortalGrpTariffService WITHOUT LOGIN
		ELSE IF EXISTS (SELECT * FROM sys.databases WHERE [name] = DB_NAME() AND SUSER_SNAME( owner_sid ) =  @userName) /* local user is db_owner*/
			CREATE USER user4PortalGrpTariffService WITHOUT LOGIN
		ELSE
			BEGIN
				SET @sqlString = 'CREATE USER user4PortalGrpTariffService FOR LOGIN [' + @userName + '] WITH DEFAULT_SCHEMA=[dbo]';
				EXECUTE sp_executesql @sqlString
			END			
	END

	IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE [name] = N'user4Splunk')
		CREATE USER [user4Splunk] WITHOUT LOGIN;
END
GO
