DROP TYPE IF EXISTS [dbo].[ContractMasterDataUDT];
GO

/****** Object:  UserDefinedTableType [dbo].[ContractMasterDataUDT]    Script Date: 9/15/2021 12:50:30 PM ******/
CREATE TYPE [dbo].[ContractMasterDataUDT] AS TABLE(
	[Id] [int] NOT NULL,
	[CreatedDateTime] [datetime] NOT NULL,
	[LastModifiedDateTime] [datetime] NOT NULL,
	[Status] [varchar](50) NULL,
	[UserId] [bigint] NULL,
	[ExternalUserId] [varchar](50) NULL,
	[ExternalContractId] [varchar](50) NULL,
	[ContractDataId] [int] NULL
)
GO


