DROP TYPE IF EXISTS [dbo].[ContractBankDataUDT]; 
GO

/****** Object:  UserDefinedTableType [dbo].[ContractBankDataUDT]    Script Date: 9/15/2021 12:50:04 PM ******/
CREATE TYPE [dbo].[ContractBankDataUDT] AS TABLE(
	[Id] [int] NOT NULL,
	[FirstName] [nvarchar](100) NULL,
	[LastName] [nvarchar](100) NOT NULL,
	[Iban] [varchar](32) NOT NULL,
	[PaymentMethod] [varchar](250) NULL,
	[SepaDate] [datetime] NULL,
	[SepaReference] [varchar](250) NULL
)
GO


