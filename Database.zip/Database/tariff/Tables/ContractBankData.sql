﻿CREATE TABLE [dbo].[ContractBankData](
	[id] [int] IDENTITY (1,1),
	[firstName] [nvarchar](100) NULL,
	[lastName] [nvarchar](100) NOT NULL, 
	[iban] [varchar](32) NOT NULL,
-- TODO: JW: Minor: 250 seems very huge for a Payment method. Prefer an (INT) enum for type definitions like payment method
	[paymentMethod] [varchar](250) NULL,
	[sepaDate] [datetime] NULL,
	[sepaReference] [varchar](250) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
