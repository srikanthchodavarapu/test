﻿CREATE TABLE [dbo].[ContractData](
	[id] [int] IDENTITY (1,1),
	[contractEntityId] [int] NOT NULL,													--		<- Foreign Key
	[deliveryAddressId] [int] NOT NULL,													--		<- Foreign Key
	[billingAddressId] [int] NOT NULL,													--		<- Foreign Key
	[preferredDeliveryStart] [date] NULL,

-- TODO: JW: Prefer an (INT) enum for type definitions like subscriptionReasons
	[subscriptionReason] [varchar](20) NOT NULL,
	[meterId] [varchar](20) NOT NULL,
	[meterRole] [varchar](250) NULL,
	[meteringpointId] [varchar](100) NULL,

-- TODO: JW: Minor: could potentially be NVARCHAR - but which provider realisticly has a longer name than 100 chars?
	[previousProvider] [varchar](500) NOT NULL,

-- TODO: JW: Minor: Prefer adding the unit in the colum definition (e.g. annualConsumptionKwh)
	[annualConsumption] [float] NOT NULL,
	[bankDataId] [int] NULL,														--		<- Foreign Key
	
-- TODO: JW: Minor: 250 seems very huge for a type. Prefer an (INT) enum for type definitions like tariff type
	[tariffType] [varchar](255) NOT NULL,

-- TODO: JW: Minor: It seems that 'saas' and 'thirdParty' reference to the same entity. I suggest calling it always 'thirdParty' for mear clearity
	[saasCustomerId] [varchar](20) NULL,
	[saasContractId] [varchar](20) NULL,
	[thirdPartySalespartner] [varchar](255) NULL,
	[freeAmount] [int] NOT NULL,

-- TODO: JW: Minor: Prefer adding the unit in the colum definition (e.g. [annual]consumptionBeforeBatteryInstallationKwh)
	[consumptionBeforeBatteryInstallation] [int] NULL,

-- TODO: JW: Minor: If dates are in UTC, prefer including Utc in the column name. If this data is not UTC, I suggest saving it in UTC
	[orderDate] [date] NULL,

-- TODO: JW: Major: Provider and supplier seems like the same for me. Potentially, a former customer is meant. I suggest normalizing this entity in a different table.
	[formerSupplierFirstName] [nvarchar](100) NULL,
	[formerSupplierLastName] [nvarchar](100) NULL,
	[formerSupplierContractTerminated] [bit] NULL,
	[formerSupplierContractTerminationDate] [date] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ContractData]
ADD  CONSTRAINT FK_ContractData_ContractEntityId FOREIGN KEY(contractEntityId)
REFERENCES [dbo].[ContractEntity] (ID) 
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[ContractData]
ADD  CONSTRAINT FK_ContractData_DeliveryAddressId FOREIGN KEY(deliveryAddressId)
REFERENCES [dbo].[ContractAddress] (ID) 
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[ContractData]
ADD  CONSTRAINT FK_ContractData_BillingAddressId FOREIGN KEY(billingAddressId)
REFERENCES [dbo].[ContractAddress] (ID) 
ON DELETE NO ACTION
GO

ALTER TABLE [dbo].[ContractData]
ADD  CONSTRAINT FK_ContractData_BankDataId FOREIGN KEY(bankDataId)
REFERENCES [dbo].[ContractBankData] (ID) 
ON DELETE SET NULL
GO