-- cleanup for exceptions table if existing
DROP TABLE IF EXISTS [dbo].[Exceptions]; 
GO