﻿CREATE TABLE [dbo].[ContractMasterData](
	[id] [int] IDENTITY (1,1),
	[createdDateTime] [datetime] NOT NULL,
	[lastModifiedDateTime] [datetime] NOT NULL,
-- TODO: JW: Minor: Prefer an (INT) enum for type definitions 
	[status] [varchar](50) NULL,
	[userId] [bigint] NULL,
	[externalUserId] [varchar](50) NULL,
	[externalContractId] [varchar](50) NULL,
	[contractDataId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
