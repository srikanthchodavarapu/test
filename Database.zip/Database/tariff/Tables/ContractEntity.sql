﻿
-- TODO: JW: Major: It seems, that contractEntity was meant as a normalization of contractData, but still looks like a collection of different subjects. Why not using ContractAddress?
CREATE TABLE [dbo].[ContractEntity](
	[id] [int] IDENTITY (1,1),
	[isBusiness] [bit] NOT NULL,
	[isSmallBusiness] [bit] NOT NULL,

-- TODO: JW: Minor: Potentially, it must be NVARCHAR
	[companyName] [varchar](250) NULL,

-- TODO: JW: Minor: Potentially, it must be NVARCHAR
	[salutation] [varchar](50) NOT NULL,

-- TODO: JW: Minor: Potentially, it must be NVARCHAR
	[title] [varchar](50) NULL,
	[firstName] [nvarchar](100) NOT NULL,
	[lastName] [nvarchar](100) NOT NULL,
	[birthday] [date] NULL,
	[telephone] [varchar](20) NULL,

-- TODO: JW: Minor: Potentially, it must be NVARCHAR
	[email] [varchar](250) NOT NULL,

-- TODO: JW: Minor: Potentially, it must be NVARCHAR
	[accountingEmail] [varchar](250) NULL,
	[username] [nvarchar](100) NULL,
	[taxNumber] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
