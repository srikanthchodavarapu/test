﻿CREATE TABLE [dbo].[ContractAddress](
	[id] [int] IDENTITY (1,1),
	[street] [nvarchar](250) NOT NULL,
	[houseNumber] [varchar](10) NOT NULL,
	[zipcode] [varchar](15) NOT NULL,
	[city] [nvarchar](250) NOT NULL,
	[addition] [nvarchar](250) NULL,

-- TODO: JW: Minor: What about "Country" (or Country Code)?

PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
