/****** Object:  View [dbo].[ContractBankDataView]    Script Date: 9/15/2021 12:51:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[ContractBankDataView]
AS
SELECT dbo.ContractBankData.*
FROM     dbo.ContractBankData
GO


