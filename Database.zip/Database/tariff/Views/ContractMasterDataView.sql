/****** Object:  View [dbo].[ContractMasterDataView]    Script Date: 9/14/2021 10:47:33 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[ContractMasterDataView]
AS
SELECT dbo.ContractMasterData.*
FROM     dbo.ContractMasterData
GO


