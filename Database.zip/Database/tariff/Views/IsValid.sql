/****** Object:  View [dbo].[IsValid]    Script Date: 9/14/2021 10:47:50 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[IsValid]
AS
SELECT dbo.ContractMasterData.id, dbo.ContractMasterData.createdDateTime, dbo.ContractMasterData.lastModifiedDateTime, dbo.ContractMasterData.status, dbo.ContractMasterData.userId, dbo.ContractMasterData.externalUserId, 
                  dbo.ContractMasterData.externalContractId, dbo.ContractMasterData.contractDataId, dbo.ContractData.meterId, dbo.ContractEntity.lastName, dbo.ContractAddress.street, dbo.ContractAddress.houseNumber, 
                  dbo.ContractAddress.zipcode, dbo.ContractAddress.city
FROM     dbo.ContractMasterData INNER JOIN
                  dbo.ContractData ON dbo.ContractMasterData.id = dbo.ContractData.id INNER JOIN
                  dbo.ContractEntity ON dbo.ContractData.contractEntityId = dbo.ContractEntity.id INNER JOIN
                  dbo.ContractAddress ON dbo.ContractData.deliveryAddressId = dbo.ContractAddress.id
GO


