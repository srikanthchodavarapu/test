/****** Object:  View [dbo].[GetByEmail]    Script Date: 9/14/2021 10:42:24 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[GetByEmail]
AS
SELECT dbo.ContractMasterData.*, dbo.ContractEntity.email
FROM     dbo.ContractMasterData INNER JOIN
                  dbo.ContractData ON dbo.ContractMasterData.id = dbo.ContractData.id INNER JOIN
                  dbo.ContractEntity ON dbo.ContractData.contractEntityId = dbo.ContractEntity.id
GO


