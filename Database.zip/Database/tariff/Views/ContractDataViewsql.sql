/****** Object:  View [dbo].[ContractDataView]    Script Date: 9/15/2021 12:52:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[ContractDataView]
AS
SELECT dbo.ContractData.*
FROM     dbo.ContractData
GO


