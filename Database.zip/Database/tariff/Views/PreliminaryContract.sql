/****** Object:  View [dbo].[PreliminaryContract]    Script Date: 9/14/2021 10:48:01 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[PreliminaryContract]
AS
SELECT dbo.ContractMasterData.*, dbo.ContractData.contractEntityId, dbo.ContractData.deliveryAddressId, dbo.ContractData.billingAddressId, dbo.ContractData.preferredDeliveryStart, dbo.ContractData.subscriptionReason, 
                  dbo.ContractData.meterId, dbo.ContractData.meterRole, dbo.ContractData.meteringpointId, dbo.ContractData.previousProvider, dbo.ContractData.annualConsumption, dbo.ContractData.bankDataId, dbo.ContractData.tariffType, 
                  dbo.ContractData.saasCustomerId, dbo.ContractData.saasContractId, dbo.ContractData.thirdPartySalespartner, dbo.ContractData.freeAmount, dbo.ContractData.consumptionBeforeBatteryInstallation, dbo.ContractData.orderDate, 
                  dbo.ContractData.formerSupplierFirstName, dbo.ContractData.formerSupplierLastName, dbo.ContractData.formerSupplierContractTerminated, dbo.ContractData.formerSupplierContractTerminationDate, dbo.ContractEntity.isBusiness, 
                  dbo.ContractEntity.isSmallBusiness, dbo.ContractEntity.companyName, dbo.ContractEntity.salutation, dbo.ContractEntity.title, dbo.ContractEntity.firstName, dbo.ContractEntity.lastName, dbo.ContractEntity.birthday, 
                  dbo.ContractEntity.telephone, dbo.ContractEntity.email, dbo.ContractEntity.accountingEmail, dbo.ContractEntity.username, dbo.ContractEntity.taxNumber, 
				  DeliveryAddress.street daStreet, DeliveryAddress.houseNumber daHouseNumber, 
                  DeliveryAddress.zipcode daZipcode, DeliveryAddress.city daCity, DeliveryAddress.addition daAddition, 
				  BillAddress.street, BillAddress.houseNumber, 
                  BillAddress.zipcode, BillAddress.city, BillAddress.addition,
				  dbo.ContractBankData.firstName AS CBDFirstName, dbo.ContractBankData.lastName AS CBDLastName, dbo.ContractBankData.iban, 
                  dbo.ContractBankData.paymentMethod, dbo.ContractBankData.sepaDate, dbo.ContractBankData.sepaReference
FROM     dbo.ContractMasterData LEFT JOIN
                  dbo.ContractData ON dbo.ContractMasterData.id = dbo.ContractData.id LEFT JOIN
                  dbo.ContractEntity ON dbo.ContractData.contractEntityId = dbo.ContractEntity.id LEFT JOIN
                  dbo.ContractAddress DeliveryAddress ON dbo.ContractData.deliveryAddressId = DeliveryAddress.id LEFT JOIN
				  dbo.ContractAddress BillAddress ON dbo.ContractData.billingAddressId = BillAddress.id LEFT JOIN
                  dbo.ContractBankData ON dbo.ContractData.bankDataId = dbo.ContractBankData.id
WHERE    dbo.ContractMasterData.userId IS NOT NULL AND dbo.ContractMasterData.[status] = 'incomplete'
GO


