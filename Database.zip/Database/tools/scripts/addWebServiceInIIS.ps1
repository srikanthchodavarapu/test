param
(
	[Parameter(Mandatory = $true,
  			   HelpMessage = "e.g.: Sma.Sp.WebUi.Api"  )]
	[string] $serviceName,
	[Parameter(Mandatory = $true,
  			   HelpMessage = "where Web.config is placed (project folder)"  )]
	[string] $physicalDirectory
)

Import-Module Webadministration

function GrantAccessToFolder {
	param
	(
		[Parameter(Mandatory = $true)]
		[string] $path,
		[Parameter(Mandatory = $true)]
		[string] $identity
	)

	# Write-Host "GrantAccessToFolder $path for $identity"

	$acl = Get-Acl -Path $path
	try
	{
		$accessrule	= New-Object System.Security.AccessControl.FileSystemAccessRule ($identity, 'ReadAndExecute', 'ContainerInherit, ObjectInherit', 'InheritOnly', 'Allow')
		if($accessrule -ne $Null) {
			$acl.SetAccessRule($accessrule)
			Set-Acl -Path $path -AclObject $acl 
		}
	}
	catch
	{
	}
}

# eliminate ".."s
$physicalDirectory=(Resolve-Path -Path $physicalDirectory).Path

# remove old microservice from IIS
Import-Module Webadministration 
if ((Test-Path "IIS:\\Sites\\EnnexOs-Backend\$serviceName")) 
{
	Remove-Item -Path "IIS:\Sites\EnnexOs-Backend\$serviceName" -Force -Recurse
}


if (-not (Test-Path "IIS:\\Sites\\EnnexOs-Backend\$serviceName")) 
{ 
	$isCoreProject=$false
	if(Test-Path -Path "$physicalDirectory\appsettings.json") {
		$isCoreProject=$true
	}


	$appPoolName="Backend"

	# if it's a core project
	if($isCoreProject) {
		$projDir=$physicalDirectory
		$physicalDirectory="$physicalDirectory\bin\Debug\netcoreapp3.0\publish"
		$appPoolName="BackendCore_$serviceName"

		# create app pool for core app
		if ((Test-Path "IIS:\AppPools\$appPoolName") -eq $False) { 
			New-Item -Path "IIS:\AppPools" -Name $appPoolName -Type AppPool 
		}

		$appPool = Get-ChildItem IIS:\AppPools\ | Where-Object { $_.Name -eq $appPoolName }; 
		$appPool.startMode = 'AlwaysRunning'; 
		$appPool.managedRuntimeVersion = ""; 
		$appPool.managedPipelineMode = "Classic"
		$appPool | Set-Item -Verbose; 

		# find *.csproj
		Get-ChildItem -Path $projDir -File | Where-Object {$_.Name -like '*.csproj'} | ForEach {
            $filePath = $_.FullName
            $fileName = $_.Name
			Write-Host "publishing to folder ..."
			# compile and publish core app to folder bin\Debug\netcoreapp3.0\publish
			& dotnet publish $filePath --configuration Debug --force
			Write-Host "published ..."
        }
	}

	# install app in IIS
	New-Item -Type Application `
			 -Path "IIS:\Sites\EnnexOs-Backend\$serviceName" `
		     -physicalPath $physicalDirectory `
	         -ApplicationPool $appPoolName 

	Write-Host "physicalDirectory=$physicalDirectory"
}

GrantAccessToFolder -path $physicalDirectory -identity 'Jeder'
GrantAccessToFolder -path $physicalDirectory -identity 'Everyone'
