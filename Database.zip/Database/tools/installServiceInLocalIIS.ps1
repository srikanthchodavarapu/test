& ./build.ps1 -Target Install-Services
