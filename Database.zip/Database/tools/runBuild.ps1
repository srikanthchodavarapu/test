param
(
	[Parameter(Mandatory = $false,
               HelpMessage = "Specifies the 1st file to compare. Make sure it's an absolute path with the file name and its extension."  )]
	[string] $Target='Default',
	[Parameter(Mandatory = $false,
               HelpMessage = "Specifies the 1st file to compare. Make sure it's an absolute path with the file name and its extension."  )]
	[string] $Directory='.\'
)



If (($Target -eq 'Install-Services') -and -NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))
{
	$curDir=(Get-Location).Path

	# Relaunch as an elevated process:
	Start-Process powershell.exe "-File",('"{0}"' -f $MyInvocation.MyCommand.Path),"-Directory","`"$curDir`"","-Target",$Target -Verb RunAs
	exit
}

If ($Target -eq 'Install-Services')
{
	# if .net core windows server hosting isn't installed
	$software = "*Windows Server Hosting*";
	$installed = ((gp HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*).DisplayName -like $software).Length -gt 0

	if(-Not $installed) {
		Write-Host -ForegroundColor Red ".net core windows server hosting runtime bundle isn't installed !!!"

		Write-Host -ForegroundColor Cyan ("Press any key to exit")
		cmd /c pause | out-null

		exit 8768765
	}
}

Function RemovegeneratedFilesFromTools {
	Get-ChildItem .\tools -recurse -force | select -expand fullname | where {-not($_ -like "*packages.config")} | sort length -desc | foreach-object {remove-item $_ -force -recurse -confirm:$false}
}

Write-Host "Directory=$Directory"
$Directory=(Resolve-Path -Path $Directory).Path
Write-Host "Directory=$Directory"

& cd $Directory

$sqlPackage=".\SqlPackage"
$tools=".\tools"


& cd $sqlPackage

# load package sma.tools.sqlpackage ==> Database\tools\SqlPackage\packages\SMA.Tools.SqlPackage.1.0.0
if(Test-Path -Path ".\packages") {
	#Remove-Item -Path ".\packages" -Recurse -Force -confirm:$false | Out-Null
}

try
{
	& nuget install -ConfigFile ".\nuget.config"
}
catch
{
}

& cd ..

# run cake script ==> deploy of database SPS_TariffService to local database
RemovegeneratedFilesFromTools

& ./build.ps1 -Target $Target
#Remove-Item -Path "$sqlPackage\packages" -Recurse -Force -confirm:$false | Out-Null

RemovegeneratedFilesFromTools


Write-Host -ForegroundColor Cyan ("Press any key to continue")
cmd /c pause | out-null

