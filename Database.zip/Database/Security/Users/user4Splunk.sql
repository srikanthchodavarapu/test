CREATE USER [user4Splunk] FOR LOGIN [PORTAL\SVC-Splunk];

