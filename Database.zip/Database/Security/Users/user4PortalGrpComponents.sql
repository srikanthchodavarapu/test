CREATE USER [user4PortalGrpTariffService] FOR LOGIN [PORTAL\GRP-SQL-I-TariffService];

