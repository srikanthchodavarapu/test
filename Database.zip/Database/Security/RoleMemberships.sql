
ALTER ROLE [db_executor] ADD MEMBER [user4PortalGrpTariffService];


GO
ALTER ROLE [db_datareader] ADD MEMBER [user4PortalGrpTariffService];

