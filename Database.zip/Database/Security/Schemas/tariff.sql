CREATE SCHEMA [tariff]
    AUTHORIZATION [dbo];
