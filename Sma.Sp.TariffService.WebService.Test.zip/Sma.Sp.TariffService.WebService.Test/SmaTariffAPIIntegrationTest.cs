using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sma.Sp.TariffService.Webservice.IntegrationTest;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using XUnit.Project.Attributes;
// Need to turn off test parallelization so we can validate the run order
[assembly: CollectionBehavior(DisableTestParallelization = true)]
[assembly: TestCollectionOrderer("XUnit.Project.Orderers.DisplayNameOrderer", "XUnit.Project")]

namespace XUnit.Project
{
	// Integration Test Class with XUnit For All API Endpoints ::
	public class SmaTariffAPIIntegrationTest
	{
		#region Test Order 
		[TestCaseOrderer("XUnit.Project.Orderers.PriorityOrderer", "XUnit.Project")]
		public class ByPriorityOrder
		{
			public static bool PostContractCalled;
			public static bool PostUnverifiedContractDataCalled;
			public static bool Test_GetContractsCalled;
			public static bool Test_GetProvidersCalled;
			public static bool Test_GetPricesCalled;
			public static bool Test_GetPricesSpecialCaseCalled;
			public static bool Test_GetPricesCO2SavingWithYearCalled;
			public static bool Test_GetPricesCO2SavingCalled;
			public static bool Test_ValidateMarketLocationCalled;
			public static bool Test_ValidateIbanCalled;


			[Collection("A Test Collection")]
			public class TestsInCollection1
			{
				public static bool Collection1Run;

				//Test call for POST /v1/contracts::

				[Theory, TestPriority(1)]
				[InlineData("8", "gustav.test@sma.de", "contractData.json", HttpStatusCode.OK)]
				public async Task PostContract(string userId, string userEmail, string fileName, HttpStatusCode expectedStatusCode)
				{
					PostContractCalled = true;

					string jsonPath = @fileName;
					var jsonString = File.ReadAllText(jsonPath);
					StringContent data = new StringContent(jsonString, Encoding.UTF8, "application/json");
					using (var client = new TestClientProvider().Client)
					{
						//Arrange
						client.DefaultRequestHeaders.Add("X-USERID", userId);
						client.DefaultRequestHeaders.Add("X-USEREMAIL", userEmail);
						//Act
						var response = await client.PostAsync("/v1/contracts", data);
						string result = await response.Content.ReadAsStringAsync();
						//Assert
						Assert.Equal(expectedStatusCode, response.StatusCode);
					}
				}


				// Test call for POST /v1/contracts/preliminaryContracts ::
				[Theory, TestPriority(2)]
				[InlineData("test", HttpStatusCode.OK)]
				public async Task PostUnverifiedContractData(string captchaValidationKey, HttpStatusCode expectedStatusCode)
				{
					PostUnverifiedContractDataCalled = true;

					string jsonPath = @"contractData.json";
					var jsonString = File.ReadAllText(jsonPath);
					StringContent data = new StringContent(jsonString, Encoding.UTF8, "application/json");
					using (var client = new TestClientProvider().Client)
					{
						//Act
						var response = await client.PostAsync("/v1/contracts/preliminaryContracts?captchaValidationKey=" + captchaValidationKey, data);
						string result = await response.Content.ReadAsStringAsync();
						//Assert
						Assert.Equal(expectedStatusCode, response.StatusCode);
					}
				}
			}

			// Test call for GET /v1/providers ::
			[Fact]
			public async Task Test_GetProviders()
			{
				Test_GetProvidersCalled = true;
				using (var client = new TestClientProvider().Client)
				{
					// Act
					var response = await client.GetAsync("/v1/providers");
					JArray jArr = (JArray)JsonConvert.DeserializeObject(await response.Content.ReadAsStringAsync());
					//Assert
					Assert.Equal(HttpStatusCode.OK, response.StatusCode);
					Assert.Equal(jArr.Count, 1876);
				}
			}

			// Test call for GET /v1/prices :
			[Theory]
			[InlineData("12435", 1000, HttpStatusCode.OK, 4)]
			[InlineData("95632", 1000, HttpStatusCode.OK, 2)]
			[InlineData("99999", 1000, HttpStatusCode.BadRequest, 2)]
			public async Task Test_GetPrices(string zipCode, int consumption, HttpStatusCode expectedStatusCode, int count)
			{
				Test_GetPricesCalled = true;
				using (var client = new TestClientProvider().Client)
				{
					// Act
					var response = await client.GetAsync("/v1/prices?zipCode=" + zipCode + "&consumption=" + consumption);
					JObject jObj = (JObject)JsonConvert.DeserializeObject(await response.Content.ReadAsStringAsync());
					//Assert
					Assert.Equal(expectedStatusCode, response.StatusCode);
					Assert.Equal(count, jObj.Count);
				}
			}

			// Test call for GET /v1/prices with (Special ZIP code case)::
			[Theory]
			[InlineData("95632", 1000, "Wunsiedel", HttpStatusCode.OK, 4)]
			[InlineData("95632", 1000, "Tokyo", HttpStatusCode.BadRequest, 2)]
			public async Task Test_GetPricesSpecialCase(string zipCode, int consumption, string city, HttpStatusCode expectedStatusCode, int count)
			{
				Test_GetPricesSpecialCaseCalled = true;
				using (var client = new TestClientProvider().Client)
				{
					// Act
					var response = await client.GetAsync("/v1/prices?zipCode=" + zipCode + "&consumption=" + consumption + "&city=" + city);
					JObject jObj = (JObject)JsonConvert.DeserializeObject(await response.Content.ReadAsStringAsync());
					//Assert
					Assert.Equal(expectedStatusCode, response.StatusCode);
					Assert.Equal(count, jObj.Count);
				}
			}

			// Test call for GET /v1/prices/co2Avoidance ( with Year )::
			[Theory]
			[InlineData(1000, 2014, HttpStatusCode.BadRequest, 2)]
			[InlineData(1000, 2021, HttpStatusCode.OK, 1)]
			public async Task Test_GetPricesCO2SavingWithYear(int consumption, int year, HttpStatusCode expectedStatusCode, int count)
			{
				Test_GetPricesCO2SavingWithYearCalled = true;
				using (var client = new TestClientProvider().Client)
				{
					// Act
					var response = await client.GetAsync("/v1/prices/co2Avoidance?consumption=" + consumption + "&year=" + year);
					JObject jObj = (JObject)JsonConvert.DeserializeObject(await response.Content.ReadAsStringAsync());
					//Assert
					Assert.Equal(expectedStatusCode, response.StatusCode);
					Assert.Equal(count, jObj.Count);
				}
			}

			// Test call for GET /v1/prices/co2Avoidance ( without Year )::
			[Theory]
			[InlineData(1000, HttpStatusCode.OK, 1)]
			[InlineData(10000000000, HttpStatusCode.BadRequest, 2)]
			public async Task Test_GetPricesCO2Saving(long consumption, HttpStatusCode expectedStatusCode, int count)
			{
				Test_GetPricesCO2SavingCalled = true;
				using (var client = new TestClientProvider().Client)
				{
					// Act
					var response = await client.GetAsync("/v1/prices/co2Avoidance?consumption=" + consumption);
					JObject jObj = (JObject)JsonConvert.DeserializeObject(await response.Content.ReadAsStringAsync());
					//Assert
					Assert.Equal(expectedStatusCode, response.StatusCode);
					Assert.Equal(count, jObj.Count);
				}
			}

			// Test call for GET /v1/contracts" ::
			[Theory, TestPriority(3)]
			[InlineData("8", "gustav.test@sma.de", HttpStatusCode.OK)]
			[InlineData("0", "gustav.test@sma.de", HttpStatusCode.NotFound)]
			public async Task Test_GetContracts(string userId, string userEmail, HttpStatusCode expectedStatusCode)
			{
				Test_GetContractsCalled = true;
				using (var client = new TestClientProvider().Client)
				{
					//Arrange
					client.DefaultRequestHeaders.Add("X-USERID", userId);
					client.DefaultRequestHeaders.Add("X-USEREMAIL", userEmail);
					// Act
					var response = await client.GetAsync("/contracts");
					//Assert
					Assert.Equal(expectedStatusCode, response.StatusCode);
				}
			}

			// Test call for GET /v1/validateMarketLocation ::
			[Theory]
			[InlineData("12345678905", HttpStatusCode.OK)]
			[InlineData("12345678901", HttpStatusCode.OK)]
			[InlineData("12345678", HttpStatusCode.OK)]
			public async Task Test_ValidateMarketLocation(string marketLocation, HttpStatusCode expectedStatusCode)
			{
				Test_ValidateMarketLocationCalled = true;
				using (var client = new TestClientProvider().Client)
				{
					// Act
					var response = await client.GetAsync("/v1/validateMarketLocation?marketLocation=" + marketLocation);

					//Assert
					Assert.Equal(expectedStatusCode, response.StatusCode);
				}
			}

			// Test call for GET /v1/validateIban ::
			[Theory]
			[InlineData("DE89 3704 0044 0532 0130 00", HttpStatusCode.NoContent)]
			[InlineData("DE89 3704 0044 0532 0130 0", HttpStatusCode.BadRequest)]
			public async Task Test_ValidateIban(string iban, HttpStatusCode expectedStatusCode)
			{
				Test_ValidateIbanCalled = true;
				using (var client = new TestClientProvider().Client)
				{
					// Act
					var response = await client.GetAsync("/v1/validateIban?iban=" + iban);

					//Assert
					Assert.Equal(expectedStatusCode, response.StatusCode);
				}
			}
		}
		#endregion

	}
}