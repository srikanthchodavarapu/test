﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Sma.Sp.TariffService.Web.Service;
using Microsoft.Extensions.Configuration;
using System.IO;
using System;

namespace Sma.Sp.TariffService.Webservice.IntegrationTest
{
	// Test Client Provider Class used for XUNIT Tests
	public class TestClientProvider : IDisposable
	{
		private TestServer server;
		public System.Net.Http.HttpClient Client { get; private set; }

		// Default Constructor
		public TestClientProvider()
		{
			string curDir = Directory.GetCurrentDirectory();

			var builder = new ConfigurationBuilder()
				.SetBasePath(curDir)
				.AddJsonFile("appsettings.json");

			var webBuilder = new WebHostBuilder()
				.UseContentRoot(curDir).UseConfiguration(builder.Build())
				.UseStartup<Startup>();

			server = new TestServer(webBuilder);

			Client = server.CreateClient();
		}

		//Dispose Method
		public void Dispose()
		{
			server?.Dispose();
			Client?.Dispose();
		}
	}
}
