namespace Sma.Sp.TariffService.Api.Interfaces.Tariff
{
    // Get and Set the Address Object for Requested Address  with properties called country,city,zipcode, street, streetno,phoneno
    /// <summary>
    /// Address object
    /// </summary>
    public class RequestAddressObject
    {
        public string Country { get; set; }

        public string City { get; set; }

        public string ZipCode { get; set; }

        public string Street { get; set; }

        public string StreetNo { get; set; }

        public string PhoneNumber { get; set; }

    }
}