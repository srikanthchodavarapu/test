
using System.ComponentModel.DataAnnotations;

namespace Sma.Sp.TariffService.Api.Interfaces.Tariff
{  //  Get and Set the  Object for RequestUnverifiedSavingUserObject Get and Set the RequestUnverifiedSavingUserObject Object for Requested RequestUnverifiedSavingUserObject  with properties called email,password,firstname, lastname and etc listed in model class for the object
    /// <summary>
    /// Request object for using in Unverified saving API
    /// </summary>
    public class RequestUnverifiedSavingsObject
    {
        /// <summary>
        /// User information
        /// </summary>
        [Required]
        public RequestUnverifiedSavingUserObject User { get; set; }
        
        /// <summary>
        /// Contract information
        /// </summary>
        [Required]
        public RequestContractObject Contract { get; set; }
    }
}