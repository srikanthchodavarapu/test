using System;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Sma.Sp.TariffService.Api.Interfaces.Tariff
{
    // TODO: JW: Minor: Think about splitting this object to set consistent things together.
    // Get and Set the business Object for Requested business  with properties called IsBusiness,IsSmallBusiness .etc listed below .
    public class RequestContractObject
    {
           /// <summary>
        /// true if consumer is a business customer, else false
        /// </summary>
        [Required]
        public bool IsBusiness { get; set; }

        /// <summary>
        /// [optional]: wheter the contract belongs to an small busnes customer
        /// </summary>
        public bool IsSmallBusiness { get; set; }

        /// <summary>
        /// (mandatory for companies)
        /// </summary>
        [StringLength(255)]
        public string CompanyName { get; set; }

        /// <summary>
        /// „Herr“, „Frau“, or "Eheleute". See also first_name below.
        /// </summary>
        [Required]        
        [StringLength(255)]
        public string Salutation { get; set; }

        /// <summary>
        /// [optional]: „Dr.“, „Prof.“, „Prof. Dr.“. This is not used if the salutation is "Eheleute".
        /// </summary>
        [StringLength(50)]
        public string Title { get; set; }

        /// <summary>
        /// first name of the consumer (or contact for companies). If salutation is "Eheleute" the first name should contain both first names like "Hans und Erika".
        /// </summary>
        [Required]
        [StringLength(255)]
        public string FirstName { get; set; }

        /// <summary>
        /// last name of the consumer (or contact for companies)
        /// </summary>
        [Required]
        [StringLength(255)]
        public string LastName { get; set; }

        /// <summary>
        /// [optional]: the birthday date.(default format: yyyy-MM-dd)
        /// </summary>
        public DateTime? Birthday { get; set; }

        /// <summary>
        /// [optional]: telephone number
        /// </summary>
        [StringLength(20)]
        public string Telephone { get; set; }

        /// <summary>
        /// a contact email address (for sending bills and confirmations)
        /// </summary>
        [Required]
        [StringLength(255)]
        public string Email { get; set; }

        /// <summary>
        /// [optional]: if given the emails will be sent to this email adress
        /// </summary>
        [StringLength(255)]
        public string AccountingEmail { get; set; }

        /// <summary>
        /// [optional]: (max. 30 characters) a username for registered user (needs to login in frontend)
        /// </summary>
        [StringLength(255)]
        public string Username { get; set; }

        /// <summary>
        /// delivery address street
        /// </summary>
        [Required]
        [StringLength(255)]
        public string DelivAddressStreet { get; set; }

        /// <summary>
        /// delivery address house number
        /// </summary>
        [Required]
        [StringLength(10)]
        public string DelivAddressHouseNumber { get; set; }

        /// <summary>
        /// delivery address zipcode
        /// </summary>
        [Required]
        [StringLength(20)]
        // TODO: JW: Minor: Deliv -> Delivery
        public string DelivAddressZipcode { get; set; }

        /// <summary>
        /// delivery address city
        /// </summary>
        [Required]
        [StringLength(255)]
        public string DelivAddressCity { get; set; }

        /// <summary>
        /// [optional]: additions to the delivery address
        /// </summary>
        [StringLength(255)]
        public string DelivAddressAddition { get; set; }

        /// <summary>
        /// [optional]: the preferred delivery start if requested by the customer. This date has to lie two weeks in the future if the subscription_reason is "E03" and up to six weeks in the past if the reason is "E01" or "E02"
        /// </summary>
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? PreferredDeliveryStart { get; set; }

        /// <summary>
        /// [optional]: if empty, we use the delivery address information
        /// </summary>
        [StringLength(255)]
        public string BillAddressStreet { get; set; }

        /// <summary>
        /// [optional]: if empty, we use the delivery address information
        /// </summary>
        [StringLength(255)]
        public string BillAddressHouseNumber { get; set; }

        /// <summary>
        /// [optional]: if empty, we use the delivery address information
        /// </summary>
        [StringLength(20)]
        public string BillAddressZipcode { get; set; }

        /// <summary>
        /// [optional]: if empty, we use the delivery address information
        /// </summary>
        [StringLength(255)]
        public string BillAddressCity { get; set; }

        /// <summary>
        /// [optional] 
        /// </summary>
        [StringLength(255)]
        public string BillAddressAddition { get; set; }

        /// <summary>
        /// 'E01' for Ein-/Auszug (Umzug) (move into location),
        /// 'E02' for Einzug/Neuanlage(new site),
        /// 'E03' for Wechsel(change of provider)
        /// </summary>
        [Required]
        [StringLength(20)]
        public string SubscriptionReason { get; set; }

        /// <summary>
        /// the identification number for the meter
        /// </summary>
        [Required]
        [StringLength(20)]
        public string MeterId { get; set; }

        /// <summary>
        /// [optional]: either a default value is set as derived from the meter data or a project specifically defined value is used. (NOT IMPLEMENTED YET)
        /// </summary>
        [StringLength(255)]
        public string MeterRole { get; set; }

        /// <summary>
        /// [optional]: the market location (Marktlokation) identification number (legay name for backward compatibility)
        /// </summary>
        [StringLength(20)]
        public string MeteringPointId { get; set; }

        /// <summary>
        /// this should be already the Marketpartner ID of the „Alt-Lieferant". IDs are managed by BDEW [optiona l if subscription_reason is "E01" or "E02"]
        /// </summary>
        public string PreviousProvider { get; set; }

        /// <summary>
        /// the yearly consumption as indicated on the latest year end bill of the customer.
        /// </summary>
        [Required]
        [StringLength(255)]
        public string AnnualConsumption { get; set; }

        /// <summary>
        /// [optional]: owner of the account. This field may be empty for corporate customers.
        /// </summary>
        [StringLength(255)]
        public string BankDataFirstName { get; set; }

        /// <summary>
        /// owner of the account
        /// </summary>
        [Required]
        [StringLength(255)]
        public string BankDataLastName { get; set; }

        /// <summary>
        /// the IBAN (is validated during the process)
        /// </summary>
        [Required]
        [StringLength(255)]
        public string BankDataIban { get; set; }

        /// <summary>
        /// [optional]: (new in version 3.4) direct_debit or bank_transfer; defaults to direct_debit (new in version 3.4).
        /// </summary>
        public enum PaymentMethodType
        {
            direct_debit = 0,
            bank_transfer = 1
        }

        [JsonConverter(typeof(JsonStringEnumConverter))]
        public PaymentMethodType PaymentMethod 
        { 
            get; 
            set;
        }

        /// <summary>
        /// [optional]: required if no payment_method is set or direct_debit is selected as payment_method (new in version 3.4). The date on which the SEPA reference form has been signed by the customer or the date of the online contract.
        /// </summary>
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? SepaDateUtc { get; set; }

        /// <summary>
        /// [optional]: the SEPA reference.
        /// </summary>
        [StringLength(255)]
        public string SepaReference { get; set; }

        /// <summary>
        /// the type of tariff (values: defined by Lumenaza)
        /// </summary>
        public string TariffType 
        {
            get { return this.IsBusiness ? "sma_community_strom_gewerbe" : "sma_community_strom"; }
        }

        /// <summary>
        /// [optional]: In case of using a flat tariff this is the overall consumption (in kWh) before sign the contract (DEPRECATED, moved to product specifics).
        /// </summary>
        [StringLength(255)]
        public string ConsumptionBeforeBatteryInstallation { get; set; }

        /// <summary>
        /// [optional]: the date of contract for signature
        /// </summary>
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? OrderDate 
        { 
            get { return DateTime.UtcNow; }
        }

        /// <summary>
        /// [optional]: the first name from customer of former supplier contract
        /// </summary>
        [StringLength(255)]
        public string FormerSupplierFirstName { get; set; }

        /// <summary>
        /// [optional]: the last name from customer of former supplier contract
        /// </summary>
        [StringLength(255)]
        public string FormerSupplierLastName { get; set; }

        /// <summary>
        /// [optional, default is false]: if former supplier contract is terminated by customer set to true (if false Lumenaza is terminating the customers contract)
        /// </summary>
        [StringLength(255)]
        public string FormerSupplierContractTerminated { get; set; }

        /// <summary>
        /// [optional]: the date when customer terminates its contract (if former_supplier_c ontract_termination_date is set to true the field is mandatory)
        /// </summary>
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? FormerSupplierContractTerminationDate { get; set; }

        /// <summary>
        /// [optional]: (max length=13) the tax number for this contract
        /// </summary>
        [StringLength(255)]
        public string TaxNumber { get; set; }
    }
}