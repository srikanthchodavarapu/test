using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Api.Interfaces.Tariff
{
    //Get and Set the fields for  RequestUserObject like UserId,Email,Title,Lastname and etc to bind with the RequestUserObject Object class.
    /// <summary>
    /// RequestUserObject
    /// </summary>
    public class RequestUserObject
    {
        [Required]
        [MaxLength(255)]
        public string UserId { get; set; }
        public string Email { get; set; }
        
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Culture { get; set; }

        public RequestAddressObject Address { get; set; }
    }
}