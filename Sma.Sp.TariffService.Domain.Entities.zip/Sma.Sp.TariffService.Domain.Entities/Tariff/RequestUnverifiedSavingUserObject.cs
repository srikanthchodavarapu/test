using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Api.Interfaces.Tariff
{ // Get and Set the fields for  RequestUnverifiedSavingUserObject like Email,Password and etc to bind with the Object
    /// <summary>
    /// RequestUserObject
    /// </summary>
    public class RequestUnverifiedSavingUserObject
    {
        [Required]
        public string Email { get; set; }
        
        [Required]
        public string Password { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Culture { get; set; }

        public RequestAddressObject Address { get; set; }
    }
}