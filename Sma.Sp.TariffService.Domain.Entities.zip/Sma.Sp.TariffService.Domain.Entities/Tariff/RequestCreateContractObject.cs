using System.ComponentModel.DataAnnotations;

namespace Sma.Sp.TariffService.Api.Interfaces.Tariff
{
    /// <summary>
    /// Create contract object is used by CreateController
    /// </summary>
    public class RequestCreateContractObject
    {
        // Get and Set the user Object for Requested user  with all user  properties like  UserId,email,Title,and etc listed in User Model class.
        /// <summary>
        /// User information
        /// </summary>
        [Required]
        public RequestUserObject User { get; set; }

        /// <summary>
        /// Contract information
        /// </summary>
        [Required]
        public RequestContractObject Contract { get; set; }
    }
}