﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.ConsumersObject;
using Sma.Sp.TariffService.Domain.Entities.SMAUser;

namespace Sma.Sp.TariffService.Api.Interfaces.Tariff.Models
{
    /// <summary>
    /// A request object for create a new contract with unverified user
    /// </summary>
    public class RequestConsumerUnverifiedObject
    {
        [Required]
        [JsonProperty("user")]
        public UnverifiedUserObject User { get; set; }

        [Required]
        [JsonProperty("contract")]
        public LumenazaConsumersRequestObject Contract { get; set; }
    }
}
