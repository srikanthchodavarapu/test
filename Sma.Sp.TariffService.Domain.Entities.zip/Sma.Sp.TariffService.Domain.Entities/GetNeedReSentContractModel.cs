namespace Sma.Sp.TariffService.Domain.Entities
{   // PreliminaryContractModel is having properties for Get ;Set ; the data and  the fields are of
    // type list and object which has predefined model where properties of the objects are declare for get;set
    public class PreliminaryContractModel
    {
        public ContractMasterData Master { get; set; }
        public ContractEntity Entity { get; set; }
        public ContractAddress BillAddress { get; set; }
        public ContractAddress DeliveryAddress { get; set; }
        public ContractData Data { get; set; }
        public ContractBankData BankData { get; set; }
    }
}