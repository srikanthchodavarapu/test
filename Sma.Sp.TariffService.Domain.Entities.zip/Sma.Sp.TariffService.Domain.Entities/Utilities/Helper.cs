﻿using System.Linq;
using Newtonsoft.Json.Linq;
using System.Text.RegularExpressions;

namespace Sma.Sp.TariffService.Domain.Entities.Utilities
{
	public static class Helper
    {
        /// <summary>
        /// renames all keys to comply to camelCase
        /// </summary>
        /// <param name="inputObj">Object retrieved from await response.Content.ReadAsAsync<object>(); </param>
        /// <returns>JObject with renamed keys</returns> 
        public static JObject RenameKeysToCamelCase(object inputObj)
        {
            JObject inputJson = JObject.Parse(inputObj.ToString());
            JObject tempJson = new JObject();

            foreach (var item in inputJson)
            {
                string camelKey = System.Text.RegularExpressions.Regex.Replace(item.Key, @"(_.)", delegate (Match match)
                {
                    string v = match.ToString();
                    return "" + char.ToUpper(v[1]);
                });

                if (item.Value is JValue)
                {
                    tempJson.Add(camelKey, item.Value);
                }
                else if (item.Value is JArray)
                {
                    if (item.Value.Count() == 0 || item.Value[0] is JValue)
                    {
                        tempJson.Add(camelKey, item.Value);
                    }
                    else
                    {
                        tempJson.Add(camelKey, RenameKeysToCamelCase(item.Value[0]));
                    }
                }
                else if (item.Value is JObject)
                {
                    tempJson.Add(camelKey, RenameKeysToCamelCase(item.Value));
                }
            }

            return tempJson;
        }
    }
}
