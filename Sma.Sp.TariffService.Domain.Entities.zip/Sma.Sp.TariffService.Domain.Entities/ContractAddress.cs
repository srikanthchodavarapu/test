﻿using System.Collections.Generic;

namespace Sma.Sp.TariffService.Domain.Entities
{/*class is having a constructor inside which having virtual variables
 ContractDataBillingAddress,ContractDataDeliveryAddress of type collection ,and some
 other properites for Get and Set the fields in the class  */
    public class ContractAddress
    {
        public ContractAddress()
        {
            ContractDataBillingAddress = new HashSet<ContractData>();
            ContractDataDeliveryAddress = new HashSet<ContractData>();
        }

        // TODO: JW: Minor: Properties of Domain Entities should only be SETable via the constructor.
        public int Id { get; set; }
        public string Street { get; set; }
        public string HouseNumber { get; set; }
        public string Zipcode { get; set; }
        public string City { get; set; }
        public string Addition { get; set; }

        public virtual ICollection<ContractData> ContractDataBillingAddress { get; set; }
        public virtual ICollection<ContractData> ContractDataDeliveryAddress { get; set; }
    }
}
