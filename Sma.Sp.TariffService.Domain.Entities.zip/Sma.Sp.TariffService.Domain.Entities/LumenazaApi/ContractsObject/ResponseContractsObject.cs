﻿using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Domain.Entities.LumenazaApi.ContractObject
{
    public class ResponseContractsObject
    {
        [JsonProperty("consumer_id")]
        public string ConsumerId { get; set; }

        [JsonProperty("contract_id")]
        public string ContractId { get; set; }
    }
}
