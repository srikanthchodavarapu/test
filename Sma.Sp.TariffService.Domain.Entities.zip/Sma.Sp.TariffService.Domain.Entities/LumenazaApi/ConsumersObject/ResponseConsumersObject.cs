﻿using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Domain.Entities.LumenazaApi.ConsumersObject
{   //Getting and setting Up the properties for ConsumerId, contractId .
    public class ResponseConsumersObject
    {
        [JsonProperty("consumerId")]
        public string ConsumerId { get; set; }

        [JsonProperty("contractId")]
        public string ContractId { get; set; } 
    }
}
