﻿using Newtonsoft.Json;
using Sma.Sp.TariffService.Domain.Services;
using System;
using System.ComponentModel.DataAnnotations;

namespace Sma.Sp.TariffService.Domain.Entities.LumenazaApi.ConsumersObject
{
    // Object used for transformation to Lumenaza's POST Consumers Object
    // JW: I like the comments / descriptions for each property :-)
    public class LumenazaConsumersRequestObject
    {
        // TODO: JW: Minor #PascalCase: Styleguide: Use PascalCase for properties (the JSON contract resolver 'CamelCasePropertyNamesContractResolver' in Startup.cs will make it CamelCase.
        /// <summary>
        /// true if consumer is a business customer, else false
        /// </summary>
        [Required]
        public bool is_business { get; set; }

        /// <summary>
        /// [optional]: wheter the contract belongs to an small busnes customer
        /// </summary>
        // TODO: JW: Minor: see #PascalCase:
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public bool is_small_business { get; set; }

        /// <summary>
        /// (mandatory for companies)
        /// </summary>
        [StringLength(255)]
        //TODO: JW: Minor: Prefer central configuration of json field handling. Use 'options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore' in startup to omit null properties.
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string company_name { get; set; }

        /// <summary>
        /// „Herr“, „Frau“, or "Eheleute". See also first_name below.
        /// </summary>
        [Required]
        [StringLength(255)]
        public string salutation { get; set; }

        /// <summary>
        /// [optional]: „Dr.“, „Prof.“, „Prof. Dr.“. This is not used if the salutation is "Eheleute".
        /// </summary>
        [StringLength(50)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string title { get; set; }

        /// <summary>
        /// first name of the consumer (or contact for companies). If salutation is "Eheleute" the first name should contain both first names like "Hans und Erika".
        /// </summary>
        [Required]
        [StringLength(255)]
        public string first_name { get; set; }

        /// <summary>
        /// last name of the consumer (or contact for companies)
        /// </summary>
        [Required]
        [StringLength(255)]
        public string last_name { get; set; }

        /// <summary>
        /// [optional]: the birthday date.(default format: yyyy-MM-dd)
        /// </summary>
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        //TODO: JW: Remark: If this format shall generally be used, prefer setting the JSON option: 'options.SerializerSettings.DateFormatString' in Startup.cs
        [JsonConverter(typeof(CustomDateTimeJsonConverter))] 
        public DateTime? birthday { get; set; }

        /// <summary>
        /// [optional]: telephone number
        /// </summary>
        [StringLength(20)]
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string telephone { get; set; }

        /// <summary>
        /// a contact email address (for sending bills and confirmations)
        /// </summary>
        [Required]
        [StringLength(255)]
        public string email { get; set; }

        /// <summary>
        /// [optional]: if given the emails will be sent to this email adress
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string accounting_email { get; set; }

        /// <summary>
        /// [optional]: (max. 30 characters) a username for registered user (needs to login in frontend)
        /// </summary>
        [StringLength(30)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string username { get; set; }

        /// <summary>
        /// delivery address street
        /// </summary>
        [Required]
        [StringLength(2000)]
        public string deliv_address_street { get; set; }

        /// <summary>
        /// delivery address house number
        /// </summary>
        [Required]
        [StringLength(255)]
        public string deliv_address_house_number { get; set; }

        /// <summary>
        /// delivery address zipcode
        /// </summary>
        [Required]
        [StringLength(20)]
        public string deliv_address_zipcode { get; set; }

        /// <summary>
        /// delivery address city
        /// </summary>
        [Required]
        [StringLength(255)]
        public string deliv_address_city { get; set; }

        /// <summary>
        /// [optional]: additions to the delivery address
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string deliv_address_addition { get; set; }

        /// <summary>
        /// [optional]: the preferred delivery start if requested by the customer. This date has to lie two weeks in the future if the subscription_reason is "E03" and up to six weeks in the past if the reason is "E01" or "E02"
        /// </summary>
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        [JsonConverter(typeof(CustomDateTimeJsonConverter))]
        public DateTime? preferred_delivery_start { get; set; }

        /// <summary>
        /// [optional]: if empty, we use the delivery address information
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string bill_address_street { get; set; }

        /// <summary>
        /// [optional]: if empty, we use the delivery address information
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string bill_address_house_number { get; set; }

        /// <summary>
        /// [optional]: if empty, we use the delivery address information
        /// </summary>
        [StringLength(20)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string bill_address_zipcode { get; set; }

        /// <summary>
        /// [optional]: if empty, we use the delivery address information
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string bill_address_city { get; set; }

        /// <summary>
        /// [optional] 
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string bill_address_addition { get; set; }

        /// <summary>
        /// 'E01' for Ein-/Auszug (Umzug) (move into location),
        /// 'E02' for Einzug/Neuanlage(new site),
        /// 'E03' for Wechsel(change of provider)
        /// </summary>
        [Required]
        [StringLength(20)]
        public string subscription_reason { get; set; }

        /// <summary>
        /// the identification number for the meter
        /// </summary>
        [Required]
        [StringLength(20)]
        public string meter_id { get; set; }

        /// <summary>
        /// [optional]: either a default value is set as derived from the meter data or a project specifically defined value is used. (NOT IMPLEMENTED YET)
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string meter_role { get; set; }

        /// <summary>
        /// [optional]: the market location (Marktlokation) identification number (legay name for backward compatibility)
        /// </summary>
        [StringLength(20)]
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string meteringpoint_id { get; set; }

        /// <summary>
        /// this should be already the Marketpartner ID of the „Alt-Lieferant". IDs are managed by BDEW [optiona l if subscription_reason is "E01" or "E02"]
        /// </summary>
       [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string previous_provider { get; set; }

        /// <summary>
        /// the yearly consumption as indicated on the latest year end bill of the customer.
        /// </summary>
        [Required]
        [StringLength(255)]
        public string annual_consumption { get; set; }

        /// <summary>
        /// [optional]: owner of the account. This field may be empty for corporate customers.
        /// </summary>
        [StringLength(255)]
        public string bank_data_first_name { get; set; }

        /// <summary>
        /// owner of the account
        /// </summary>
        [Required]
        [StringLength(255)]
        public string bank_data_last_name { get; set; }

        /// <summary>
        /// the IBAN (is validated during the process)
        /// </summary>
        [Required]
        [StringLength(255)]
        public string bank_data_iban { get; set; }

        /// <summary>
        /// [optional]: (new in version 3.4) direct_debit or bank_transfer; defaults to direct_debit (new in version 3.4).
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string payment_method { get; set; }

        /// <summary>
        /// [optional]: required if no payment_method is set or direct_debit is selected as payment_method (new in version 3.4). The date on which the SEPA reference form has been signed by the customer or the date of the online contract.
        /// </summary>
        /// 
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        [JsonConverter(typeof(CustomDateTimeJsonConverter))]
        public DateTime? sepa_date { get; set; }

        /// <summary>
        /// [optional]: the SEPA reference.
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string sepa_reference { get; set; }

        /// <summary>
        /// the type of tariff (values: defined by Lumenaza)
        /// </summary>
        [Required]
        [StringLength(255)]
        public string tariff_type { get; set; }

        /// <summary>
        /// [optional]: if value is given it will be saved as contract id else Lumenaza will create a contract id.
        /// </summary>
        [StringLength(20)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string saas_customer_id { get; set; }

        /// <summary>
        ///  [optional]: if value is given it will be saved as contract id else Lumenaza will create a contract id.
        /// </summary>
        [StringLength(20)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string saas_contract_id { get; set; }

        /// <summary>
        /// [optional]: In case of using salespartner hierarchy this ID identifies the sub salespartner.
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string third_party_salespartner { get; set; }

        /// <summary>
        /// [optional]: In case of using a flat tariff this is the overall consumption (in kWh) before sign the contract (DEPRECATED, moved to product specifics).
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string consumption_before_battery_installation { get; set; }

        /// <summary>
        /// [optional]: the date of contract for signature
        /// </summary>
        ///
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        [JsonConverter(typeof(CustomDateTimeJsonConverter))]
        //TODO: JW: Minor: This should be saved in UTC. Prefer Suffixing the property with "xxxUtc" then.
        public DateTime? order_date { get; set; }

        /// <summary>
        /// [optional]: the first name from customer of former supplier contract
        /// TODO: JW: Minor: Naming the property 'FormerCustomerFirstName' or similar would fit better (Most people will use supplier and provider interchangeably).
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string former_supplier_first_name { get; set; }

        /// <summary>
        /// [optional]: the last name from customer of former supplier contract
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string former_supplier_last_name { get; set; }

        /// <summary>
        /// [optional, default is false]: if former supplier contract is terminated by customer set to true (if false Lumenaza is terminating the customers contract)
        /// </summary>
        [StringLength(255)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public bool former_supplier_contract_terminated { get; set; }

        /// <summary>
        /// [optional]: the date when customer terminates its contract (if former_supplier_c ontract_termination_date is set to true the field is mandatory)
        /// </summary>
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        [JsonConverter(typeof(CustomDateTimeJsonConverter))]
        public DateTime? former_supplier_contract_termination_date { get; set; }

        /// <summary>
        /// [optional]: (max length=13) the tax number for this contract
        /// </summary>
        [MaxLength(13)]
        [JsonProperty(NullValueHandling=NullValueHandling.Ignore)]
        public string tax_number { get; set; }
    }
}