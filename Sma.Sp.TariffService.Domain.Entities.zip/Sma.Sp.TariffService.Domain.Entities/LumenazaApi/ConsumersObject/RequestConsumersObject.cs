﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Net.Http;
using System.Reflection;
using Newtonsoft.Json;
using Sma.Sp.TariffService.Domain.Entities.SMAUser;

namespace Sma.Sp.TariffService.Domain.Entities.LumenazaApi.ConsumersObject
{
    //Getting and Setting User Object having UserId, Title,firstname and etc.. while returning data from JSON  
    public class RequestConsumersObject
    {
        [Required]
        [JsonProperty("user")]
        public UserObject User { get; set; }

        //Getting and Setting ConsumersObject Object having is_business, isSmall_business, and other properties etc.. while returning data from JSON  
        [Required]
        [JsonProperty("contract")]
        public LumenazaConsumersRequestObject Contract { get; set; }
    }
}
