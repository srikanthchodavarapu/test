﻿using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Domain.Entities.LumenazaApi.PriceObject
{ //Getting and Setting the Properties in the  for the Costs class as per defined Like CostPerUnitNetto,DisplayName,Name,unit. 
    public class Costs
    {
        // TODO: JW: Minor: prefer using camelCase for JSON properties (was actually used in the other classes).
        [JsonProperty("cost_per_unit_netto")]
        public float CostPerUnitNetto { get; set; } 

        [JsonProperty("display_name")]
        public string DisplayName { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("unit")]
        public string Unit { get; set; }
    }
}