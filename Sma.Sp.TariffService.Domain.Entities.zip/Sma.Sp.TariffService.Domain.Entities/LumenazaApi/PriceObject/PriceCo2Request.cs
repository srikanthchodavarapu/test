﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Domain.Entities.LumenazaApi.PriceObject
{
    /// <summary>
    /// PriceO2Request
    /// </summary>
    public class PriceCo2Request
    {
        //Getting and Setting Properties for ther class PriceCo2Request like consumption,year.
        [Required]
        public float consumption { get; set; }
        public int year { get; set; } 
    }
}
