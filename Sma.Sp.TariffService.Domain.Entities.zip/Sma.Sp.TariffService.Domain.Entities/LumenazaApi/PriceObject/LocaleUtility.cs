﻿using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Domain.Entities.LumenazaApi.PriceObject
{ //Getting and setting properties for LocaleUtility class , like localutilityName,LocalUtilityYearPrice
    public class LocaleUtility
    {
        [JsonProperty("locatUtilityName")]
        public string LocatUtilityName { get; set; }
   
        [JsonProperty("localUtilityYearPrice")]
        public float LocalUtilityYearPrice { get; set; } 

    }
}