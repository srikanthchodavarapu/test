﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using Sma.Sp.TariffService.Domain.Entities.Dtos;

namespace Sma.Sp.TariffService.Domain.Entities.LumenazaApi.PriceObject
{
    public class PriceResponse
    {
        [JsonProperty("consumption")]
        public int consumption { get; set; }

        [JsonProperty("isBusiness")]
        public bool isBusiness { get; set; }

        [JsonProperty("tariffs")]
        public TariffDTO tariffs { get; set; }

        [JsonProperty("localeUtility")]
        public LocaleUtility localeUtility { get; set; }
    }
}
