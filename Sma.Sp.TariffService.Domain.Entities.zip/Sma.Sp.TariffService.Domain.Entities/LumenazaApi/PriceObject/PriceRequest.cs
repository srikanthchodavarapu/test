﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Domain.Entities.LumenazaApi.PriceObject
{
    public class PriceRequest
    {    //Getting and Setting Properties for the class price request like zipcode,consumption  etc..
        /// <summary>
        /// the zipcode for the calculated price
        /// </summary>
        [Required]
        [JsonProperty("zipcode")]
        public string zipcode { get; set; } 

        /// <summary>
        /// the customer's annual consumption (needs to be positive)
        /// </summary>
        [Required]
        [JsonProperty("consumption")]
        public int consumption { get; set; }

        /// <summary>
        /// the type of tariff (values: defined by Lumenaza)
        ///  TODO: JW: Minor: since this is business logic, this logic should be placed in the domain services (or domain entities).
        /// </summary>
        [StringLength(255)]
        public string tariffType
        {
            get { return this.isBusiness ? "sma_community_strom_gewerbe" : "sma_community_strom"; }
        }

        /// <summary>
        /// business or private tariff
        /// </summary>
        [JsonProperty("is_business")]
        public bool isBusiness { get; set; }

        /// <summary>
        /// [optional, default=false]: if set to true the 300 Multiple Choices Response delivers street/city combinations (not city/district)
        /// </summary>
        [JsonProperty("deliver_streets")]
        public bool deliverStreets { get; set; } = true;

        //JW: I like the documentation of this one - very helpful!
        /// <summary>
        /// [optional, default=0.6]: the part of high tariff consumption in range [0,1]. This is for products where a time-dependent pricing is foreseen (in Germany two price per day with time slots defined by the DSO).
        /// </summary>
        [JsonProperty("ht_consumption_part")]
        public float htConsumptionPart { get; set; }

        /// <summary>
        /// [optional]: street of delivery point
        /// </summary>
        [JsonProperty("street")]
        public string street { get; set; }

        /// <summary>
        /// [optional]: house number of delivery point
        /// </summary>
        [JsonProperty("house_number")]
        public string houseNumber { get; set; }

        /// <summary>
        /// [optional]: city of delivery point
        /// </summary>
        [JsonProperty("city")]
        public string city { get; set; }
    }
}