﻿using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Domain.Entities.PriceObject
{
    /// <summary>
    /// CO2 Saving object
    /// </summary>
    public class Co2Saving
    {   //this class is used to set and get SavedCO2;
        //TODO: JW: Remark: I appreciate that your using value objects. Generally, a simple float here would have been sufficient.

        //TODO: JW: Minor: Prefer appending the Unit (and here maybe also the time range) in the property name (e.g. AnnualSaveCo2Kg)
        [JsonProperty("savedCo2")]
        public float SavedCO2 { get; set; } 
    }
}
