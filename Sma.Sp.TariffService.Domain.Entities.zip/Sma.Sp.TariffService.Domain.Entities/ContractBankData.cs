﻿using System;
using System.Collections.Generic;

namespace Sma.Sp.TariffService.Domain.Entities
{/*class is having a constructor inside which having virtual variables
 ContractData of type Hash table collection ,and some
 other properites for Get and Set the fields in the class like Id,Firtstname described below */
    public class ContractBankData
    {
        public ContractBankData()
        {
            ContractData = new HashSet<ContractData>();
        }

        // TODO: JW: Minor: Properties of Domain Entities should only be SETable via the constructor.
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Iban { get; set; }
        public string PaymentMethod { get; set; }
        public DateTime? SepaDateUtc { get; set; }
        public string SepaReference { get; set; }

        public virtual ICollection<ContractData> ContractData { get; set; }
    }
}
