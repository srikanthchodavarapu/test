namespace Sma.Sp.TariffService.Domain.Entities
{ //class is having properties defined for transaction status for database.
    public static class ContractMasterDataStatus
    {
        public const string Wait = "wait";
        public const string Complete = "complete";
        public const string InComplete = "incomplete";
        public const string Cancelled = "cancelled";
    }
}