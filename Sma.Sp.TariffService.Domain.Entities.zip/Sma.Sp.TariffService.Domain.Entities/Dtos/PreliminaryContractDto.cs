﻿using System;

namespace Sma.Sp.TariffService.Domain.Entities.Dtos
{   //Gets and Sets the fields/Properties fr Post and Get method for Prelemenery contact 
	public class PreliminaryContract
    {
        public int id { get; set; }

        public DateTime createdDateTime { get; set; }

        public DateTime lastModifiedDateTime { get; set; }

        public string status { get; set; }

        public long? userId { get; set; }

        public string externalUserId { get; set; }

        public string externalContractId { get; set; }

        public int? contractDataId { get; set; }

        public int? contractEntityId { get; set; }

        public int? deliveryAddressId { get; set; }

        public int? billingAddressId { get; set; }

        public DateTime? preferredDeliveryStart { get; set; }

        public string subscriptionReason { get; set; }

        public string meterId { get; set; }

        public string meterRole { get; set; }

        public string meteringpointId { get; set; }

        public string previousProvider { get; set; }

        public double annualConsumption { get; set; }

        public int? bankDataId { get; set; }

        public string tariffType { get; set; }

        public string saasCustomerId { get; set; }

        public string saasContractId { get; set; }

        public string thirdPartySalespartner { get; set; }

        public int? consumptionBeforeBatteryInstallation { get; set; }

        public DateTime? orderDate { get; set; }

        public string formerSupplierFirstName { get; set; }

        public string formerSupplierLastName { get; set; }

        public bool? formerSupplierContractTerminated { get; set; }

        public DateTime? formerSupplierContractTerminationDate { get; set; }

        public bool? isBusiness { get; set; }

        public bool? isSmallBusiness { get; set; }

        public string companyName { get; set; }

        public string salutation { get; set; }

        public string title { get; set; }

        public string firstName { get; set; }

        public string lastName { get; set; }

        public DateTime? birthday { get; set; }

        public string telephone { get; set; }

        public string email { get; set; }

        public string accountingEmail { get; set; }

        public string username { get; set; }

        public string taxNumber { get; set; }

        public string street { get; set; }

        public string houseNumber { get; set; }

        public string zipcode { get; set; }

        public string city { get; set; }

        public string addition { get; set; }

        public string daStreet { get; set; }

        public string daHouseNumber { get; set; }

        public string daZipcode { get; set; }

        public string daCity { get; set; }

        public string daAddition { get; set; }

        public string CBDFirstName { get; set; }

        public string CBDLastName { get; set; }

        public string iban { get; set; }

        public string paymentMethod { get; set; }

        public DateTime? SepaDateUtc { get; set; }
        public DateTime? SepaDate { get; set; }

        public string sepaReference { get; set; }

    }
}
