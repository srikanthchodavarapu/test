﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sma.Sp.TariffService.Domain.Entities.Dtos
{
    public class TariffDTO
    {
        [JsonProperty("basePrice")]
        public float basePrice { get; set; }

        [JsonProperty("price")]
        public float price { get; set; }

        [JsonProperty("basePriceYearly")]
        public float basePriceYearly { get; set; }

        [JsonProperty("amount")]
        public float amount { get; set; }

        [JsonProperty("totalAmount")]
        public float totalAmount { get; set; }

        [JsonProperty("totalAmountYearly")]
        public float totalAmountYearly { get; set; }

        [JsonProperty("tariffType")]
        public string tariffType { get; set; }

        [JsonProperty("costs")]
        public List<CostDTO> costs { get; set; }

    }
}
