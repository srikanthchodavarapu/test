﻿using System;
using System.Collections.Generic;
using System.Net.Http;

namespace Sma.Sp.TariffService.Domain.Entities.Dtos
{    //DOC-Gets and Sets the Response and ContractObject for the service .
	public class ContractObjectDto
	{
		public HttpResponseMessage httpResponse { get; set; }
		public Dictionary<string, Dictionary<string, object>[]> contractObject { get; set; }
	}
}
