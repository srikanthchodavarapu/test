﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sma.Sp.TariffService.Domain.Entities.Dtos
{
    public class CostDTO
    {
        [JsonProperty("costPerUnitNetto")]
        public float costPerUnitNetto { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }
        
        [JsonProperty("displayName")]
        public string displayName { get; set; }
        
        [JsonProperty("unit")]
        public string unit { get; set; }

        
    }
}
