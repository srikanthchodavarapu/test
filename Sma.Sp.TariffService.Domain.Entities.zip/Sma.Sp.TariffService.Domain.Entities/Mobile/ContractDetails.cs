﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sma.Sp.TariffService.Api.Interfaces.Mobile
{   //Get and Set properties for ContractDetails class. 
    public class ContractDetails
    {
        [JsonProperty("current_monthly_installment_amount")]
        public float? monthlyAmount { get; set; }
        
        [JsonProperty("preferred_delivery_start")]
        public DateTime? deliveryStartDate { get; set; }

        [JsonProperty("reg_status")]
        public string registrationStatus { get; set; }

        [JsonProperty("meter_id")]
        public List<string> meterId { get; set; }

        [JsonProperty("market_location")]
        public string marketLocation { get; set; }

        [JsonProperty("annualConsumptionKwh")]
        public int annualConsumption { get; set; }

        [JsonProperty("delivery_address")]
        public Address deliveryAddress { get; set; }
    }
}
