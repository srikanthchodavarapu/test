﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sma.Sp.TariffService.Api.Interfaces.Mobile
{
    public class ProductDetails
    {
        
        [JsonProperty("name")]
        public string Name { get; set; }
        
        [JsonProperty("working_price")]
        public float WorkingPrice { get; set; }
        
        [JsonProperty("base_fee")]
        public float BaseFee { get; set; }
    }
}
