﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Sma.Sp.TariffService.Api.Interfaces.Mobile
{  //Get and Set properties for ContractRequest class. 
    public class ContractsRequest
    {
        /// <summary>
        /// The international bank account number.
        /// </summary>
        [Required]
        [JsonProperty("userId")]
        // TODO: JW: Minor see: #PascalCase
        public string userId { get; set; }
    }
}
