﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sma.Sp.TariffService.Api.Interfaces.Mobile
{     //Get and Set properties for address class. 
    // TODO: JW: Minor #PascalCase: Styleguide: Use PascalCase for properties (the JSON contract resolver 'CamelCasePropertyNamesContractResolver' in Startup.cs will make it CamelCase.
    public class Address
    {
        [JsonProperty("deliv_address_street")]
        public string street { get; set; }
        
        [JsonProperty("deliv_address_house_number")]
        public string houseNumber { get; set; }
        
        [JsonProperty("deliv_address_zipcode")]
        public string zipcode { get; set; }
        
        [JsonProperty("deliv_address_city")]
        public string city { get; set; }
        
        [JsonProperty("deliv_address_addition")]
        public string addressAddition { get; set; }
    }
}
