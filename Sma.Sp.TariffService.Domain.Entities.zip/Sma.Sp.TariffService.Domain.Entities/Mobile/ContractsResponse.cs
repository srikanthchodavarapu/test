﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Sma.Sp.TariffService.Api.Interfaces.Mobile
{  //getting and setting ContractResponse Dictonary for the class and objects 
    public class ContractsResponse
    {
        
        [JsonProperty("contracts")]
        public Dictionary<string, Dictionary<string, object>[]> Contracts { get; set; }

    }
}
