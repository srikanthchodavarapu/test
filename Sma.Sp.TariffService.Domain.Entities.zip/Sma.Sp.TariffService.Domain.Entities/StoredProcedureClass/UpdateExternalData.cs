﻿using EntityFrameworkExtras.EFCore;
using System.Collections.Generic;
using System.Data;

namespace Sma.Sp.TariffService.Domain.Entities.StoredProcedureClass
{ // //Class Used as EF(Entity FrameWork for Mapping Database connection and list of Parameters and Properties with Database
	[StoredProcedure("UpdateExternalData")]
	public class UpdateExternalData
	{
		[StoredProcedureParameter(SqlDbType.Udt, ParameterName = "ParamExternalMasterDataUDT")]
		public List<ContractMasterDataUDT> ParamExternalMasterDataUDT { get; set; }
	}
}
