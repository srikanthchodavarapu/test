﻿using EntityFrameworkExtras.EFCore;
using Sma.Sp.TariffService.Domain.Entities.User_DefinedTableType;
using System.Collections.Generic;
using System.Data;

namespace Sma.Sp.TariffService.Domain.Entities.StoredProcedureClass
{ //Class Used as EF(Entity FrameWork for Mapping Database connection and list of Parameters and Properties with Database
	[StoredProcedure("RemoveContractBankData")]
	public class RemoveContractBankData
	{
		[StoredProcedureParameter(SqlDbType.Udt, ParameterName = "ParamBankDataUDT")]
		public List<ContractBankDataUDT> ParamBankDataUDT { get; set; }
	}
}
