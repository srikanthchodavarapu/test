﻿using EntityFrameworkExtras.EFCore;
using Sma.Sp.TariffService.Domain.Entities.User_DefinedTableType;
using System.Collections.Generic;
using System.Data;

namespace Sma.Sp.TariffService.Domain.Entities.StoredProcedureClass
{ //Class Used as EF(Entity FrameWork for Mapping Database connection and list of Parameters and Properties with Database
	[StoredProcedure("CreateContractBankAddressEntity")]
	public class CreateContractBankAddressEntity
	{
		[StoredProcedureParameter(SqlDbType.Udt, ParameterName = "ParamBankAddressEntityData")]
		public List<ContractBankAddressEntityUDT> ParamBankAddressEntityData { get; set; }

		[StoredProcedureParameter(SqlDbType.Int, Direction = ParameterDirection.Output)]
		public int @LastCreatedIdentity { get; set; }
	}
}
