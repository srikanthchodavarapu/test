﻿using EntityFrameworkExtras.EFCore;
using System.Collections.Generic;
using System.Data;

namespace Sma.Sp.TariffService.Domain.Entities.StoredProcedureClass
{ // //Class Used as EF(Entity FrameWork for Mapping Database connection and list of Parameters and Properties with Database
	[StoredProcedure("UpdateStatus")]
	public class UpdateStatus
	{
		[StoredProcedureParameter(SqlDbType.Udt, ParameterName = "ParamMasterDataUDT")]
		public List<ContractMasterDataUDT> ParamMasterDataUDT { get; set; }
	}
}
