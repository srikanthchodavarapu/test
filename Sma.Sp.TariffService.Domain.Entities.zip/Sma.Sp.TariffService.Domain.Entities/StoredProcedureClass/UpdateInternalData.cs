﻿using EntityFrameworkExtras.EFCore;
using System.Collections.Generic;
using System.Data;

namespace Sma.Sp.TariffService.Domain.Entities.StoredProcedureClass
{
	[StoredProcedure("UpdateInternalData")]
	public class UpdateInternalData
	{
		[StoredProcedureParameter(SqlDbType.Udt, ParameterName = "ParamInternalMasterDataUDT")]
		public List<ContractMasterDataUDT> ParamInternalMasterDataUDT { get; set; }
	}
}
