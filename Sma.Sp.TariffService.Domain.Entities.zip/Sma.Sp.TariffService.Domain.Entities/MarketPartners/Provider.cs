﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Domain.Entities.MarketPartners
{   //Get;Set the properties for class provider 
    /// <summary>
    /// Provider Dto
    /// </summary>
    public class Provider
    {
        public string Id { get; set; }

        public string Name { get; set; } 
    }
}
