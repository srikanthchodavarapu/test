﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sma.Sp.TariffService.Api.Interfaces
{
    /// <summary>
    /// Order Validation response object
    /// </summary>
    public class OrderValidationResponse
    {
        // TODO: JW: Minor: If a response is that simple, it's okay if your simply returning "true". Please Prefix all boolean properties with 'Is', 'Are' etc.
        public bool Exist { get; set; }
    }
}
