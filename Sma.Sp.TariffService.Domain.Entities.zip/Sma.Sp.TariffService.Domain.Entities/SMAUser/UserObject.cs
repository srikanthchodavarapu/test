﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Domain.Entities.SMAUser
{  //Getting and Setting UserObject properties from User object Class like Userid, email,title etc ..
    /// <summary>
    /// User object
    /// </summary>
    public class UserObject
    {
        [Required]
        [MaxLength(255)]
        public string UserId { get; set; } 

        public string Email { get; set; }

        public string Title { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Culture { get; set; }

        public Address Address { get; set; }
    }
}
