﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Domain.Entities.SMAUser
{  //properties are used in UnverifiedUserObject for get and set like userId,passwors,email and etc ,
    /// <summary>
    /// 
    /// </summary>
    public class UnverifiedUserObject
    {
        [JsonProperty("userId")]
        public string Userid { get; set; } 
        
        [Required]
        [JsonProperty("password")]
        public string Password { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("culture")]
        public string Culture { get; set; }

        [JsonProperty("address")]
        public Address Address { get; set; }
    }
}
