﻿using System;
using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Domain.Entities.SMAUser
{ //Getting and Setting up Properties for address class like city,country etc ..
    /// <summary>
    /// Address entity for SMAUser
    /// </summary>
    public class Address
    {
        public string Country { get; set; } 

        public string City { get; set; }

        public string ZipCode { get; set; }

        public string Street { get; set; }

        public string StreetNo { get; set; }

        public string PhoneNumber { get; set; }

    }
}
