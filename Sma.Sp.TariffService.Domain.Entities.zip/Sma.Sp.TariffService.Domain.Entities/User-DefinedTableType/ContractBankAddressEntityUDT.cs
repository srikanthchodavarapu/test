﻿using EntityFrameworkExtras.EFCore;
using System;

namespace Sma.Sp.TariffService.Domain.Entities.User_DefinedTableType
{ //here listed are the coloums from User defined tables called ContractBankAddressEntityUDT from database to map and bind the data from the database.
	[UserDefinedTableType("ContractBankAddressEntityUDT")]
	public class ContractBankAddressEntityUDT
	{
		// Bank Data ::
		[UserDefinedTableTypeColumn(1, "FirstName")]
		public string FirstName { get; set; }
		[UserDefinedTableTypeColumn(2, "LastName")]
		public string LastName { get; set; }
		[UserDefinedTableTypeColumn(3)]
		public string Iban { get; set; }
		[UserDefinedTableTypeColumn(4)]
		public string PaymentMethod { get; set; }
		[UserDefinedTableTypeColumn(5)]
		public DateTime? SepaDateUtc { get; set; }
		[UserDefinedTableTypeColumn(6)]
		public string SepaReference { get; set; }
		// Delivery Address ::
		[UserDefinedTableTypeColumn(7)]
		public string Street { get; set; }
		[UserDefinedTableTypeColumn(8)]
		public string HouseNumber { get; set; }
		[UserDefinedTableTypeColumn(9)]
		public string Zipcode { get; set; }
		[UserDefinedTableTypeColumn(10)]
		public string City { get; set; }
		[UserDefinedTableTypeColumn(11)]
		public string Addition { get; set; }
		// Billing Address ::
		[UserDefinedTableTypeColumn(12)]
		public string BillStreet { get; set; }
		[UserDefinedTableTypeColumn(13)]
		public string BillHouseNumber { get; set; }
		[UserDefinedTableTypeColumn(14)]
		public string BillZipcode { get; set; }
		[UserDefinedTableTypeColumn(15)]
		public string BillCity { get; set; }
		[UserDefinedTableTypeColumn(16)]
		public string BillAddition { get; set; }
		// Contract Entity ::
		[UserDefinedTableTypeColumn(17)]
		public bool IsBusiness { get; set; }
		[UserDefinedTableTypeColumn(18)]
		public bool IsSmallBusiness { get; set; }
		[UserDefinedTableTypeColumn(19)]
		public string CompanyName { get; set; }
		[UserDefinedTableTypeColumn(20)]
		public string Salutation { get; set; }
		[UserDefinedTableTypeColumn(21)]
		public string Title { get; set; }
		[UserDefinedTableTypeColumn(22)]
		public string CEFirstName { get; set; }
		[UserDefinedTableTypeColumn(23)]
		public string CELastName { get; set; }
		[UserDefinedTableTypeColumn(24)]
		public DateTime? Birthday { get; set; }
		[UserDefinedTableTypeColumn(25)]
		public string Telephone { get; set; }
		[UserDefinedTableTypeColumn(26)]
		public string Email { get; set; }
		[UserDefinedTableTypeColumn(27)]
		public string AccountingEmail { get; set; }
		[UserDefinedTableTypeColumn(28)]
		public string Username { get; set; }
		[UserDefinedTableTypeColumn(29)]
		public string TaxNumber { get; set; }
		// Contract Data ::
		[UserDefinedTableTypeColumn(30)]
		public int ContractEntityId { get; set; }
		[UserDefinedTableTypeColumn(31)]
		public int DeliveryAddressId { get; set; }
		[UserDefinedTableTypeColumn(32)]
		public int BillingAddressId { get; set; }
		[UserDefinedTableTypeColumn(33)]
		public DateTime? PreferredDeliveryStart { get; set; }
		[UserDefinedTableTypeColumn(34)]
		public string SubscriptionReason { get; set; }
		[UserDefinedTableTypeColumn(35)]
		public string MeterId { get; set; }
		[UserDefinedTableTypeColumn(36)]
		public string MeterRole { get; set; }
		[UserDefinedTableTypeColumn(37)]
		public string MeteringpointId { get; set; }
		[UserDefinedTableTypeColumn(38)]
		public string PreviousProvider { get; set; }
		[UserDefinedTableTypeColumn(39)]
		public double AnnualConsumption { get; set; }
		[UserDefinedTableTypeColumn(40)]
		public int? BankDataId { get; set; }
		[UserDefinedTableTypeColumn(41)]
		public string TariffType { get; set; }
		[UserDefinedTableTypeColumn(42)]
		public string SaasCustomerId { get; set; }
		[UserDefinedTableTypeColumn(43)]
		public string SaasContractId { get; set; }
		[UserDefinedTableTypeColumn(44)]
		public string ThirdPartySalespartner { get; set; }
		[UserDefinedTableTypeColumn(45)]
		public int FreeAmount { get; set; }
		[UserDefinedTableTypeColumn(46)]
		public int? ConsumptionBeforeBatteryInstallation { get; set; }
		[UserDefinedTableTypeColumn(47)]
		public DateTime? OrderDate { get; set; }
		[UserDefinedTableTypeColumn(48)]
		public string FormerSupplierFirstName { get; set; }
		[UserDefinedTableTypeColumn(49)]
		public string FormerSupplierLastName { get; set; }
		[UserDefinedTableTypeColumn(50)]
		public bool? FormerSupplierContractTerminated { get; set; }
		[UserDefinedTableTypeColumn(51)]
		public DateTime? FormerSupplierContractTerminationDate { get; set; }
		// Contract Master Data ::
		[UserDefinedTableTypeColumn(52)]
		public DateTime CreatedDateTime { get; set; }
		[UserDefinedTableTypeColumn(53)]
		public DateTime LastModifiedDateTime { get; set; }
		[UserDefinedTableTypeColumn(54)]
		public string Status { get; set; }
		[UserDefinedTableTypeColumn(55)]
		public long? UserId { get; set; }
		[UserDefinedTableTypeColumn(56)]
		public string ExternalUserId { get; set; }
		[UserDefinedTableTypeColumn(57)]
		public string ExternalContractId { get; set; }
		[UserDefinedTableTypeColumn(58)]
		public int? ContractDataId { get; set; }
	}
}

