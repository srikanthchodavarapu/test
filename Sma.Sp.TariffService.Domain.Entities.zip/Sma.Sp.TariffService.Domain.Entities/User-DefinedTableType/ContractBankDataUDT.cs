﻿using EntityFrameworkExtras.EFCore;
using System;

namespace Sma.Sp.TariffService.Domain.Entities.User_DefinedTableType
{////here listed are the coloums from User defined tables called ContractBankDataUDT from database to map and bind the data from the database.

    [UserDefinedTableType("ContractBankDataUDT")]
    public class ContractBankDataUDT
	{
        // Bank Data ::
        [UserDefinedTableTypeColumn(1)]
        public int Id { get; set; }
        [UserDefinedTableTypeColumn(2)]
        public string FirstName { get; set; }
        [UserDefinedTableTypeColumn(3)]
        public string LastName { get; set; }
        [UserDefinedTableTypeColumn(4)]
        public string Iban { get; set; }
        [UserDefinedTableTypeColumn(5)]
        public string PaymentMethod { get; set; }
        [UserDefinedTableTypeColumn(6)]
        public DateTime? SepaDateUtc { get; set; }
        [UserDefinedTableTypeColumn(7)]
        public string SepaReference { get; set; }
    }
}
