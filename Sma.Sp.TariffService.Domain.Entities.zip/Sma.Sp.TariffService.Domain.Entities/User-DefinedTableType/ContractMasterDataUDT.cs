﻿using EntityFrameworkExtras.EFCore;
using System;

namespace Sma.Sp.TariffService.Domain.Entities
{
    //here listed are the coloums from User defined tables called ContractMasterDataUDT from database to map and bind the data from the database.
    [UserDefinedTableType("ContractMasterDataUDT")]
    public class ContractMasterDataUDT
    {
        [UserDefinedTableTypeColumn(1)]
        public int Id { get; set; }
        [UserDefinedTableTypeColumn(2)]
        public DateTime CreatedDateTime { get; set; }
        [UserDefinedTableTypeColumn(3)]
        public DateTime LastModifiedDateTime { get; set; }
        [UserDefinedTableTypeColumn(4)]
        public string Status { get; set; }
        [UserDefinedTableTypeColumn(5)]
        public long? UserId { get; set; }
        [UserDefinedTableTypeColumn(6)]
        public string ExternalUserId { get; set; }
        [UserDefinedTableTypeColumn(7)]
        public string ExternalContractId { get; set; }
        [UserDefinedTableTypeColumn(8)]
        public int? ContractDataId { get; set; }
    }
}
