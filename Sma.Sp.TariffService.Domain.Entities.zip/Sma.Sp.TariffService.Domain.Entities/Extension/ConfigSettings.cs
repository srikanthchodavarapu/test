﻿namespace Sma.Sp.TariffService.Domain.Services
{ //Get and Set the Properties for the configuraton variables which are used in startup to read the values from appsetting.json  
    public class ConfigSettings
    {
        public string EndPoint { get; set; }
        public string GrantType { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; } 
    }
}