using Newtonsoft.Json.Converters;

//TODO: JW: Minor: Namespace shall reflect file path.
namespace Sma.Sp.TariffService.Domain.Services 
{ 
    /// <summary>
    /// Covert DateTime format to "yyyy-MM-dd" (use with annotation)
    /// </summary>
//class is inhereting interface to set the format of Json Date time according to requirement.
public class CustomDateTimeJsonConverter: IsoDateTimeConverter
    {
        /// <summary>
        /// 
        /// </summary>
        public CustomDateTimeJsonConverter()
        {
            base.DateTimeFormat = "yyyy-MM-dd"; 
        }
    }
}