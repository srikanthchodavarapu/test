﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Reflection;

namespace Sma.Sp.TariffService.Domain.Services
{
    /// <summary>
    /// Convert to FormUrlEncodedContent
    /// </summary>
   //class to Get the Value properties and Encode the URL and to Change the Format for Datetime 
    public static class Extension
    {
        private static object GetPropValue(object src, string propName)
        {
            return src.GetType().GetProperty(propName).GetValue(src, null);
        }
        public static FormUrlEncodedContent ConvertToFormContentUrlEncoded<T>(T obj) 
        {
            var result = new List<KeyValuePair<string, string>>();
            PropertyInfo[] properties = typeof(T).GetProperties();
            foreach (PropertyInfo property in properties)
            {
                var value = Extension.GetPropValue(obj, property.Name);
                if (value != null)
                {
                   
                    string realValue = string.Empty;
                    if (property.PropertyType == typeof(DateTime?))
                    {
                        var dateStr = value.ToString();
                        if (!String.IsNullOrEmpty(dateStr))
                        {
                            DateTime date = DateTime.Parse(dateStr);
                            if (date != default(DateTime))
                                realValue = date.ToString("yyyy-MM-dd");
                        }
                    }
                    else if (property.PropertyType == typeof(DateTime))
                    {
                        var dateStr = value.ToString();
                        DateTime date = DateTime.Parse(dateStr);
                        if (date != default(DateTime))
                            realValue = date.ToString("yyyy-MM-dd");
                    }
                    else realValue = value.ToString();

                    if(!String.IsNullOrEmpty(realValue))
                        result.Add(new KeyValuePair<string, string>(property.Name, realValue));
                }
            }
            return new FormUrlEncodedContent(result);
        }
    }
}
