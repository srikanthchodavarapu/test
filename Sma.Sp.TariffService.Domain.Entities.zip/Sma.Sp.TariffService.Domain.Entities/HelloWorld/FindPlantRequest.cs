// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BaseLoadForecastRequest.cs" company="SMA Solar Technology AG, 34266 Niestetal, Germany">
//   Copyright (c) SMA Solar Technology AG, 34266 Niestetal, Germany.  All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Sma.Sp.TariffService.Domain.Entities.HelloWorld
{
    /// <summary>A base load forecast request.</summary>
    public class FindPlantRequest
    {
        /// <summary>
        /// Gets or sets the user id.
        /// </summary>
        /// <value>
        /// The user id.
        /// </value>
        public long UserId { get; set; }

        /// <summary>retrieve only plant names which contain this string</summary>
        public string PlantNameQuery { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="FindPlantRequest" /> class.
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="plantNameQuery">retrieve only plant names which contain this string</param>
        public FindPlantRequest(
            long userId,
            string plantNameQuery)
        {
            UserId = userId;
            PlantNameQuery = plantNameQuery;
        }
    }
}
