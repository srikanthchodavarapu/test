using System.Collections.Generic;

namespace Sma.Sp.TariffService.Domain.Entities.HelloWorld
{
    /// <summary>
    /// Response to hello world request 
    /// </summary>
    public class FindPlantsResponse
    {
        /// <summary>
        /// Gets or sets the plants.
        /// </summary>
        /// <value>
        /// The plants.
        /// </value>
        public IEnumerable<Plant> Plants { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="FindPlantsResponse" /> class.
        /// </summary>
        /// <param name="plants">The plants.</param>
        public FindPlantsResponse(
            IEnumerable<Plant> plants
            )
        {
            Plants = plants;
        }
    }
}