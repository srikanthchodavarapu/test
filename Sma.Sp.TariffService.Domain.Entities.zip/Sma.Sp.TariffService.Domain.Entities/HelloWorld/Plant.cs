namespace Sma.Sp.TariffService.Domain.Entities.HelloWorld
{
    public class Plant
    {
        /// <summary>
        /// Gets or sets the plant identifier.
        /// </summary>
        /// <value>
        /// The plant identifier.
        /// </value>
        public long PlantId { get; }

        /// <summary>
        /// Gets or sets the name of the plant.
        /// </summary>
        /// <value>
        /// The name of the plant.
        /// </value>
        public string PlantName { get; }


        /// <summary>
        /// Initializes a new instance of the <see cref="FindPlantsResponse"/> class.
        /// </summary>
        /// <param name="plantId">The plant identifier.</param>
        /// <param name="plantName">Name of the plant.</param>
        public Plant(
            long plantId,
            string plantName
        )
        {
            PlantId = plantId;
            PlantName = plantName;
        }
    }
}