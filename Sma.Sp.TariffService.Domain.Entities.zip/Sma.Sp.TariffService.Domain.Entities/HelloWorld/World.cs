﻿namespace Sma.Sp.TariffService.Domain.Entities.HelloWorld
{
    public class World
    {
        public long WorldId { get; }
        public long PlantId { get; }
        public string Name { get; }

        public World(long worldId, long plantId, string name)
        {
            WorldId = worldId;
            PlantId = plantId;
            Name = name;
        }
    }
}
