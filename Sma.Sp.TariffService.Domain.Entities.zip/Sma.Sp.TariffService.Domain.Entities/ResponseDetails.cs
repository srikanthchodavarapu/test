﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sma.Sp.TariffService.Api.Interfaces
{
    /// <summary>
    /// Response Details object
    /// </summary>
    public class ResponseDetails
    {
        // TODO: JW: Minor: Potential bug: In order for json de/serialization to work, DTO classes must contain a default constructor.
        public ResponseDetails(string detail)
        {
            Detail = detail;
        }

        // TODO: JW: Minor: This class is very unspecific, looks like poor design. 
        [JsonProperty("detail")]
        public string Detail { get; set; }
    }
}
