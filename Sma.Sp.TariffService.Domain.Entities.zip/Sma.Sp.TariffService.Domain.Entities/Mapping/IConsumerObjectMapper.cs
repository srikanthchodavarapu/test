using Sma.Sp.TariffService.Api.Interfaces.Tariff;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.ConsumersObject;

namespace Sma.Sp.TariffService.Web.Service.Models.Mapping
{ //interface where the methoad from the ConsumersObject has been initilize/define 
    public interface IConsumerObjectMapper
    {
        /// <summary>
        /// Mapper RequestCreateContractObject -> ConsumersObject
        /// </summary>
        /// <param name="createContractObject"></param>
        /// <returns></returns>
        LumenazaConsumersRequestObject Transform(RequestCreateContractObject createContractObject);
    }
}