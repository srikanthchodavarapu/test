using Sma.Sp.TariffService.Api.Interfaces.Tariff;
using Sma.Sp.TariffService.Api.Interfaces.Tariff.Models;
using Sma.Sp.TariffService.Domain.Entities;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.ConsumersObject;

namespace Sma.Sp.TariffService.Web.Service.Models.Mapping
{   //interface where methods have been defined to implements in various classes by implementing interface.
	public interface ICreateContractRequestMapper
    {
        /// <summary>
        /// Mapper RequestConsumersObject -> CreateContractRequest
        /// </summary>
        /// <param name="requestConsumersObject"></param>
        /// <returns></returns>
        CreateContractRequest Transform(RequestConsumersObject requestConsumersObject);
        
        
        /// <summary>
        /// Mapper RequestCreateContractObject -> CreateContractRequest
        /// </summary>
        /// <param name="requestCreateContractObject"></param>
        /// <returns></returns>
        CreateContractRequest Transform(RequestCreateContractObject requestCreateContractObject);

        /// <summary>
        /// Mapper RequestConsumerUnverifiedObject -> CreateContractRequest
        /// </summary>
        /// <param name="requestConsumersObject"></param>
        /// <returns></returns>
        CreateContractRequest Transform(RequestConsumerUnverifiedObject requestConsumersObject);
        
        /// <summary>
        /// Mapper RequestUnverifiedSavingsObject -> CreateContractRequest
        /// </summary>
        /// <param name="requestConsumersObject"></param>
        /// <returns></returns>
        CreateContractRequest Transform(RequestUnverifiedSavingsObject requestConsumersObject);
    }
    
}