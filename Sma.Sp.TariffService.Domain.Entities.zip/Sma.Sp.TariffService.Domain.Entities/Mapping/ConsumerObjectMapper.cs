using System;
using Sma.Sp.TariffService.Api.Interfaces.Tariff;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.ConsumersObject;

namespace Sma.Sp.TariffService.Web.Service.Models.Mapping
{
	/// <summary>
	/// 
	/// </summary>
	public class ConsumerObjectMapper : IConsumerObjectMapper
    {
        //Accessing and setting all the properties from ConsumersObject class and making use of them to setting the properties and variables 
        /// <summary>
        /// 
        /// </summary>
        /// <param name="createContractObject"></param>
        /// <returns></returns>
        public LumenazaConsumersRequestObject Transform(RequestCreateContractObject createContractObject)
        {  // creating new object from the constructor class and assgnining its properties here .
            var returnObj = new LumenazaConsumersRequestObject
            {
                company_name = createContractObject.Contract.CompanyName,
                is_business = createContractObject.Contract.IsBusiness,
                salutation = createContractObject.Contract.Salutation,
                username = createContractObject.Contract.Username,
                first_name = createContractObject.Contract.FirstName,
                last_name = createContractObject.Contract.LastName,
                birthday = createContractObject.Contract.Birthday,
                telephone = (createContractObject.Contract.Telephone == "" ? null : createContractObject.Contract.Telephone),
                email = createContractObject.Contract.Email,
                accounting_email = createContractObject.Contract.AccountingEmail,
                deliv_address_street = createContractObject.Contract.DelivAddressStreet,
                deliv_address_house_number = createContractObject.Contract.DelivAddressHouseNumber,
                deliv_address_zipcode = createContractObject.Contract.DelivAddressZipcode,
                deliv_address_city = createContractObject.Contract.DelivAddressCity,
                deliv_address_addition = (createContractObject.Contract.DelivAddressAddition == "" ? null : createContractObject.Contract.DelivAddressAddition),
                bill_address_street = createContractObject.Contract.BillAddressStreet,
                bill_address_house_number = createContractObject.Contract.BillAddressHouseNumber,
                bill_address_zipcode = createContractObject.Contract.BillAddressZipcode,
                bill_address_city = createContractObject.Contract.BillAddressCity,
                bill_address_addition = createContractObject.Contract.BillAddressAddition,
                subscription_reason = createContractObject.Contract.SubscriptionReason,
                meter_id = createContractObject.Contract.MeterId,
                previous_provider = (createContractObject.Contract.PreviousProvider == "" ? null : createContractObject.Contract.PreviousProvider),
                annual_consumption = createContractObject.Contract.AnnualConsumption,
                bank_data_first_name = createContractObject.Contract.BankDataFirstName,
                bank_data_last_name = createContractObject.Contract.BankDataLastName,
                bank_data_iban = createContractObject.Contract.BankDataIban,
                tariff_type = createContractObject.Contract.TariffType,
                former_supplier_first_name = createContractObject.Contract.FormerSupplierFirstName,
                former_supplier_last_name = createContractObject.Contract.FormerSupplierLastName,
                former_supplier_contract_terminated =
                    Convert.ToBoolean(createContractObject.Contract.FormerSupplierContractTerminated),
                former_supplier_contract_termination_date =
                    createContractObject.Contract.FormerSupplierContractTerminationDate,
                meteringpoint_id = (createContractObject.Contract.MeteringPointId == "" ? null : createContractObject.Contract.MeteringPointId), 
                sepa_date = createContractObject.Contract.SepaDateUtc,
                preferred_delivery_start = createContractObject.Contract.PreferredDeliveryStart,
                consumption_before_battery_installation = createContractObject.Contract.ConsumptionBeforeBatteryInstallation,
                is_small_business = createContractObject.Contract.IsSmallBusiness,
                meter_role = createContractObject.Contract.MeterRole,
                order_date = createContractObject.Contract.OrderDate,
                payment_method = createContractObject.Contract.PaymentMethod.ToString(),
				saas_contract_id = null,
				saas_customer_id = null,
				sepa_reference = createContractObject.Contract.SepaReference,
                tax_number = createContractObject.Contract.TaxNumber,
                third_party_salespartner = null,
                title = createContractObject.Contract.Title
            };

            return returnObj;
        }
    }
}