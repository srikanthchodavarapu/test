using System;
using System.Collections.Generic;
using Sma.Sp.TariffService.Api.Interfaces.Tariff;
using Sma.Sp.TariffService.Api.Interfaces.Tariff.Models;
using Sma.Sp.TariffService.Domain.Entities;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.ConsumersObject;

namespace Sma.Sp.TariffService.Web.Service.Models.Mapping
{  //Mapping the object and  setting the properties from CreateContractRequest class and implementing the Interface ICreateContractRequestMapper and its method.
    public class CreateContractRequestMapper : ICreateContractRequestMapper
    {
        /// <summary>
        /// Mapper RequestConsumersObject -> CreateContractRequest
        /// </summary>
        /// <param name="requestConsumersObject"></param>
        /// <returns></returns>
        public CreateContractRequest Transform(RequestConsumersObject requestConsumersObject)
        {
            var returnObj = new CreateContractRequest
            {
                ContractAddress = new List<ContractAddress>(),
                ContractMasterData = new ContractMasterData
                {
                    UserId = long.Parse(requestConsumersObject.User.UserId),
                },
                ContractBankData =
                    new ContractBankData
                    {
                        Iban = requestConsumersObject.Contract.bank_data_iban,
                        FirstName = requestConsumersObject.Contract.bank_data_first_name,
                        LastName = requestConsumersObject.Contract.bank_data_last_name,
                        PaymentMethod = requestConsumersObject.Contract.payment_method,
                        SepaDateUtc = requestConsumersObject.Contract.sepa_date,
                        SepaReference = requestConsumersObject.Contract.sepa_reference
                    },
                ContractEntity = new ContractEntity
                {
                    Birthday = requestConsumersObject.Contract.birthday,
                    Email = requestConsumersObject.Contract.email,
                    Salutation = requestConsumersObject.Contract.salutation,
                    Telephone = requestConsumersObject.Contract.telephone,
                    Title = requestConsumersObject.Contract.title,
                    Username = requestConsumersObject.Contract.username,
                    AccountingEmail = requestConsumersObject.Contract.accounting_email,
                    CompanyName = requestConsumersObject.Contract.company_name,
                    FirstName = requestConsumersObject.Contract.first_name,
                    LastName = requestConsumersObject.Contract.last_name,
                    IsBusiness = requestConsumersObject.Contract.is_business,
                    IsSmallBusiness = requestConsumersObject.Contract.is_small_business,
                    TaxNumber = requestConsumersObject.Contract.tax_number,
                },
                ContractData = new ContractData
                {
                    AnnualConsumption = double.Parse(requestConsumersObject.Contract.annual_consumption),
                    MeterId = requestConsumersObject.Contract.meter_id,
                    MeteringpointId = requestConsumersObject.Contract.meteringpoint_id,
                    MeterRole = requestConsumersObject.Contract.meter_role,
                    OrderDate = requestConsumersObject.Contract.order_date,
                    PreviousProvider = requestConsumersObject.Contract.previous_provider,
                    SubscriptionReason = requestConsumersObject.Contract.subscription_reason,
                    TariffType = requestConsumersObject.Contract.tariff_type,
                    PreferredDeliveryStart = requestConsumersObject.Contract.preferred_delivery_start,
                    SaasContractId = requestConsumersObject.Contract.saas_contract_id,
                    SaasCustomerId = requestConsumersObject.Contract.saas_customer_id,
                    ThirdPartySalespartner = requestConsumersObject.Contract.third_party_salespartner,
                    ConsumptionBeforeBatteryInstallation =
                        Convert.ToInt32(requestConsumersObject.Contract.consumption_before_battery_installation),
                    FormerSupplierContractTerminated =
                        requestConsumersObject.Contract.former_supplier_contract_terminated == true ? true : false,
                    FormerSupplierFirstName = requestConsumersObject.Contract.former_supplier_first_name,
                    FormerSupplierLastName = requestConsumersObject.Contract.former_supplier_last_name,
                    FormerSupplierContractTerminationDate =
                        requestConsumersObject.Contract.former_supplier_contract_termination_date,
                }
            };
            
            returnObj.ContractAddress.Add(new ContractAddress
                {
                    HouseNumber = requestConsumersObject.Contract.deliv_address_house_number,
                    City = requestConsumersObject.Contract.deliv_address_city,
                    Zipcode = requestConsumersObject.Contract.deliv_address_zipcode,
                    Addition = requestConsumersObject.Contract.deliv_address_addition,
                    Street = requestConsumersObject.Contract.deliv_address_street,
                }
            );
            
            returnObj.ContractAddress.Add(new ContractAddress
            {
                HouseNumber = requestConsumersObject.Contract.bill_address_house_number ?? requestConsumersObject.Contract.deliv_address_house_number,
                City = requestConsumersObject.Contract.bill_address_city ?? requestConsumersObject.Contract.deliv_address_city,
                Zipcode = requestConsumersObject.Contract.bill_address_zipcode ?? requestConsumersObject.Contract.deliv_address_zipcode,
                Addition = requestConsumersObject.Contract.bill_address_addition ?? requestConsumersObject.Contract.deliv_address_addition,
                Street = requestConsumersObject.Contract.bill_address_street ?? requestConsumersObject.Contract.deliv_address_street,
            });
            
            return returnObj;
        }
        
        /// <summary>
        /// Mapper RequestCreateContractObject -> CreateContractRequest
        /// </summary>
        /// <param name="requestCreateContractObject"></param>
        /// <returns></returns>
        public CreateContractRequest Transform(RequestCreateContractObject requestCreateContractObject)
        {
            // return new CreateContractRequest();
            var returnObj = new CreateContractRequest
            {
                ContractAddress = new List<ContractAddress>(),
                ContractMasterData = new ContractMasterData
                {
                    UserId = long.Parse(requestCreateContractObject.User.UserId),
                },
                ContractBankData =
                    new ContractBankData
                    {
                        Iban = requestCreateContractObject.Contract.BankDataIban,
                        FirstName = requestCreateContractObject.Contract.BankDataFirstName,
                        LastName = requestCreateContractObject.Contract.BankDataLastName,
                        PaymentMethod = requestCreateContractObject.Contract.PaymentMethod.ToString(),
                        SepaDateUtc = requestCreateContractObject.Contract.SepaDateUtc,
                        SepaReference = requestCreateContractObject.Contract.SepaReference
                    },
                ContractEntity = new ContractEntity
                {
                    Birthday = requestCreateContractObject.Contract.Birthday,
                    Email = requestCreateContractObject.Contract.Email,
                    Salutation = requestCreateContractObject.Contract.Salutation,
                    Telephone = requestCreateContractObject.Contract.Telephone,
                    Title = requestCreateContractObject.Contract.Title,
                    Username = requestCreateContractObject.Contract.Username,
                    AccountingEmail = requestCreateContractObject.Contract.AccountingEmail,
                    CompanyName = requestCreateContractObject.Contract.CompanyName,
                    FirstName = requestCreateContractObject.Contract.FirstName,
                    LastName = requestCreateContractObject.Contract.LastName,
                    IsBusiness = requestCreateContractObject.Contract.IsBusiness,
                    IsSmallBusiness = requestCreateContractObject.Contract.IsSmallBusiness,
                    TaxNumber = requestCreateContractObject.Contract.TaxNumber,
                },
                ContractData = new ContractData
                {
                    AnnualConsumption = double.Parse(requestCreateContractObject.Contract.AnnualConsumption),
                    MeterId = requestCreateContractObject.Contract.MeterId,
                    MeteringpointId = requestCreateContractObject.Contract.MeteringPointId,
                    MeterRole = requestCreateContractObject.Contract.MeterRole,
                    OrderDate = requestCreateContractObject.Contract.OrderDate,
                    PreviousProvider = requestCreateContractObject.Contract.PreviousProvider,
                    SubscriptionReason = requestCreateContractObject.Contract.SubscriptionReason,
                    TariffType = requestCreateContractObject.Contract.TariffType,
                    PreferredDeliveryStart = requestCreateContractObject.Contract.PreferredDeliveryStart,
					SaasContractId = null,
					SaasCustomerId = null,
					ThirdPartySalespartner = null,
                    ConsumptionBeforeBatteryInstallation =
                        Convert.ToInt32(requestCreateContractObject.Contract.ConsumptionBeforeBatteryInstallation),
                    FormerSupplierContractTerminated =
                        requestCreateContractObject.Contract.FormerSupplierContractTerminated == "true" ? true : false,
                    FormerSupplierFirstName = requestCreateContractObject.Contract.FormerSupplierFirstName,
                    FormerSupplierLastName = requestCreateContractObject.Contract.FormerSupplierLastName,
                    FormerSupplierContractTerminationDate =
                        requestCreateContractObject.Contract.FormerSupplierContractTerminationDate,
                }
            };
            
            returnObj.ContractAddress.Add(new ContractAddress
                {
                    HouseNumber = requestCreateContractObject.Contract.DelivAddressHouseNumber,
                    City = requestCreateContractObject.Contract.DelivAddressCity,
                    Zipcode = requestCreateContractObject.Contract.DelivAddressZipcode,
                    Addition = requestCreateContractObject.Contract.DelivAddressAddition,
                    Street = requestCreateContractObject.Contract.DelivAddressStreet,
                }
            );
            
            returnObj.ContractAddress.Add(new ContractAddress
            {
                HouseNumber = requestCreateContractObject.Contract.BillAddressHouseNumber ?? requestCreateContractObject.Contract.DelivAddressHouseNumber,
                City = requestCreateContractObject.Contract.BillAddressCity ?? requestCreateContractObject.Contract.DelivAddressCity,
                Zipcode = requestCreateContractObject.Contract.BillAddressZipcode ?? requestCreateContractObject.Contract.DelivAddressZipcode,
                Addition = requestCreateContractObject.Contract.BillAddressAddition ?? requestCreateContractObject.Contract.DelivAddressAddition,
                Street = requestCreateContractObject.Contract.BillAddressStreet ?? requestCreateContractObject.Contract.DelivAddressStreet,
            });
            
            
            return returnObj;
        }

        /// <summary>
        /// Mapper RequestConsumerUnverifiedObject -> CreateContractRequest
        /// </summary>
        /// <param name="requestConsumersObject"></param>
        /// <returns></returns>
        public CreateContractRequest Transform(RequestConsumerUnverifiedObject requestConsumersObject)
        {
            var returnObj = new CreateContractRequest
            {
                ContractAddress = new List<ContractAddress>(),
                ContractMasterData = new ContractMasterData
                {
                    // UserId = long.Parse(requestConsumersObject.User.Userid),
                },
                ContractBankData =
                    new ContractBankData
                    {
                        Iban = requestConsumersObject.Contract.bank_data_iban,
                        FirstName = requestConsumersObject.Contract.bank_data_first_name,
                        LastName = requestConsumersObject.Contract.bank_data_last_name,
                        PaymentMethod = requestConsumersObject.Contract.payment_method,
                        SepaDateUtc = requestConsumersObject.Contract.sepa_date,
                        SepaReference = requestConsumersObject.Contract.sepa_reference
                    },
                ContractEntity = new ContractEntity
                {
                    Birthday = requestConsumersObject.Contract.birthday,
                    Email = requestConsumersObject.Contract.email,
                    Salutation = requestConsumersObject.Contract.salutation,
                    Telephone = requestConsumersObject.Contract.telephone,
                    Title = requestConsumersObject.Contract.title,
                    Username = requestConsumersObject.Contract.username,
                    AccountingEmail = requestConsumersObject.Contract.accounting_email,
                    CompanyName = requestConsumersObject.Contract.company_name,
                    FirstName = requestConsumersObject.Contract.first_name,
                    LastName = requestConsumersObject.Contract.last_name,
                    IsBusiness = requestConsumersObject.Contract.is_business,
                    IsSmallBusiness = requestConsumersObject.Contract.is_small_business,
                    TaxNumber = requestConsumersObject.Contract.tax_number,
                },
                ContractData = new ContractData
                {
                    AnnualConsumption = double.Parse(requestConsumersObject.Contract.annual_consumption),
                    MeterId = requestConsumersObject.Contract.meter_id,
                    MeteringpointId = requestConsumersObject.Contract.meteringpoint_id,
                    MeterRole = requestConsumersObject.Contract.meter_role,
                    OrderDate = requestConsumersObject.Contract.order_date,
                    PreviousProvider = requestConsumersObject.Contract.previous_provider,
                    SubscriptionReason = requestConsumersObject.Contract.subscription_reason,
                    TariffType = requestConsumersObject.Contract.tariff_type,
                    PreferredDeliveryStart = requestConsumersObject.Contract.preferred_delivery_start,
                    SaasContractId = requestConsumersObject.Contract.saas_contract_id,
                    SaasCustomerId = requestConsumersObject.Contract.saas_customer_id,
                    ThirdPartySalespartner = requestConsumersObject.Contract.third_party_salespartner,
                    ConsumptionBeforeBatteryInstallation =
                        Convert.ToInt32(requestConsumersObject.Contract.consumption_before_battery_installation),
                    FormerSupplierContractTerminated =
                        Convert.ToBoolean(requestConsumersObject.Contract.former_supplier_contract_terminated) == true ? true : false,
                    FormerSupplierFirstName = requestConsumersObject.Contract.former_supplier_first_name,
                    FormerSupplierLastName = requestConsumersObject.Contract.former_supplier_last_name,
                    FormerSupplierContractTerminationDate =
                        requestConsumersObject.Contract.former_supplier_contract_termination_date,
                }
            };
            
            returnObj.ContractAddress.Add(new ContractAddress
                {
                    HouseNumber = requestConsumersObject.Contract.deliv_address_house_number,
                    City = requestConsumersObject.Contract.deliv_address_city,
                    Zipcode = requestConsumersObject.Contract.deliv_address_zipcode,
                    Addition = requestConsumersObject.Contract.deliv_address_addition,
                    Street = requestConsumersObject.Contract.deliv_address_street,
                }
            );
            
            returnObj.ContractAddress.Add(new ContractAddress
            {
                HouseNumber = requestConsumersObject.Contract.bill_address_house_number ?? requestConsumersObject.Contract.deliv_address_house_number,
                City = requestConsumersObject.Contract.bill_address_city ?? requestConsumersObject.Contract.deliv_address_city,
                Zipcode = requestConsumersObject.Contract.bill_address_zipcode ?? requestConsumersObject.Contract.deliv_address_zipcode,
                Addition = requestConsumersObject.Contract.bill_address_addition ?? requestConsumersObject.Contract.deliv_address_addition,
                Street = requestConsumersObject.Contract.bill_address_street ?? requestConsumersObject.Contract.deliv_address_street,
            });
            
            
            return returnObj;
        }

        public CreateContractRequest Transform(RequestUnverifiedSavingsObject requestConsumersObject)
        {
            var returnObj = new CreateContractRequest
            {
                ContractAddress = new List<ContractAddress>(),
                ContractMasterData = new ContractMasterData
                {
                    // UserId = long.Parse(requestConsumersObject.User.Userid),
                },
                ContractBankData =
                    new ContractBankData
                    {
                        Iban = requestConsumersObject.Contract.BankDataIban,
                        FirstName = requestConsumersObject.Contract.BankDataFirstName,
                        LastName = requestConsumersObject.Contract.BankDataLastName,
                        PaymentMethod = requestConsumersObject.Contract.PaymentMethod.ToString(),
                        SepaDateUtc = requestConsumersObject.Contract.SepaDateUtc,
                        SepaReference = requestConsumersObject.Contract.SepaReference
                    },
                ContractEntity = new ContractEntity
                {
                    Birthday = requestConsumersObject.Contract.Birthday,
                    Email = requestConsumersObject.Contract.Email,
                    Salutation = requestConsumersObject.Contract.Salutation,
                    Telephone = requestConsumersObject.Contract.Telephone,
                    Title = requestConsumersObject.Contract.Title,
                    Username = requestConsumersObject.Contract.Username,
                    AccountingEmail = requestConsumersObject.Contract.AccountingEmail,
                    CompanyName = requestConsumersObject.Contract.CompanyName,
                    FirstName = requestConsumersObject.Contract.FirstName,
                    LastName = requestConsumersObject.Contract.LastName,
                    IsBusiness = requestConsumersObject.Contract.IsBusiness,
                    IsSmallBusiness = requestConsumersObject.Contract.IsSmallBusiness,
                    TaxNumber = requestConsumersObject.Contract.TaxNumber,
                },
                ContractData = new ContractData
                {
                    AnnualConsumption = double.Parse(requestConsumersObject.Contract.AnnualConsumption),
                    MeterId = requestConsumersObject.Contract.MeterId,
                    MeteringpointId = requestConsumersObject.Contract.MeteringPointId,
                    MeterRole = requestConsumersObject.Contract.MeterRole,
                    OrderDate = requestConsumersObject.Contract.OrderDate,
                    PreviousProvider = requestConsumersObject.Contract.PreviousProvider,
                    SubscriptionReason = requestConsumersObject.Contract.SubscriptionReason,
                    TariffType = requestConsumersObject.Contract.TariffType,
                    PreferredDeliveryStart = requestConsumersObject.Contract.PreferredDeliveryStart,
                    SaasContractId = null,
                    SaasCustomerId = null,
                    ThirdPartySalespartner = null,
                    ConsumptionBeforeBatteryInstallation =
                        Convert.ToInt32(requestConsumersObject.Contract.ConsumptionBeforeBatteryInstallation),
                    FormerSupplierContractTerminated =
                        requestConsumersObject.Contract.FormerSupplierContractTerminated == "true" ? true : false,
                    FormerSupplierFirstName = requestConsumersObject.Contract.FormerSupplierFirstName,
                    FormerSupplierLastName = requestConsumersObject.Contract.FormerSupplierLastName,
                    FormerSupplierContractTerminationDate =
                        requestConsumersObject.Contract.FormerSupplierContractTerminationDate,
                }
            };
            
            returnObj.ContractAddress.Add(new ContractAddress
                {
                    HouseNumber = requestConsumersObject.Contract.DelivAddressHouseNumber,
                    City = requestConsumersObject.Contract.DelivAddressCity,
                    Zipcode = requestConsumersObject.Contract.DelivAddressZipcode,
                    Addition = requestConsumersObject.Contract.DelivAddressAddition,
                    Street = requestConsumersObject.Contract.DelivAddressStreet,
                }
            );
            
            returnObj.ContractAddress.Add(new ContractAddress
            {
                HouseNumber = requestConsumersObject.Contract.BillAddressHouseNumber ?? requestConsumersObject.Contract.DelivAddressHouseNumber,
                City = requestConsumersObject.Contract.BillAddressCity ?? requestConsumersObject.Contract.DelivAddressCity,
                Zipcode = requestConsumersObject.Contract.BillAddressZipcode ?? requestConsumersObject.Contract.DelivAddressZipcode,
                Addition = requestConsumersObject.Contract.BillAddressAddition ?? requestConsumersObject.Contract.DelivAddressAddition,
                Street = requestConsumersObject.Contract.BillAddressStreet ?? requestConsumersObject.Contract.DelivAddressStreet,
            });

            return returnObj;
        }
    }
}
//returning object by assigning all the varibles from the properties and class.