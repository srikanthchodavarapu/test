using System.Collections.Generic;

namespace Sma.Sp.TariffService.Domain.Entities
{ // CreateContractRequestclass is having properties for Get ;Set ; the data and  the fields are of
  // type list and object which has predefined model where properties of the objects are declare for get;set.
    // TODO: JW: Minor: Properties of Domain Entities should only be SETable via the constructor.
    public class CreateContractRequest
    {
        public ContractMasterData ContractMasterData { get; set; }
        public ContractEntity ContractEntity { get; set; }
        public List<ContractAddress> ContractAddress { get; set; }
        public ContractBankData ContractBankData { get; set; }
        public ContractData ContractData { get; set; }
    }
}