﻿namespace Sma.Sp.TariffService.Web.Service
{ //this is a config file for authentication the configuration for get;set; the variables
    /// <summary>
    /// The authentication configs
    /// </summary>
    public class AuthenticationConfigs
    {
        /// <summary>
        /// Gets or sets issuer
        /// </summary>
        public string Issuer { get; set; }

        /// <summary>
        /// Gets or sets RequireHttps
        /// </summary>
        public bool RequireHttps { get; set; }

        /// <summary>
        /// Gets or sets Audience
        /// </summary>
        public string Audience { get; set; }

        /// <summary>
        /// Gets or sets WebProxy
        /// </summary>
        public string WebProxy { get; set; }
    }
}
