using System;
using System.Globalization;
using System.IO;
using System.Net.Http;
using System.Reflection;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Rewrite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.PlatformAbstractions;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using Sma.Sp.Libraries.WebApiBaseClient.Common.Resource;
using Sma.Sp.WebApiExtensions.AspNetCore;
using Sma.Sp.WebApiExtensions.AspNetCore.Authentication;
using Sma.Sp.WebApiExtensions.AspNetCore.CorrelationLogging;
using Sma.Sp.WebApiExtensions.AspNetCore.Security;
using SMA.Logging;
using AutoMapper;
using Hangfire;
using Sma.Sp.AuthenticationService.Api.Interfaces.UserAuths;
using Sma.Sp.TariffService.Domain.Interfaces;
using Sma.Sp.TariffService.Domain.Services;
using Sma.Sp.TariffService.Infrastructure.Model.Db;
using Sma.Sp.TariffService.Infrastructure.Repositories;
using Sma.Sp.TariffService.Infrastructure.SunnyPortal;
using Sma.Sp.TariffService.Infrastructure.Tariff;
using Sma.Sp.TariffService.Infrastructure.Tariff.Validation;
using Sma.Sp.TariffService.Web.Service.Models.Mapping;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.TokenObject;

namespace Sma.Sp.TariffService.Web.Service
{ /* this is the main class for definicing DI(Dependency injection) providing
   * configuration settings ans services, using and defining middleware, routing , importing swagger
   use of singelton , versioning , configuration settings and importing all other interfaces*/
    public class Startup
    {
        static string XmlCommentsFilePath
        {
            get
            {
                var basePath = PlatformServices.Default.Application.ApplicationBasePath;
                var fileName = typeof(Startup).GetTypeInfo().Assembly.GetName().Name + ".xml";
                return Path.Combine(basePath, fileName);
            }
        }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.

        #region called by runtime

        public void ConfigureServices(IServiceCollection services)
        {
            try
            {
                services.AddHealthChecks();
                services.AddControllersWithViews();

                services.AddAutoMapper(typeof(Startup));

                if (!string.IsNullOrWhiteSpace(Configuration.GetConnectionString("HangfireConnection")))
                {
                    services.AddHangfire(c => c.UseSqlServerStorage(Configuration.GetConnectionString("HangfireConnection")));
                }

                services.AddCors();

                services.AddScoped<ICreateContractRequestMapper, CreateContractRequestMapper>();
                services.AddScoped<IConsumerObjectMapper, ConsumerObjectMapper>();
                services.AddSingleton<TokenObject>();
                services.AddScoped<ConfigSettings>();
                services.PostConfigure<ConfigSettings>(myOptions =>
                {
                    var mode= Configuration["AppConfig:IsProduction"] == "true" ? "Production" : "Testing";
                    myOptions.ClientSecret = Configuration.GetSection("InfrastructureConfiguration").GetSection("LumenazaService").GetSection(mode).GetSection("ClientSecret").Value;
                    myOptions.GrantType = Configuration.GetSection("InfrastructureConfiguration").GetSection("LumenazaService").GetSection(mode).GetSection("GrantType").Value;
                    myOptions.Password = Configuration.GetSection("InfrastructureConfiguration").GetSection("LumenazaService").GetSection(mode).GetSection("Password").Value;
                    myOptions.UserName = Configuration.GetSection("InfrastructureConfiguration").GetSection("LumenazaService").GetSection(mode).GetSection("UserName").Value;
                    myOptions.EndPoint = Configuration.GetSection("InfrastructureConfiguration").GetSection("LumenazaService").GetSection(mode).GetSection("EndPoint").Value;
                    myOptions.ClientId = Configuration.GetSection("InfrastructureConfiguration").GetSection("LumenazaService").GetSection(mode).GetSection("ClientId").Value;
                });

                ConfigureDbContext(services);
                
                services.Configure<IISServerOptions>(options => { options.AutomaticAuthentication = false; });


                services.AddControllers()
                        .AddNewtonsoftJson(options =>
                                           {
                                               // options.SerializerSettings.Converters.Add(new Newtonsoft.Json.Converters.StringEnumConverter());
                                               options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                                           });

                services.AddControllers(o => { o.Conventions.Add(new ControllerDocumentationConvention()); });

                AddVersioning(services);

                AddSwagger(services);

                services.AddOptions();

                ConfigureInfrastructureInterfaces(services);
                ConfigureDomainInterfaces(services);
                ConfigureControllerInterfaces(services);
            }
            catch (Exception e)
            {
                typeof(Startup).Log().Log(LogLevel.Error, new { servicesSuccessfullyConfigured = false });
                throw;
            }

            typeof(Startup).Log().Log(LogLevel.Info, new { servicesSuccessfullyConfigured = true });
        }

        public void Configure(IApplicationBuilder app,
                              IHostingEnvironment env,
                              IApiVersionDescriptionProvider provider,
                              IServiceProvider serviceProvider,
                              IContractService contractService,
                              ILumenazaContractRepository lumenazaContractRepo,
                              IValidationService validationService,
                              IUserAuthResource userAuthResource)
        {
            try
            {
                if (env.IsDevelopment())
                {
                    app.UseDeveloperExceptionPage();
                }
                else
                {
                    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                    app.UseHsts();
                }

                ConfigureMiddleware(app);

                app.UseRouting();
                app.UseAuthentication();
                app.UseAuthorization();

                ConfigureEndpoints(app);
                ConfigureSwagger(app, provider);
                ConfigureHangfire(app);
                ConfigureCronjob(contractService);
            }
            catch (Exception e)
            {
                typeof(Startup).Log().Log(LogLevel.Error, new { applicationSuccessfullyConfigured = false });
                throw;
            }

            typeof(Startup).Log().Log(LogLevel.Info, new { applicationSuccessfullyConfigured = true });
        }

        #endregion

        #region private

        private static void AddMvc(IServiceCollection services)
        {
            services.AddMvc(options =>
                            {
                                options.EnableEndpointRouting = false;
                                options.Filters.Add(typeof(ActionFilter.ValidatorActionFilter));
                            })
                    .AddNewtonsoftJson(options =>
                                       {
                                           options.SerializerSettings.Converters.Add(new StringEnumConverter());
                                           options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
                                           options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Unspecified;
                                           options.SerializerSettings.DateFormatHandling = DateFormatHandling.IsoDateFormat;
                                           options.SerializerSettings.Formatting = Formatting.Indented;
                                           options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                                       })
                    .SetCompatibilityVersion(CompatibilityVersion.Version_2_2)
                    .AddFluentValidation(options => { options.RegisterValidatorsFromAssemblyContaining<Startup>(); });
        }

        private void AddSwagger(IServiceCollection services)
        {
            var buildDate = File.GetCreationTime(GetType().Assembly.Location);

            //Register Swagger
            services.AddSwaggerGen(options =>
                                   {
                                       var provider = services.BuildServiceProvider().GetRequiredService<IApiVersionDescriptionProvider>();
                                       options.OperationFilter<OperationParameterFilter>();
                                       foreach (var description in provider.ApiVersionDescriptions)
                                       {
                                           options.SwaggerDoc(description.GroupName,
                                                              new OpenApiInfo
                                                              {
                                                                  Title = "Contract API",
                                                                  Version =
                                                                      $"v{description.ApiVersion} - build at: {buildDate.ToString("s", CultureInfo.CurrentCulture)}"
                                                              });
                                       }

                                       // integrate xml comments
                                       options.IncludeXmlComments(XmlCommentsFilePath);

                                       //options.IncludeXmlComments(XmlCommentsForModelFilePath);
                                   });
        }

        private static void AddVersioning(IServiceCollection services)
        {
            services.AddVersionedApiExplorer(o =>
                                             {
                                                 o.GroupNameFormat = "'v'VVV";
                                                 o.SubstituteApiVersionInUrl = true;
                                                 o.AssumeDefaultVersionWhenUnspecified = false;
                                             });

            services.AddApiVersioning(o =>
                                      {
                                          o.ReportApiVersions = true;
                                          o.DefaultApiVersion = new ApiVersion(1, 0);
                                          o.AssumeDefaultVersionWhenUnspecified = true;
                                      });
        }

        private void ConfigureControllerInterfaces(IServiceCollection services)
        {
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSingleton<IInfrastructureConfiguration>(sp => Configuration.GetSection("InfrastructureConfiguration")
                                                                                   .Get<InfrastructureConfiguration>());
            services.AddScoped<ISmaAuthenticationService, SmaAuthenticationService>();
            services.AddScoped<IContractService, ContractService>();
            services.AddScoped<ILumenazaContractRepository, LumenazaContractRepository>();
            services.AddScoped<IValidationService, ValidationService>();
            services.AddSingleton<IUserAuthResource>(s => new UserAuthResource(new HttpClient(),
                                                                               Configuration["InfrastructureConfiguration:SMAUserAuthResourceEndPoint"],
                                                                               ClientContentType.Json));
        }

        private void ConfigureDbContext(IServiceCollection services)
        {
            services.AddDbContext<TariffServiceDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("TariffServiceDbContext")));
        }

        private void ConfigureDomainInterfaces(IServiceCollection services)
        {
            services.AddScoped<IContractService, ContractService>();
            services.AddScoped<ILumenazaContractRepository, LumenazaContractRepository>();
            services.AddScoped<IContractRepository, ContractRepository>();
            services.AddScoped<IValidationService, ValidationService>();
        }

        private static void ConfigureInfrastructureInterfaces(IServiceCollection services)
        {
            services.AddSingleton<Infrastructure.Security.Mapper.IPrivilegeCollectionMapper, Infrastructure.Security.Mapper.PrivilegeCollectionMapper>();
            services.AddScoped<IGoogleRecaptcha, GoogleRecaptcha>();

            var mapperConfig = new MapperConfiguration(mc => { mc.AddProfile(new MappingProfile()); });

            IMapper mapper = mapperConfig.CreateMapper();
            services.AddSingleton(mapper);
            services.AddHttpClient();
        }


        #endregion


        private void ConfigureSwagger(IApplicationBuilder app, IApiVersionDescriptionProvider provider)
        {
            app.UseSwagger();
            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), 
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(options =>
                             {
                                 foreach (var description in provider.ApiVersionDescriptions)
                                 {
                                     options.SwaggerEndpoint($"./swagger/{description.GroupName}/swagger.json", description.GroupName.ToUpperInvariant());
                                     options.RoutePrefix = string.Empty;
                                 }
                             });

            var option = new RewriteOptions();
            option.AddRedirect("^$", "index.html");
            app.UseRewriter(option);
        }

        private void ConfigureHangfire(IApplicationBuilder app)
        {
            if (!string.IsNullOrWhiteSpace(Configuration.GetConnectionString("HangfireConnection")))
            {
                app.UseHangfireServer();
                app.UseHangfireDashboard("/hangfire");
            }
        }

        private void ConfigureMiddleware(IApplicationBuilder app)
        {
            app.UseMiddleware<CorrelationLoggingMiddleware>(Options.Create(new CorrelationLoggerOptions
            {
                ReadHeader = true,
                DumpFilter = new UrlDumpFilter(new[]
                                                    {
                                                                        UrlDumpFilter.BuildPattern(HttpMethod.Post, "api/v1/token"),
                                                                        UrlDumpFilter.BuildPattern(HttpMethod.Post, "api/v1/users"),
                                                                        UrlDumpFilter.BuildPattern(HttpMethod.Put,
                                                                            "api/v1/users/.*/password"),
                                                                        UrlDumpFilter.BuildPattern(HttpMethod.Put,
                                                                            "api/v1/userpasswordreset")
                                                                    },
                                                null)
            }));
            app.UseMiddleware<ExceptionMiddleware>();
        }

        private void ConfigureCronjob(IContractService contractService)
        {
            if (Convert.ToBoolean(Configuration["CRON:EnableReCheckInCompleteContractCreation"]))
                RecurringJob.AddOrUpdate(
                                         () => contractService.CheckIncompleteContracts(), Configuration["CRON:ReCheckInCompleteContractCreation"]);
        }

        private void ConfigureEndpoints(IApplicationBuilder app)
        {
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHealthChecks("/hc");
            });
        }
    }
}