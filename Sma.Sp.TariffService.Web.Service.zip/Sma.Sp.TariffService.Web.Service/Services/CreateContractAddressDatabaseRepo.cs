﻿using Sma.Sp.TariffService.Api.Interfaces.LumenazaApi.ConsumersObject;
using Sma.Sp.TariffService.Api.Interfaces.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sma.Sp.TariffService.Web.Service.Services
{
    public class CreateContractAddressDatabaseRepo : DatabaseService<ContractAddress>, ICreateContractAddressDatabaseRepo
    {
        public CreateContractAddressDatabaseRepo(string connectionStrings) : base(connectionStrings)
        {
        }
        public List<ContractAddress> SelectCompleteList()
        {
            throw new NotImplementedException();
        }

        public List<ContractAddress> SelectIncompleteList()
        {
            throw new NotImplementedException();
        }

        public List<ContractAddress> SelectWaitList()
        {
            throw new NotImplementedException();
        }
    }
}
