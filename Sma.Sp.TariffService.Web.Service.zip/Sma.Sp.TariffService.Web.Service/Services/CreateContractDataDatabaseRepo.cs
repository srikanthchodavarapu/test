﻿using Sma.Sp.TariffService.Api.Interfaces.LumenazaApi.ConsumersObject;
using Sma.Sp.TariffService.Api.Interfaces.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sma.Sp.TariffService.Web.Service.Services
{
    public class CreateContractDataDatabaseRepo : DatabaseService<ContractData>, ICreateContractDataDatabaseRepo
    {
        public CreateContractDataDatabaseRepo(string connectionStrings) : base(connectionStrings)
        {
        }
        public ContractData GetByEmail(string email)
        {
            throw new NotImplementedException();
        }

        public List<ContractData> SelectCompleteList()
        {
            throw new NotImplementedException();
        }

        public List<ContractData> SelectIncompleteList()
        {
            throw new NotImplementedException();
        }

        public List<ContractData> SelectWaitList()
        {
            throw new NotImplementedException();
        }
    }
}
