﻿using Sma.Sp.TariffService.Api.Interfaces.LumenazaApi.ConsumersObject;
using Sma.Sp.TariffService.Api.Interfaces.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sma.Sp.TariffService.Web.Service.Services
{
    public class CreateContractBankDataDatabaseRepo : DatabaseService<ContractBankData>, ICreateContractBankDataDatabaseRepo
    {
        public CreateContractBankDataDatabaseRepo(string connectionStrings) : base(connectionStrings)
        {
        }
        public bool Insert(ContractBankData item)
        {
            throw new NotImplementedException();
        }

        public List<ContractBankData> SelectCompleteList()
        {
            throw new NotImplementedException();
        }

        public List<ContractBankData> SelectIncompleteList()
        {
            throw new NotImplementedException();
        }

        public List<ContractBankData> SelectWaitList()
        {
            throw new NotImplementedException();
        }

        public bool Update(string id, ContractBankData item)
        {
            throw new NotImplementedException();
        }

        ContractBankData IDatabaseRepo<ContractBankData>.Select(string id)
        {
            throw new NotImplementedException();
        }
    }
}
