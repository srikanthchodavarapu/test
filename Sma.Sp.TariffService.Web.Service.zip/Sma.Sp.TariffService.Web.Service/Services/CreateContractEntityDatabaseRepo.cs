﻿using Sma.Sp.TariffService.Api.Interfaces.LumenazaApi.ConsumersObject;
using Sma.Sp.TariffService.Api.Interfaces.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sma.Sp.TariffService.Web.Service.Services
{
    public class CreateContractEntityDatabaseRepo : DatabaseService<ContractEntity>, ICreateContractEntityDatabaseRepo
    {
        public CreateContractEntityDatabaseRepo(string connectionStrings) : base(connectionStrings)
        {
        }
        public CreateContractData GetByEmail(string email)
        {
            throw new NotImplementedException();
        }

        public List<ContractEntity> SelectCompleteList()
        {
            throw new NotImplementedException();
        }

        public List<ContractEntity> SelectIncompleteList()
        {
            throw new NotImplementedException();
        }

        public List<ContractEntity> SelectWaitList()
        {
            throw new NotImplementedException();
        }
    }
}
