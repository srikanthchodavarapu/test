﻿namespace Sma.Sp.TariffService.Web.Service
{ // this is InfrastructureConfiguration configuration class which is implemeting IInfrastructureConfiguration
   //this is used to set WebProxyUri, AuthorizationServiceBasePath,AssetServiceBasePath thsese properties .
    /// <summary>
    /// The InfrastructureConfiguration class
    /// </summary>
    public class InfrastructureConfiguration : IInfrastructureConfiguration
    {
        public string WebProxyUri { get; set; }
        public string AuthorizationServiceBasePath { get; set; }
        public string AssetServiceBasePath { get; set; }

    }
}
