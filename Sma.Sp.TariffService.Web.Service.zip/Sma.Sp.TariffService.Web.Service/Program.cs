﻿using System;
using System.IO;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using SMA.Logging;
using SMA.Logging.NLog;

namespace Sma.Sp.TariffService.Web.Service
{ // this is the main class for registering and declaring IIS settings, startup class, timeout and other web host setting for building up the project
    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                LoggerFactory.InitializeWith<NLogProvider>();
                CreateWebHostBuilder(args).Build().Run();
                typeof(Program).Log().Log(LogLevel.Info, new { webServiceStarted = true });
            }
            catch (Exception e)
            {
	            if (e.Message.Contains("IDX20803"))
	            {
		            var ex = new ApplicationException("Keycloak issue", e);
                    typeof(Program).Log().Log(LogLevel.Error, new { errorStartingWebservice = true });
                    throw ex;
	            }
	            else
	            {
                    typeof(Program).Log().Log(LogLevel.Error, new { errorStartingWebservice = true });
                    throw;
	            }
            }
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseKestrel()
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseIIS()
                .UseShutdownTimeout(TimeSpan.FromSeconds(10))
                .UseStartup<Startup>();
    }
}
