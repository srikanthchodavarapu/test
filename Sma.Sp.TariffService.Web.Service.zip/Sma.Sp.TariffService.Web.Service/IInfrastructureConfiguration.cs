﻿namespace Sma.Sp.TariffService.Web.Service
{ // this is the interface which needs to be implement to get and set the AssetServiceBasePath,AuthorizationServiceBasePath,WebProxyUri.
    public interface IInfrastructureConfiguration
    {
        string AssetServiceBasePath { get; set; }
        string AuthorizationServiceBasePath { get; set; }
        string WebProxyUri { get; set; }
    }
}