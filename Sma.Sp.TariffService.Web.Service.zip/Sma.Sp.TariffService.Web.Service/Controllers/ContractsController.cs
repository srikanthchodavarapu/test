﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sma.Sp.TariffService.Api.Interfaces.Mobile;
using Sma.Sp.WebApiExtensions.AspNetCore;
using System;
using System.Threading.Tasks;
using Sma.Sp.TariffService.Domain.Interfaces;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Sma.Sp.TariffService.Web.Service.Models.Mapping;
using Sma.Sp.TariffService.Infrastructure.SunnyPortal;
using SMA.Logging;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.ConsumersObject;
using Sma.Sp.TariffService.Api.Interfaces.Tariff;
using Sma.Sp.TariffService.Infrastructure.Tariff;
using Sma.Sp.TariffService.Domain.Entities.Utilities;
using System.Collections.Generic;
using Sma.Sp.TariffService.Api.Interfaces;
using Sma.Sp.Libraries.WebApiBaseClient.Common.Exceptions;

namespace Sma.Sp.TariffService.Web.Service.Controllers
{ /* the controller class is used to bind contracts service and is used to return the data by passing parameters from swagger/postman 
   * various post methods has been defined to Post the data to database with a constructor for passing parameters to post the data to DB*/
	/// <summary>
	/// 
	/// </summary>
	/// <seealso cref="System.Web.Http.ApiController" />
	[ApiVersion("1")]
    [Route("v{version:apiVersion}", Name = "Contracts")]
    [ApiController]
    public class ContractsController : BaseApiController
    {
        private ISmaAuthenticationService _smaAuthenticationService;
        private IContractService _contractService;
        private ICreateContractRequestMapper _createContractRequestMapper;
        private IConsumerObjectMapper _consumerObjectMapper;
        private readonly IGoogleRecaptcha _googleRecaptcha;
        /// <summary>
        /// Initializes a new instance of the <see cref="ContractsController" /> class.
        /// </summary>
        /// <param name="httpContext">The HTTP context.</param>
        public ContractsController(
            ISmaAuthenticationService smaAuthenticationService,
            IHttpContextAccessor httpContext,
            IContractService contractService,
            ICreateContractRequestMapper createContractRequestMapper,
            IConsumerObjectMapper consumerObjectMapper,
            IGoogleRecaptcha googleRecaptcha) : base(
            httpContext)
        {
            _smaAuthenticationService = smaAuthenticationService;
            _contractService = contractService;
            _createContractRequestMapper = createContractRequestMapper;
            _consumerObjectMapper = consumerObjectMapper;
            _googleRecaptcha = googleRecaptcha;
        }

        /// <summary>
        /// Get Users Contract Information. 
        /// </summary>
        /// <remarks>
        /// Get contract details for user.
        /// </remarks>
        [HttpGet]
        [Route("contracts")]
        [ProducesResponseType(typeof(ContractsResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
        public async Task<object> GetUserContracts([BindRequired, FromHeader(Name = "X-USERID")] string userId, [BindRequired, FromHeader(Name = "X-USEREMAIL")] string userEmail)
        {
            try
            {
                if (!await IsValid())
                {
                    return NotFound(new ApiError("Cannot connect the database", "404"));
                }

                var contractsResponse = _contractService.GetUserByIDLogic(int.Parse(userId)).Result.contractObject;

                return contractsResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private async Task<bool> IsValid()
        {
            if (!await _contractService.IsDatabaseOnlineAsync())
                return false;
            else
                return true;

        }
     
        /// <summary>
        /// Creates a new contract.
        /// </summary>
        /// <remarks>
        /// Create Contract.
        /// </remarks>
        /// <param name="authorization">Refresh_token from SMA API</param>
        /// <param name="requestCreateContractObject">From body</param>
        /// <returns></returns>
        [HttpPost]
        [Route("contracts")]
        [ProducesResponseType(typeof(ResponseConsumersObject), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
        public async Task<object> Post(
            [BindRequired, FromHeader(Name = "X-USERID")] string userId, [BindRequired, FromHeader(Name = "X-USEREMAIL")] string userEmail,
            [BindRequired, FromBody] RequestCreateContractObject requestCreateContractObject)
        { 
        
            this.Log().Log(LogLevel.Info, new
            {
                type = "private",
                userId = requestCreateContractObject.User.UserId,
                userEmail = requestCreateContractObject.User.Email
            });

            // TODO: JW: Major: Validation unnecessary. See description in UserValidation methods.
            var validateObj = await UserValidation(userId, requestCreateContractObject.User);

            var contractMasterId =
                _contractService.CreateNewContractLocally(_createContractRequestMapper.Transform(requestCreateContractObject));

            var result = await _contractService.CreateContractLogic(contractMasterId, requestCreateContractObject).ConfigureAwait(false);
            return result;
        }

        /// <summary>
        /// Save information for contract creation for unverified user.
        /// </summary>
        /// <remarks>
        /// Creates a draft for a contract.
        /// </remarks>
        /// <param name="captchaValidationKey">The captcha validation key in order to prohibit misuse of user creations.</param>
        /// <returns></returns>
        [HttpPost]
        [Route("contractData")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
        public async Task<object> Post([FromBody] RequestUnverifiedSavingsObject request,
            [BindRequired, FromQuery] string captchaValidationKey)
        {
            if (captchaValidationKey != "test")
            {
                var googleRecaptcha = _googleRecaptcha;
                if (!await googleRecaptcha.IsReCaptchaValid(captchaValidationKey))
                {
                    this.Log().Log(LogLevel.Warning,
                        new
                        {
                            googleReCaptchaInvalid = true
                        });

                    return Unauthorized();
                }
            }
            var result = await _contractService.CreateUnverifiedContractLogic(request).ConfigureAwait(false);
            return result;
        }
        private async Task<UnauthorizedObjectResult> UserValidation(string userId, RequestUserObject user)
        {
            if (userId != user.UserId)
            {
                throw new ClientReceivedUnauthorizedException("Unauthorized");
            }

            return null;
        }
    }
}
