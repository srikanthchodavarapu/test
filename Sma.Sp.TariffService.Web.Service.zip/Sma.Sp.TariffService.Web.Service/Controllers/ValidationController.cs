﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sma.Sp.TariffService.Api.Interfaces;
using Sma.Sp.WebApiExtensions.AspNetCore;
using System.Net.Http;
using System.Threading.Tasks;
using Sma.Sp.TariffService.Domain.Interfaces;
using Sma.Sp.TariffService.Domain.Entities.Utilities;
using Sma.Sp.TariffService.Infrastructure.Tariff.Validation;

namespace Sma.Sp.TariffService.Web.Service.Controllers
{ //the validation controller is used to validate address,Iban,validate market location.
  //it has a parametrised constructor to passparameter and validate data with functions.
	/// <summary>
	/// 
	/// </summary>
	/// <seealso cref="System.Web.Http.ApiController" />
	[ApiVersion("1")]
    [Route("v{version:apiVersion}")]
    [ApiController]
    public class ValidationController : BaseApiController
    {
        private IContractService _contractService;
        private IValidationService _validationService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationController" /> class.
        /// </summary>
        /// <param name="httpContext">The HTTP context.</param>
        public ValidationController(
            IHttpContextAccessor httpContext,
            IContractService contractService,
            IValidationService validationService) : base(httpContext)
        {
            _contractService = contractService;
            _validationService = validationService;
        }

        /// <summary>
        /// Validate order information. 
        /// </summary>
        /// <remarks>
        /// Check validity of the given value for order.
        /// </remarks>
        [HttpGet]
        [Route("address/validate")]
        [ProducesResponseType(typeof(OrderValidationResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(OrderValidationResponse),StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
        public async Task<object> GetIsValidAddress(
            [Microsoft.AspNetCore.Mvc.ModelBinding.BindRequired, FromQuery]
            string lastName,
            [Microsoft.AspNetCore.Mvc.ModelBinding.BindRequired, FromQuery]
            string meterId,
            [Microsoft.AspNetCore.Mvc.ModelBinding.BindRequired, FromQuery]
            string city,
            [Microsoft.AspNetCore.Mvc.ModelBinding.BindRequired, FromQuery]
            string street,
            [Microsoft.AspNetCore.Mvc.ModelBinding.BindRequired, FromQuery]
            string houseNumber,
            [Microsoft.AspNetCore.Mvc.ModelBinding.BindRequired, FromQuery]
            string postalCode
        )
        {   
            var validationOrder = new OrderValidationResponse();
            if (_contractService.IsValid(meterId, lastName, street, city, houseNumber, postalCode))
            {
                validationOrder.Exist = true;
                return Ok(validationOrder);
            }

            // TODO: JW: Remark: as used here, it's OK. But generally, we want to use exceptions (i.e. from Sma.Sp.Libraries.WebApiBaseClient.Common.Exceptions) instead of ASP.Net return objects. The short reason is that it simplifies exception and response handling (SMA exception middleware will convert the exception to a response code).
            return NotFound(validationOrder);
        }

        /// <summary>
        /// Validate market location. 
        /// </summary>
        /// <remarks>
        /// Check validity of the given value for market location.
        /// </remarks>
        [HttpGet]
        [Route("marketLocation/validate")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
        public async Task<object> GetValidateMarketLocation([FromQuery] ValidateMarketLocation request)
        {
            object response = await _validationService.ValidateMarketLocation(request.marketLocation);

            // TODO: JW: Minor: Map domain entity to a DTO of Sma.Sp.TariffService.Api.Interfaces to decouple domain objects (and changes happening there) from the service's interface.
            return response;
        }

        /// <summary>
        /// Validate IBAN.
        /// </summary>
        /// <remarks>
        /// Check validity of the given value for IBAN.
        /// </remarks>
        [HttpGet]
        [Route("iban/validate")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
        public async Task<object> GetValidateIban([FromQuery] ValidateIban request)
        {
            var response = await _validationService.ValidateBankDataIban(request);

            var responseObj = await response.Content.ReadAsAsync<object>();

            // TODO: JW: Minor: Map domain entity to a DTO of Sma.Sp.TariffService.Api.Interfaces to decouple domain objects (and changes happening there) from the service's interface.
            if (!response.IsSuccessStatusCode)
                return BadRequest(Helper.RenameKeysToCamelCase(responseObj));

            return Ok(responseObj);
        }
    }
}