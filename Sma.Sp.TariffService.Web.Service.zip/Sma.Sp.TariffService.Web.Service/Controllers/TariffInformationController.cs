﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.PriceObject;
using Sma.Sp.TariffService.Domain.Entities.MarketPartners;
using Sma.Sp.TariffService.Domain.Entities.PriceObject;
using Sma.Sp.TariffService.Domain.Entities.Utilities;
using Sma.Sp.TariffService.Domain.Interfaces;
using Sma.Sp.WebApiExtensions.AspNetCore;
using System;
using System.ComponentModel;
using System.Threading.Tasks;

namespace Sma.Sp.TariffService.Web.Service.Controllers
{ //the controller is used to get the tgarrif information from database and service .
  //this is used to return the tarrif info as a json data.it has a constructor and methods to get the data.
	/// <summary>
	/// Get tariff information ex. prices, co2, providers
	/// </summary>
	/// <seealso cref="System.Web.Http.ApiController" />
	[ApiVersion("1")]
    [Route("v{version:apiVersion}/tariff", Name = "Tariff Information")]
    [ApiController]
    public class TariffInformationController : BaseApiController
    {
        private ILumenazaContractRepository _lumenazaContractRepo;

        //private ILogRepo _logService;
        /// <summary>
        /// Initializes a new instance of the <see cref="TariffInformationController" /> class.
        /// </summary>
        /// <param name="httpContext">The HTTP context.</param>
        public TariffInformationController(
            IHttpContextAccessor httpContext, ILumenazaContractRepository lumenazaContractRepo
        ) : base(httpContext)
        {
            _lumenazaContractRepo = lumenazaContractRepo;
        }


        /// <summary>
        /// Get prices
        /// </summary>
        /// <remarks>
        /// Get the prices.
        /// </remarks>
        [HttpGet]
        [Route("provider/{providerName}/tariffs/{tariffType}/prices")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
        public async Task<object> GetPrice([DefaultValue("lumenaza")]string providerName, [DefaultValue("sma_community_strom")] string tariffType, [FromQuery] PriceRequest request)
        {
            try
            {
                if (request.consumption == 0) //Consumption is not passed as query parameter
                {
                    return BadRequest(new ApiError("consumption: This field is required.", "400"));
                }

                if (tariffType != request.tariffType)
                {
                    return BadRequest(new ApiError("tariffType mismatch", "400"));
                }

                switch (providerName)
                {
                    case "lumenaza":
                        {
                            var response = await _lumenazaContractRepo.GetPrice(request);
                            return Ok(response);
                        }
                    default: return BadRequest(new ApiError("providerName unknown", "400"));
                } 

            }
            catch (Exception ex)
            {
                return BadRequest(new ApiError("Bad Request", "400"));
            }
        }

        /// <summary>
        /// Get prices CO2 saving
        /// </summary>
        /// <remarks>
        /// Get the prices CO2 saving.
        /// </remarks>
        /// <returns></returns>
        /// <exception cref="EntityNotFoundException">zipcode={zipcode}</exception>
        [HttpGet]
        [Route("prices/co2Avoidance")]
        [ProducesResponseType(typeof(Co2Saving), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
        public async Task<object> GetPriceCo2([FromQuery] PriceCo2Request request)
        {
            try
            {
                var result = await _lumenazaContractRepo.GetPriceCo2Avoidance(request);
                return Ok(Helper.RenameKeysToCamelCase(result));
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiError("Bad Request", "400"));
            }
        }

        /// <summary>
        /// Get providers
        /// </summary>
        /// <remarks>
        /// Get the providers.
        /// </remarks>
        [HttpGet]
        [Route("providers")]
        [ProducesResponseType(typeof(Provider[]), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
        public async Task<object> GetProviders()
        {
            return Ok(await _lumenazaContractRepo.GetProvider());
        }
    }
}