﻿using System.Linq;
using System.Net;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Sma.Sp.Libraries.WebApiBaseClient.Common.Exceptions;

namespace Sma.Sp.TariffService.Web.Service.Controllers
{ //this is the controller class which binds model a parametrized constructor is defined . a method is defined to return the identity  
    /// <summary>
    /// The class BaseApiController
    /// </summary>
    public abstract class BaseApiController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContext;

        /// <summary>
        /// A new instance of <see cref="BaseApiController" />
        /// </summary>
        /// <param name="httpContext"></param>
        protected BaseApiController(IHttpContextAccessor httpContext) => _httpContext = httpContext;

        /// <summary>
        /// The Get Identity.
        /// </summary>
        /// <returns></returns>
        protected IdentityUser GetIdentity()
        {
            var claims = _httpContext.HttpContext.User.Claims.ToList();
            var identity = _httpContext.HttpContext.User.Identity;
            if (!identity.IsAuthenticated)
            {
                throw new ClientReceivedUnauthorizedException("Unauthorized");
            }
            return new IdentityUser()
            {
                Id = claims.FirstOrDefault(c => c.Type == "uid")?.Value,
                UserName = claims.FirstOrDefault(c => c.Type == "preferred_username")?.Value,
                Email = claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value
            };
        }

        protected string SubstringBearer(string token)
        {
            if (token.StartsWith("Bearer "))
            {
                return token.Substring(7, token.Length - 7);
            }
            return null;
        }
    }
}
