﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Sma.Sp.Common;
using Sma.Sp.Libraries.HelperExtensions.Exceptions;
using Sma.Sp.TariffService.Api.Interfaces.LumenazaApi.TokenObject;
using Sma.Sp.TariffService.Api.Interfaces.Service;
using Sma.Sp.TariffService.Api.Interfaces.SMAUser;
using Sma.Sp.TariffService.Web.Service.Constants;
using Sma.Sp.TariffService.Web.Service.Services;
using Sma.Sp.WebApiExtensions.AspNetCore;
using Sma.Sp.WebApiExtensions.AspNetCore.Security;
using SMA.Runtime.Logging;

namespace Sma.Sp.TariffService.Web.Service.Controllers
{    /// <summary>
     /// 
     /// </summary>
     /// <seealso cref="System.Web.Http.ApiController" />
    [ApiVersion("1")]
    [Route("v{version:apiVersion}/user")]
    [ApiController]
    public class UserController : BaseApiController
    {
        private ISMAUserService _sMAUserService;
        /// <summary>
        /// Initializes a new instance of the <see cref="UserController" /> class.
        /// </summary>
        /// <param name="httpContext">The HTTP context.</param>
        public UserController(ISMAUserService sMAUserService, IHttpContextAccessor httpContext) : base(httpContext)
        {
            _sMAUserService = sMAUserService;
        }

        /// <summary>
        /// Gets the token object by login information
        /// </summary>
        /// <param name="Login"> Login information</param>
        /// <returns></returns>
        /// <exception cref="EntityNotFoundException">Login={Login}</exception>
        [HttpPost]
        [Route("login")]
        [ProducesResponseType(typeof(TokenObject), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
        public async Task<object> PostLogin([BindRequired, FromBody] Login login)
        {
            var response = await _sMAUserService.Login(login);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<TokenObject>();
            }

            return ReturnByStatuscode(response.StatusCode, await response.Content.ReadAsAsync<object>());
        }

        /// <summary>
        /// Gets the new token object by refresh token
        /// </summary>
        /// <param name="refresh_token">Bearer {refresh_token}</param>
        /// <returns></returns>
        /// <exception cref="EntityNotFoundException">refreshToken={refreshToken}</exception>
        [HttpPost]
        [Route("refreshtoken")]
        [ProducesResponseType(typeof(TokenObject), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
        public async Task<object> PostRefreshToken([BindRequired,FromHeader] string refresh_token)
        {
            var token = SubstringBearer(refresh_token);
            var response = await _sMAUserService.RefreshToken(token);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<object>();
            }

            return ReturnByStatuscode(response.StatusCode, await response.Content.ReadAsAsync<object>());
        }

        /// <summary>
        /// Gets the user object by the SMA user token
        /// </summary>
        /// <param name="Authorization">Bearer {token}</param>
        /// <returns></returns>
        /// <exception cref="EntityNotFoundException">token={token}</exception>
        [HttpGet]
        [Route("data")]
        [ProducesResponseType(typeof(UserObject), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
        public async Task<object> GetUserObject([BindRequired, FromHeader] string Authorization)
        {
            var token = SubstringBearer(Authorization);
            SMAHttpClient client = new SMAHttpClient();
            client.AddToken(token);

            var response = await client.GetAsync("users/v1/current");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<UserObject>();
            }

            return ReturnByStatuscode(response.StatusCode, await response.Content.ReadAsAsync<object>());
        }


    }
}
