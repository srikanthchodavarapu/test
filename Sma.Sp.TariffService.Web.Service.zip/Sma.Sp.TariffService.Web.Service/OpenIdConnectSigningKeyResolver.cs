﻿using System.Linq;
using System.Net;
using System.Net.Http;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;

namespace Sma.Sp.TariffService.Web.Service
{ /* the class conatins security key , authority,web proxy settings and having parametrised constructor */
    public class OpenIdConnectSigningKeyResolver
    {
        private readonly OpenIdConnectConfiguration _openIdConfig;

        public OpenIdConnectSigningKeyResolver(string authority, bool requireHttps)
        {
            var cm = new ConfigurationManager<OpenIdConnectConfiguration>($"{authority.TrimEnd('/')}/.well-known/openid-configuration",
                new OpenIdConnectConfigurationRetriever(),
                new HttpDocumentRetriever { RequireHttps = requireHttps });
            _openIdConfig = cm.GetConfigurationAsync().Result;
        }

        public OpenIdConnectSigningKeyResolver(string authority, bool requireHttps, WebProxy webProxy)
        {
            // use proxy
            var httpClientHandler = new HttpClientHandler()
            {
                Proxy = webProxy
            };

            var httpClient = new HttpClient(httpClientHandler);
            var cm = new ConfigurationManager<OpenIdConnectConfiguration>($"{authority.TrimEnd('/')}/.well-known/openid-configuration",
                new OpenIdConnectConfigurationRetriever(),
                new HttpDocumentRetriever(httpClient) { RequireHttps = requireHttps });
            _openIdConfig = cm.GetConfigurationAsync().Result;
        }

        public SecurityKey[] GetSigningKey(string kid)
        {
            // Find the security token which matches the identifier
            return new[] { _openIdConfig.JsonWebKeySet.GetSigningKeys().FirstOrDefault(t => t.KeyId == kid) };
        }
    }
}
