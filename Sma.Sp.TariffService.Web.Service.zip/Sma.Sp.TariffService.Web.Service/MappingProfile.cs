using AutoMapper;
using Sma.Sp.TariffService.Domain.Entities.User_DefinedTableType;
using Sma.Sp.TariffService.Infrastructure.Model.Db;

namespace Sma.Sp.TariffService.Web.Service
{/* this is a mapping class for automapper user for mapping
  partial classes and entities ,the model contains fileds and 
  all the property and attributes for the described classfor mapping the data */
    /// <summary>
    /// Mapping profile for AutoMapper
    /// </summary>
    public class MappingProfile : Profile
    {
        /// <summary>
        /// Mapping profile detail
        /// </summary>
        public MappingProfile()
        {
            CreateMap<ContractMasterData, Domain.Entities.ContractMasterData>();
            CreateMap<ContractBankData, Domain.Entities.ContractBankData>();
            CreateMap<ContractEntity, Domain.Entities.ContractEntity>();
            CreateMap<ContractAddress, Domain.Entities.ContractAddress>();
            CreateMap<ContractData, Domain.Entities.ContractData>();

            CreateMap<Domain.Entities.ContractMasterData, ContractMasterData>();
            CreateMap<Domain.Entities.ContractBankData, ContractBankData>();
            CreateMap<Domain.Entities.ContractEntity, ContractEntity>();
            CreateMap<Domain.Entities.ContractAddress, ContractAddress>();
            CreateMap<Domain.Entities.ContractData, ContractData>();
        }
    }
}