﻿using Sma.Sp.TariffService.Api.Interfaces.LumenazaApi.ConsumersObject;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sma.Sp.TariffService.Api.Interfaces.Repository
{
    public interface ICreateContractBankDataDatabaseRepo: IDatabaseRepo<ContractBankData>
    {
        List<ContractBankData> SelectWaitList();
        List<ContractBankData> SelectIncompleteList();
        List<ContractBankData> SelectCompleteList();
    }
}
