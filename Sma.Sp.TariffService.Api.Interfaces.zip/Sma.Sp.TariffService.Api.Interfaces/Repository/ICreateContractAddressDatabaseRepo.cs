﻿using Sma.Sp.TariffService.Api.Interfaces.LumenazaApi.ConsumersObject;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sma.Sp.TariffService.Api.Interfaces.Repository
{
    public interface ICreateContractAddressDatabaseRepo: IDatabaseRepo<ContractAddress>
    {
        List<ContractAddress> SelectWaitList();
        List<ContractAddress> SelectIncompleteList();
        List<ContractAddress> SelectCompleteList();
    }
}
