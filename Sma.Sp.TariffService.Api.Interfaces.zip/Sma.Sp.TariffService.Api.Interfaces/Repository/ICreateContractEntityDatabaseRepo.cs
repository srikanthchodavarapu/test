﻿using System;
using System.Collections.Generic;
using System.Text;
using Sma.Sp.TariffService.Api.Interfaces.LumenazaApi.ConsumersObject;

namespace Sma.Sp.TariffService.Api.Interfaces.Repository
{
    public interface ICreateContractEntityDatabaseRepo : IDatabaseRepo<ContractEntity>
    {
        List<ContractEntity> SelectWaitList();
        List<ContractEntity> SelectIncompleteList();
        List<ContractEntity> SelectCompleteList();

        CreateContractData GetByEmail(string email);
    }
}
