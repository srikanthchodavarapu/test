﻿using Sma.Sp.TariffService.Api.Interfaces.LumenazaApi.ConsumersObject;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sma.Sp.TariffService.Api.Interfaces.Repository
{
    public interface ICreateContractDataDatabaseRepo: IDatabaseRepo<ContractData>
    {
        List<ContractData> SelectWaitList();
        List<ContractData> SelectIncompleteList();
        List<ContractData> SelectCompleteList();

        ContractData GetByEmail(string email);
    }
}
