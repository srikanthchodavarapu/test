﻿using Sma.Sp.TariffService.Api.Interfaces.LumenazaApi.ConsumersObject;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sma.Sp.TariffService.Api.Interfaces.Repository
{
    public interface ICreateContractMasterDataDatabaseRepo : IDatabaseRepo<ContractMasterData>
    {
        List<ContractMasterData> SelectWaitList();
        List<ContractMasterData> SelectIncompleteList();
        List<ContractMasterData> SelectCompleteList();
    }
}
