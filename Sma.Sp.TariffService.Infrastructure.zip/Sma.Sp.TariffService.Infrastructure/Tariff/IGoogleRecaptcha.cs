using System.Threading.Tasks;

namespace Sma.Sp.TariffService.Infrastructure.Tariff
{
    // TODO: JW: Major: Since purpose of controllers is to do the authentication, this interface may directly be consumed by controller. Move interface to "Sma....Web.Service". Leave implementation of interface in infrastructure.
    public interface IGoogleRecaptcha
    {
        Task<bool> IsReCaptchaValid(string captchaValidationKey);
    }
}