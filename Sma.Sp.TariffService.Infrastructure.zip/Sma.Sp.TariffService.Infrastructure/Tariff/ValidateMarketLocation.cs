﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace Sma.Sp.TariffService.Infrastructure.Tariff.Validation
{
    public class ValidateMarketLocation
    {
        /// <summary>
        /// The market location id.
        /// </summary>
        [Required]
        [JsonProperty("marketLocation")]
        public string marketLocation { get; set; }
    }
}