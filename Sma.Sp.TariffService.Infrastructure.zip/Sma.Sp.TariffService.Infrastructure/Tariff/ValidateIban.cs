﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace Sma.Sp.TariffService.Infrastructure.Tariff.Validation
{   //Property to Get and  set IBAN for validateIban class
    public class ValidateIban
    {
        /// <summary>
        /// The international bank account number.
        /// </summary>
        [Required]
        [JsonProperty("iban")]
        public string iban { get; set; }
    }
}
