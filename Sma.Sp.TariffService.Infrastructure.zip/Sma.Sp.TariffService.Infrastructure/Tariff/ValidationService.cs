﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Sma.Sp.TariffService.Domain.Entities.LumenazaApi.TokenObject;
using Sma.Sp.TariffService.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sma.Sp.TariffService.Domain.Services;

namespace Sma.Sp.TariffService.Infrastructure.Tariff.Validation
{// service is used for validation validation on iban ,validation bank data, authenticate.
    public class ValidationService : IValidationService
    {
        private readonly IContractService _contractService;
        private IConfiguration _configuration;
        private HttpClient _httpClient;
        private TokenObject _accessToken;
        private ConfigSettings configSettings;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="contractService"></param>
        /// <param name="lumenazaLoginService"></param>
        /// <param name="configuration"></param>
        /// <param name="lumenazaLogintestService"></param>
        public ValidationService(IContractService contractService,
            IConfiguration configuration, IOptions<ConfigSettings> options)
        {
            _contractService = contractService;
            _configuration = configuration;
            configSettings = options.Value;

            // Proxy configuration
            var httpHandler = new HttpClientHandler();
            if (Convert.ToBoolean(_configuration["InfrastructureConfiguration:WebProxy:Enable"]))
            {
                httpHandler.UseProxy = true;
                httpHandler.Proxy = new WebProxy(
                    _configuration["InfrastructureConfiguration:WebProxy:Host"],
                    Convert.ToInt32(_configuration["InfrastructureConfiguration:WebProxy:Port"]));
            }

            _httpClient = new HttpClient(httpHandler);
            Task.Run(this.Authenticate).Wait();
        }


        public async Task<HttpResponseMessage> ValidateBankDataIban(ValidateIban validateIban)
        {
            var query = "iban=" + validateIban.iban;
            return await _httpClient.GetAsync("v3/validation/bank_data_iban/?" + query);

        }

        public async Task<object> ValidateMarketLocation(string marketLocation)
        {
            try
            {
                var response = await _httpClient.GetAsync("v3/validation/market_location/?" +
                                                          "market_location_identifier=" + marketLocation);

                var result = await response.Content.ReadAsStringAsync();

                JObject objResult = JObject.Parse(result);
                return objResult;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        /// <summary>
        /// Get an authentication (token) from Lumenaza service
        /// </summary>
        /// <returns>TokenObject</returns>
        private async Task Authenticate()
        {
            var endPoint = configSettings.EndPoint;
            var grantType = configSettings.GrantType;
            var userName = configSettings.UserName;
            var password = configSettings.Password;
            var clientId = configSettings.ClientId;
            var clientSecret = configSettings.ClientSecret;

            _httpClient.BaseAddress =
                new Uri(endPoint);
            _httpClient.DefaultRequestHeaders.Accept.Clear();
            _httpClient.DefaultRequestHeaders.Add("Authorization", "Basic " + System.Convert.ToBase64String(
                System.Text.Encoding.GetEncoding("ISO-8859-1")
                    .GetBytes(clientId + ":" + clientSecret)));

            var requestContent = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("grant_type", grantType),
                new KeyValuePair<string, string>("username", userName),
                new KeyValuePair<string, string>("password", password),
                new KeyValuePair<string, string>("client_id", clientId),
                new KeyValuePair<string, string>("client_secret", clientSecret),
            });

            var response = await _httpClient.PostAsync("oauth/token/", requestContent);

            if (response.IsSuccessStatusCode)
            {
                var tokenObject = await response.Content.ReadAsAsync<TokenObject>();

                _httpClient.DefaultRequestHeaders.Accept.Clear();
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", tokenObject.AccessToken);


                // TODO: JW: Major: Since this service is configured as 'scoped' in startup, each request to a controller with this class will lead to a token request to lumenaza. Consider implementing a singleton with token management (ie. refreshing tokens)
                _accessToken = tokenObject;
            }
        }
    }
}
