﻿using System;
using Newtonsoft.Json;

namespace Sma.Sp.TariffService.Infrastructure.Tariff
{    
    public class GoogleRecaptchaRespond
    {
        [JsonProperty("success")]
        public bool Success { get; set; }

        [JsonProperty("challenge_ts")]
        public DateTime ChallengeTs { get; set; }

        [JsonProperty("hostname")]
        public string hostname { get; set; }

        [JsonProperty("error-codes")]
        public object errorcodes { get; set; }
    }
}
