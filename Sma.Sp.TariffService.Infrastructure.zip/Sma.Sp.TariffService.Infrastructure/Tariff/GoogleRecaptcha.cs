﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using SMA.Logging;

namespace Sma.Sp.TariffService.Infrastructure.Tariff
{
    /// <summary>
    /// Google recaptcha management class
    /// </summary>
    public class GoogleRecaptcha : IGoogleRecaptcha
    {
        private IConfiguration _configuration;

        public GoogleRecaptcha(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<bool> IsReCaptchaValid(string captchaValidationKey)
        {
            try {
                var secretKey = _configuration["InfrastructureConfiguration:RecaptchaSecretKey"];
                if (String.IsNullOrWhiteSpace(secretKey)) return true;
                var apiUrl = "https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}";
                var requestUri = string.Format(apiUrl, secretKey, captchaValidationKey);

                var httpHandler = new HttpClientHandler();
                if (Convert.ToBoolean(_configuration["InfrastructureConfiguration:WebProxy:Enable"]))
                {
                    httpHandler.UseProxy = true;
                    httpHandler.Proxy = new WebProxy(
                        _configuration["InfrastructureConfiguration:WebProxy:Host"],
                        Convert.ToInt32(_configuration["InfrastructureConfiguration:WebProxy:Port"]));
                }
                var client = new HttpClient(httpHandler);

                var response = await client.PostAsync(requestUri, null);

                if (response.IsSuccessStatusCode)
                {
                    var data = await response.Content.ReadAsAsync<GoogleRecaptchaRespond>();
                    return data.Success;
                }
                return false;
            } catch (Exception e)
            {
                this.Log().Log(LogLevel.Warning, new
                {
                    recaptchaInvalid = true,
                    errorMessage = e.Message
                });

                throw;
            }
        }
    }
}
