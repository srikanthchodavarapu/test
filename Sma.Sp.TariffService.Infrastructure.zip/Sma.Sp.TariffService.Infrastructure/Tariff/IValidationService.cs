﻿using System.Net.Http;
using System.Threading.Tasks;

namespace Sma.Sp.TariffService.Infrastructure.Tariff.Validation
{  //its an interface for IValidationService where all methods and variable are defined which should be implemented after implementing
   //interface the methods and functions are of type Task etc..
	public interface IValidationService
	{
		Task<object> ValidateMarketLocation(string marketLocation);
		Task<HttpResponseMessage> ValidateBankDataIban(ValidateIban validateIban);
	}
}