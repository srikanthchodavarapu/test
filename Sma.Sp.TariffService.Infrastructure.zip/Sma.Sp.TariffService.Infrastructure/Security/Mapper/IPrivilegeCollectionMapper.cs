﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IPrivilegeCollectionMapper.cs" company="SMA Solar Technology AG, 34266 Niestetal, Germany">
//   Copyright (c) SMA Solar Technology AG, 34266 Niestetal, Germany.  All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System.Collections.Generic;
using Sma.Sp.Common;

namespace Sma.Sp.TariffService.Infrastructure.Security.Mapper
{
    public interface IPrivilegeCollectionMapper
    {
        IReadOnlyList<ApiPrivileges> TransformApi(IEnumerable<string> privileges);

        IReadOnlyList<ViewPrivileges> TransformView(IEnumerable<string> privileges);
    }
}
