﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PrivilegeCollectionMapper.cs" company="SMA Solar Technology AG, 34266 Niestetal, Germany">
//   Copyright (c) SMA Solar Technology AG, 34266 Niestetal, Germany.  All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using Sma.Sp.Common;

namespace Sma.Sp.TariffService.Infrastructure.Security.Mapper
{
    public class PrivilegeCollectionMapper : IPrivilegeCollectionMapper
    {
        public IReadOnlyList<ApiPrivileges> TransformApi(IEnumerable<string> privileges)
        {
            if (privileges == null)
            {
                throw new ArgumentNullException(nameof(privileges));
            }

            var apiPrivileges = new List<ApiPrivileges>();

            foreach (var privilege in privileges)
            {
                if (Enum.TryParse(privilege, out ApiPrivileges apiPriv))
                {
                    apiPrivileges.Add(apiPriv);
                }
            }

            return apiPrivileges;
        }

        public IReadOnlyList<ViewPrivileges> TransformView(IEnumerable<string> privileges)
        {
            if (privileges == null)
            {
                throw new ArgumentNullException(nameof(privileges));
            }

            var apiPrivileges = new List<ViewPrivileges>();

            foreach (var privilege in privileges)
            {
                if (Enum.TryParse(privilege, out ViewPrivileges apiPriv))
                {
                    apiPrivileges.Add(apiPriv);
                }
            }

            return apiPrivileges;
        }
    }
}
