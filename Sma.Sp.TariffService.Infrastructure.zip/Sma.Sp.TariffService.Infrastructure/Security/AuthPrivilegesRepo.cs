﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Sma.Sp.AuthenticationService.Api.Interfaces.Authorizations;
using Sma.Sp.Common;
using Sma.Sp.TariffService.Infrastructure.Security.Mapper;
using Sma.Sp.WebApiExtensions.AspNetCore.Security;

namespace Sma.Sp.TariffService.Infrastructure.Security
{
    public class AuthPrivilegesRepo : IAuthPrivilegesRepo
    {
        private readonly IAuthorizationResource _authorizationResource;
        private readonly IPrivilegeCollectionMapper _privilegeCollectionMapper;

        public AuthPrivilegesRepo(IAuthorizationResource authorizationResource, IPrivilegeCollectionMapper privilegeCollectionMapper)
        {
            _authorizationResource = authorizationResource;
            _privilegeCollectionMapper = privilegeCollectionMapper;
        }

        public async Task<IReadOnlyList<ApiPrivileges>> GetApiPrivilegesOfUserForComponent(long userId, long componentId, params ApiPrivileges[] privileges)
        {
            var privs = GetPrivilegesAsString(privileges);

            var result = await _authorizationResource.Get(userId, componentId, privs).ConfigureAwait(false);

            return _privilegeCollectionMapper.TransformApi(result);
        }

        public async Task<IReadOnlyList<ApiPrivileges>> GetApiPrivilegesOfUser(long userId, params ApiPrivileges[] privileges)
        {
            var privs = GetPrivilegesAsString(privileges);
            var result = await _authorizationResource.GetPrivilegesOfUser(userId, privs).ConfigureAwait(false);

            return _privilegeCollectionMapper.TransformApi(result);
        }

        private static string GetPrivilegesAsString(ApiPrivileges[] privileges)
        {
            string privs = null;
            if (privileges?.Length > 0)
            {
                privs = string.Join(",", privileges);
            }

            return privs;
        }

    }
}
