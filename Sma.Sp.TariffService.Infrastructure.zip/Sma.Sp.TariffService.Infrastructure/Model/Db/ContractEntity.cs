﻿using System;
using System.Collections.Generic;

namespace Sma.Sp.TariffService.Infrastructure.Model.Db
{
    public partial class ContractEntity
    {
        public ContractEntity()
        {
            ContractData = new HashSet<ContractData>();
        }

        public int Id { get; set; }
        public bool IsBusiness { get; set; }
        public bool IsSmallBusiness { get; set; }
        public string CompanyName { get; set; }
        public string Salutation { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime? Birthday { get; set; }
        public string Telephone { get; set; }
        public string Email { get; set; }
        public string AccountingEmail { get; set; }
        public string Username { get; set; }
        public string TaxNumber { get; set; }

        public virtual ICollection<ContractData> ContractData { get; set; }
    }
}
