﻿using System;
using System.Collections.Generic;

namespace Sma.Sp.TariffService.Infrastructure.Model.Db
{
    public partial class ContractBankData
    {
        public ContractBankData()
        {
            ContractData = new HashSet<ContractData>();
        }

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Iban { get; set; }
        public string PaymentMethod { get; set; }
        public DateTime? SepaDateUtc { get; set; }
        public string SepaReference { get; set; }

        public virtual ICollection<ContractData> ContractData { get; set; }
    }
}
