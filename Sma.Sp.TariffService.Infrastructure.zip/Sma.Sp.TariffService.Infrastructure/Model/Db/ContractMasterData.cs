﻿using System;

namespace Sma.Sp.TariffService.Infrastructure.Model.Db
{    
    public partial class ContractMasterData
    {
        public int Id { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }
        public string Status { get; set; }
        public long? UserId { get; set; }
        public string ExternalUserId { get; set; }
        public string ExternalContractId { get; set; }
        public int? ContractDataId { get; set; }
    }
}
