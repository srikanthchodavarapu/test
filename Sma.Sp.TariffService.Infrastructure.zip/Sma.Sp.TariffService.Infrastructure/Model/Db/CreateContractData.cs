﻿using System;

namespace Sma.Sp.TariffService.Infrastructure.Model.Db
{
    public partial class CreateContractData
    {
        public string Id { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }
        public string Status { get; set; }
        public string UserId { get; set; }
        public string ContractId { get; set; }
        public string ConsumerId { get; set; }
        public bool IsBusiness { get; set; }
        public bool IsSmallBusiness { get; set; }
        public string CompanyName { get; set; }
        public string Salutation { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime? Birthday { get; set; }
        public string Telephone { get; set; }
        public string Email { get; set; }
        public string AccountingEmail { get; set; }
        public string Username { get; set; }
        public string DelivAddressStreet { get; set; }
        public string DelivAddressHouseNumber { get; set; }
        public string DelivAddressZipcode { get; set; }
        public string DelivAddressCity { get; set; }
        public string DelivAddressAddition { get; set; }
        public DateTime? PreferredDeliveryStart { get; set; }
        public string BillAddressStreet { get; set; }
        public string BillAddressHouseNumber { get; set; }
        public string BillAddressZipcode { get; set; }
        public string BillAddressCity { get; set; }
        public string BillAddressAddition { get; set; }
        public string SubscriptionReason { get; set; }
        public string MeterId { get; set; }
        public string MeterRole { get; set; }
        public string MeteringpointId { get; set; }
        public string PreviousProvider { get; set; }
        public string AnnualConsumption { get; set; }
        public string BankDataFirstName { get; set; }
        public string BankDataLastName { get; set; }
        public string BankDataIban { get; set; }
        public string PaymentMethod { get; set; }
        public DateTime? SepaDateUtc { get; set; }
        public string SepaReference { get; set; }
        public string TariffType { get; set; }
        public string SaasCustomerId { get; set; }
        public string SaasContractId { get; set; }
        public string ThirdPartySalespartner { get; set; }
        public int FreeAmount { get; set; }
        public string ConsumptionBeforeBatteryInstallation { get; set; }
        public DateTime? OrderDate { get; set; }
        public string FormerSupplierFirstName { get; set; }
        public string FormerSupplierLastName { get; set; }
        public string FormerSupplierContractTerminated { get; set; }
        public DateTime? FormerSupplierContractTerminationDate { get; set; }
        public string TaxNumber { get; set; }
    }
}
