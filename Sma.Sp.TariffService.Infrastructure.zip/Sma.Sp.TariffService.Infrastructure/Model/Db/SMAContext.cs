﻿using Microsoft.EntityFrameworkCore;
using Sma.Sp.TariffService.Domain.Entities;

namespace Sma.Sp.TariffService.Infrastructure.Model.Db
{
    
    public partial class TariffServiceDbContext : DbContext
    {
        public TariffServiceDbContext(DbContextOptions<TariffServiceDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ContractAddress> ContractAddress { get; set; }
        public virtual DbSet<ContractBankData> ContractBankData { get; set; }
        public virtual DbSet<ContractData> ContractData { get; set; }
        public virtual DbSet<ContractEntity> ContractEntity { get; set; }
        public virtual DbSet<ContractMasterData> ContractMasterData { get; set; }
        public virtual DbSet<CreateContractData> CreateContractData { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<ContractAddress>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Addition)
                    .HasColumnName("addition")
                    .HasMaxLength(250);

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasColumnName("city")
                    .HasMaxLength(250);

                entity.Property(e => e.HouseNumber)
                    .IsRequired()
                    .HasColumnName("houseNumber")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Street)
                    .IsRequired()
                    .HasColumnName("street")
                    .HasMaxLength(250);

                entity.Property(e => e.Zipcode)
                    .IsRequired()
                    .HasColumnName("zipcode")
                    .HasMaxLength(15)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ContractBankData>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.FirstName)
                    .HasColumnName("firstName")
                    .HasMaxLength(100);

                entity.Property(e => e.Iban)
                    .IsRequired()
                    .HasColumnName("iban")
                    .HasMaxLength(32)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasColumnName("lastName")
                    .HasMaxLength(100);

                entity.Property(e => e.PaymentMethod)
                    .HasColumnName("paymentMethod")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.SepaDateUtc)
                    .HasColumnName("sepaDateUtc")
                    .HasColumnType("datetime");

                entity.Property(e => e.SepaReference)
                    .HasColumnName("sepaReference")
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ContractData>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AnnualConsumption).HasColumnName("annualConsumption");

                entity.Property(e => e.BankDataId).HasColumnName("bankDataId");

                entity.Property(e => e.BillingAddressId).HasColumnName("billingAddressId");

                entity.Property(e => e.ConsumptionBeforeBatteryInstallation).HasColumnName("consumptionBeforeBatteryInstallation");

                entity.Property(e => e.ContractEntityId).HasColumnName("contractEntityId");

                entity.Property(e => e.DeliveryAddressId).HasColumnName("deliveryAddressId");

                entity.Property(e => e.FormerSupplierContractTerminated).HasColumnName("formerSupplierContractTerminated");

                entity.Property(e => e.FormerSupplierContractTerminationDate)
                    .HasColumnName("formerSupplierContractTerminationDate")
                    .HasColumnType("date");

                entity.Property(e => e.FormerSupplierFirstName)
                    .HasColumnName("formerSupplierFirstName")
                    .HasMaxLength(100);

                entity.Property(e => e.FormerSupplierLastName)
                    .HasColumnName("formerSupplierLastName")
                    .HasMaxLength(100);

                entity.Property(e => e.FreeAmount).HasColumnName("freeAmount");

                entity.Property(e => e.MeterId)
                    .IsRequired()
                    .HasColumnName("meterId")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.MeterRole)
                    .HasColumnName("meterRole")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.MeteringpointId)
                    .HasColumnName("meteringpointId")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.OrderDate)
                    .HasColumnName("orderDate")
                    .HasColumnType("date");

                entity.Property(e => e.PreferredDeliveryStart)
                    .HasColumnName("preferredDeliveryStart")
                    .HasColumnType("date");

                entity.Property(e => e.PreviousProvider)
                    .IsRequired()
                    .HasColumnName("previousProvider")
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.SaasContractId)
                    .HasColumnName("saasContractId")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SaasCustomerId)
                    .HasColumnName("saasCustomerId")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SubscriptionReason)
                    .IsRequired()
                    .HasColumnName("subscriptionReason")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TariffType)
                    .IsRequired()
                    .HasColumnName("tariffType")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ThirdPartySalespartner)
                    .HasColumnName("thirdPartySalespartner")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.BankData)
                    .WithMany(p => p.ContractData)
                    .HasForeignKey(d => d.BankDataId)
                    .OnDelete(DeleteBehavior.SetNull)
                    .HasConstraintName("FK_ContractData_BankDataId");

                entity.HasOne(d => d.BillingAddress)
                    .WithMany(p => p.ContractDataBillingAddress)
                    .HasForeignKey(d => d.BillingAddressId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ContractData_BillingAddressId");

                entity.HasOne(d => d.ContractEntity)
                    .WithMany(p => p.ContractData)
                    .HasForeignKey(d => d.ContractEntityId)
                    .HasConstraintName("FK_ContractData_ContractEntityId");

                entity.HasOne(d => d.DeliveryAddress)
                    .WithMany(p => p.ContractDataDeliveryAddress)
                    .HasForeignKey(d => d.DeliveryAddressId)
                    .HasConstraintName("FK_ContractData_DeliveryAddressId");
            });

            modelBuilder.Entity<ContractEntity>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AccountingEmail)
                    .HasColumnName("accountingEmail")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Birthday)
                    .HasColumnName("birthday")
                    .HasColumnType("date");

                entity.Property(e => e.CompanyName)
                    .HasColumnName("companyName")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasColumnName("email")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasColumnName("firstName")
                    .HasMaxLength(100);

                entity.Property(e => e.IsBusiness).HasColumnName("isBusiness");

                entity.Property(e => e.IsSmallBusiness).HasColumnName("isSmallBusiness");

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasColumnName("lastName")
                    .HasMaxLength(100);

                entity.Property(e => e.Salutation)
                    .IsRequired()
                    .HasColumnName("salutation")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TaxNumber)
                    .HasColumnName("taxNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Telephone)
                    .HasColumnName("telephone")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Title)
                    .HasColumnName("title")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Username)
                    .HasColumnName("username")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<ContractMasterData>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.ContractDataId).HasColumnName("contractDataId");

                entity.Property(e => e.CreatedDateTime)
                    .HasColumnName("createdDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.ExternalContractId)
                    .HasColumnName("externalContractId")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExternalUserId)
                    .HasColumnName("externalUserId")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastModifiedDateTime)
                    .HasColumnName("lastModifiedDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Status)
                    .HasColumnName("status")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserId).HasColumnName("userId");
            });

            modelBuilder.Entity<CreateContractData>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.AccountingEmail)
                    .HasColumnName("accountingEmail")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.AnnualConsumption)
                    .IsRequired()
                    .HasColumnName("annualConsumption")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BankDataFirstName)
                    .HasColumnName("bankDataFirstName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BankDataIban)
                    .IsRequired()
                    .HasColumnName("bankDataIban")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BankDataLastName)
                    .IsRequired()
                    .HasColumnName("bankDataLastName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BillAddressAddition)
                    .HasColumnName("billAddressAddition")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BillAddressCity)
                    .HasColumnName("billAddressCity")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BillAddressHouseNumber)
                    .HasColumnName("billAddressHouseNumber")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BillAddressStreet)
                    .HasColumnName("billAddressStreet")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BillAddressZipcode)
                    .HasColumnName("billAddressZipcode")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Birthday)
                    .HasColumnName("birthday")
                    .HasColumnType("datetime");

                entity.Property(e => e.CompanyName)
                    .HasColumnName("companyName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ConsumerId)
                    .HasColumnName("consumerId")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ConsumptionBeforeBatteryInstallation)
                    .HasColumnName("consumptionBeforeBatteryInstallation")
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.ContractId)
                    .HasColumnName("contractId")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDateTime)
                    .HasColumnName("createdDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DelivAddressAddition)
                    .HasColumnName("delivAddressAddition")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DelivAddressCity)
                    .IsRequired()
                    .HasColumnName("delivAddressCity")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DelivAddressHouseNumber)
                    .IsRequired()
                    .HasColumnName("delivAddressHouse_number")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DelivAddressStreet)
                    .IsRequired()
                    .HasColumnName("delivAddressStreet")
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.DelivAddressZipcode)
                    .IsRequired()
                    .HasColumnName("delivAddressZipcode")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasColumnName("email")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasColumnName("firstName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.FormerSupplierContractTerminated)
                    .HasColumnName("formerSupplierContractTerminated")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.FormerSupplierContractTerminationDate)
                    .HasColumnName("formerSupplierContractTerminationDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.FormerSupplierFirstName)
                    .HasColumnName("formerSupplierFirstName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.FormerSupplierLastName)
                    .HasColumnName("formerSupplierLastName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.FreeAmount).HasColumnName("freeAmount");

                entity.Property(e => e.IsBusiness).HasColumnName("isBusiness");

                entity.Property(e => e.IsSmallBusiness).HasColumnName("isSmallBusiness");

                entity.Property(e => e.LastModifiedDateTime)
                    .HasColumnName("lastModifiedDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasColumnName("lastName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.MeterId)
                    .IsRequired()
                    .HasColumnName("meterId")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.MeterRole)
                    .HasColumnName("meterRole")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.MeteringpointId)
                    .HasColumnName("meteringpointId")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.OrderDate)
                    .HasColumnName("orderDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.PaymentMethod)
                    .HasColumnName("paymentMethod")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PreferredDeliveryStart)
                    .HasColumnName("preferredDeliveryStart")
                    .HasColumnType("datetime");

                entity.Property(e => e.PreviousProvider)
                    .IsRequired()
                    .HasColumnName("previousProvider")
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.SaasContractId)
                    .HasColumnName("saasContractId")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SaasCustomerId)
                    .HasColumnName("saasCustomerId")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Salutation)
                    .IsRequired()
                    .HasColumnName("salutation")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SepaDateUtc)
                    .HasColumnName("sepaDateUtc")
                    .HasColumnType("datetime");

                entity.Property(e => e.SepaReference)
                    .HasColumnName("sepaReference")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasColumnName("status")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SubscriptionReason)
                    .IsRequired()
                    .HasColumnName("subscriptionReason")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TariffType)
                    .IsRequired()
                    .HasColumnName("tariffType")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.TaxNumber)
                    .HasColumnName("taxNumber")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Telephone)
                    .HasColumnName("telephone")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ThirdPartySalespartner)
                    .HasColumnName("thirdPartySalespartner")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Title)
                    .HasColumnName("title")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserId)
                    .HasColumnName("userId")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Username)
                    .HasColumnName("username")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

        }
    }
}
