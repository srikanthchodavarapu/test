﻿using System;

namespace Sma.Sp.TariffService.Infrastructure.Model.Db
{
    public partial class ContractData
    {
        public int Id { get; set; }
        public int ContractEntityId { get; set; }
        public int DeliveryAddressId { get; set; }
        public int BillingAddressId { get; set; }
        public DateTime? PreferredDeliveryStart { get; set; }
        public string SubscriptionReason { get; set; }
        public string MeterId { get; set; }
        public string MeterRole { get; set; }
        public string MeteringpointId { get; set; }
        public string PreviousProvider { get; set; }
        public double AnnualConsumption { get; set; }
        public int? BankDataId { get; set; }
        public string TariffType { get; set; }
        public string SaasCustomerId { get; set; }
        public string SaasContractId { get; set; }
        public string ThirdPartySalespartner { get; set; }
        public int FreeAmount { get; set; }
        public int? ConsumptionBeforeBatteryInstallation { get; set; }
        public DateTime? OrderDate { get; set; }
        public string FormerSupplierFirstName { get; set; }
        public string FormerSupplierLastName { get; set; }
        public bool? FormerSupplierContractTerminated { get; set; }
        public DateTime? FormerSupplierContractTerminationDate { get; set; }

        public virtual ContractBankData BankData { get; set; }
        public virtual ContractAddress BillingAddress { get; set; }
        public virtual ContractEntity ContractEntity { get; set; }
        public virtual ContractAddress DeliveryAddress { get; set; }
    }
}
