﻿using System.Collections.Generic;

namespace Sma.Sp.TariffService.Infrastructure.Model.Db
{

    public  class ContractAddress
    {
        public ContractAddress()
        {
            ContractDataBillingAddress = new HashSet<ContractData>();
            ContractDataDeliveryAddress = new HashSet<ContractData>();
        }

        public int Id { get; set; }
        public string Street { get; set; }
        public string HouseNumber { get; set; }
        public string Zipcode { get; set; }
        public string City { get; set; }
        public string Addition { get; set; }

        public virtual ICollection<ContractData> ContractDataBillingAddress { get; set; }
        public virtual ICollection<ContractData> ContractDataDeliveryAddress { get; set; }
    }
}
