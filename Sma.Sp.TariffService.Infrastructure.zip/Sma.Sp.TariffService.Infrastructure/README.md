To update the database models

`dotnet ef dbcontext scaffold "Server=localhost;Database=SPS_Tariffs;User Id=sa;Password=P@ssw0rd;" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Model`