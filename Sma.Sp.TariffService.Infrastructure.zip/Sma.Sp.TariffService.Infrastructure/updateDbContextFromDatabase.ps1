Param
(
	[Parameter(Mandatory = $true,
				HelpMessage = "the nuget packages folder where GeneratorDbClient is colocated"  )]
	[string] $packagesFolderPath,
	[Parameter(Mandatory = $true,
				HelpMessage = "output folder"  )]
	[string] $outputFolder,
	[Parameter(Mandatory = $true,
				HelpMessage = "the name of the project"  )]
	[string] $projectName
)

function isLessThan {
	Param
	(
		[Parameter(Mandatory = $true,
					HelpMessage = "1.2.4"  )]
		[string] $version1,
		[Parameter(Mandatory = $true,
					HelpMessage = "43.4.2"  )]
		[string] $version2
	)

	$a=$version1.Split(".")
	$b=$version2.Split(".")
	$aLength=$a.Length
	$bLength=$b.Length
	$idx=0

	while(($idx -lt $aLength) -and ($idx -lt $bLength)) {
		$l=$a[$idx]
		$r=$b[$idx]
		$rn=[convert]::ToInt32($r, 10)
		$ln=[convert]::ToInt32($l, 10)

		if($ln -lt $rn) {
			return $true
		}

		$idx = $idx + 1
	}

	return $false
}


Write-Host "packagesFolderPath=$packagesFolderPath; outputFolder=$outputFolder"

function findGeneratorTool {
	$generatorPackageFolder ="$packagesFolderPath\sma.ennexos.dbclientgenerator"

	if(-Not(Test-Path -Path $generatorPackageFolder)) {
		Write-Host -ForegroundColor Red "can't find $generatorPackageFolder! Build project first."
		cmd /c pause | out-null
		exit 9876345
	}

	$biggestVersion="0.0.0"

	Get-ChildItem -Path "$generatorPackageFolder" -Directory | ForEach {
		$dirPath = $_.FullName
		$dirName = $_.Name

		if(isLessThan -version1 $biggestVersion -version2 $dirName) {
			$biggestVersion = $dirName
		}
	}

	if($biggestVersion -eq "0.0.0") {
		Write-Host -ForegroundColor Red "can't find a version for generator"
		exit 8645
	}

	$generatorFolder="$generatorPackageFolder\$biggestVersion\lib\netcoreapp2.2"

	return $generatorFolder
}

$generatorFolder=findGeneratorTool
$generator="$generatorFolder\GenerateDbClient.dll"
Write-Host "using generator $generator"
$curDir=(Get-Location).Path
cd $generatorFolder
Write-Host "dotnet $generator -o $outputFolder -n `"Sma.Sp.$projectName.Infrastructure.Model.Db`" -p $projectName -c `"Data Source =.\NAMEDINSTANCE;Database = SPS_$projectName;Integrated Security = true`""

dotnet $generator -o $outputFolder -n "Sma.Sp.$projectName.Infrastructure.Model.Db" -p $projectName -c "Data Source =.\NAMEDINSTANCE;Database = SPS_$projectName;Integrated Security = true"

cd $curDir
