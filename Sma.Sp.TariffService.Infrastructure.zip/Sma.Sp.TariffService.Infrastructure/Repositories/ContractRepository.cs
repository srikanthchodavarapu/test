using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http.Results;
using AutoMapper;
using EntityFrameworkExtras.EFCore;
using Microsoft.EntityFrameworkCore;
using Sma.Sp.TariffService.Domain.Entities;
using Sma.Sp.TariffService.Domain.Entities.Dtos;
using Sma.Sp.TariffService.Domain.Entities.StoredProcedureClass;
using Sma.Sp.TariffService.Domain.Entities.User_DefinedTableType;
using Sma.Sp.TariffService.Domain.Interfaces;
using Sma.Sp.TariffService.Infrastructure.Extension;
using Sma.Sp.TariffService.Infrastructure.Model.Db;
using static System.String;
using ContractAddress = Sma.Sp.TariffService.Infrastructure.Model.Db.ContractAddress;
using ContractBankData = Sma.Sp.TariffService.Infrastructure.Model.Db.ContractBankData;
using ContractData = Sma.Sp.TariffService.Infrastructure.Model.Db.ContractData;
using ContractEntity = Sma.Sp.TariffService.Infrastructure.Model.Db.ContractEntity;
using ContractMasterData = Sma.Sp.TariffService.Infrastructure.Model.Db.ContractMasterData;

namespace Sma.Sp.TariffService.Infrastructure.Repositories
{
    public class ContractRepository : IContractRepository
    {
        private readonly TariffServiceDbContext _context;
        private readonly IMapper _mapper;

        public ContractRepository(TariffServiceDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<bool> IsCanConnect()
        {
            return await _context.Database.CanConnectAsync();
        }
       
        public int Create(CreateContractRequest request)
        {
            using var transaction = _context.Database.BeginTransaction();
            try
            {
				//mapping request object to createParam
				var procedure = new CreateContractBankAddressEntity();
				procedure.ParamBankAddressEntityData = new List<ContractBankAddressEntityUDT>();

                procedure.ParamBankAddressEntityData.Add(new ContractBankAddressEntityUDT 
                {
                    //bank data ::
                    FirstName = request.ContractBankData.FirstName,
                    LastName = request.ContractBankData.LastName,
					Iban = request.ContractBankData.Iban,
					PaymentMethod = request.ContractBankData.PaymentMethod,
					SepaDateUtc = request.ContractBankData.SepaDateUtc,
					SepaReference = request.ContractBankData.SepaReference,

					// ContractAddress ::
					// INFO: At 0 always be `Delivery address`
					Street = request.ContractAddress[0].Street,
					HouseNumber = request.ContractAddress[0].HouseNumber,
					Zipcode = request.ContractAddress[0].Zipcode,
					City = request.ContractAddress[0].City,
					Addition = request.ContractAddress[0].Addition,

					// Billing Address ::
					BillStreet = request.ContractAddress[1].Street,
					BillHouseNumber = request.ContractAddress[1].HouseNumber,
					BillZipcode = request.ContractAddress[1].Zipcode,
					BillCity = request.ContractAddress[1].City,
					BillAddition = request.ContractAddress[1].Addition,

					// Contract Entity ::
					IsBusiness = request.ContractEntity.IsBusiness,
					IsSmallBusiness = request.ContractEntity.IsSmallBusiness,
					CompanyName = request.ContractEntity.CompanyName,
					Salutation = request.ContractEntity.Salutation,
					Title = request.ContractEntity.Title,
					CEFirstName = request.ContractEntity.FirstName,
					CELastName = request.ContractEntity.LastName,
					Birthday = request.ContractEntity.Birthday,
					Telephone = request.ContractEntity.Telephone,
					Email = request.ContractEntity.Email,
					AccountingEmail = request.ContractEntity.AccountingEmail,
					Username = request.ContractEntity.Username,
					TaxNumber = request.ContractEntity.TaxNumber,

					// Contract Data ::
					ContractEntityId = request.ContractData.ContractEntityId,
					DeliveryAddressId = request.ContractData.DeliveryAddressId,
					BillingAddressId = request.ContractData.BillingAddressId,
					PreferredDeliveryStart = request.ContractData.PreferredDeliveryStart,
					SubscriptionReason = request.ContractData.SubscriptionReason,
					MeterId = request.ContractData.MeterId,
					MeterRole = request.ContractData.MeterRole,
					MeteringpointId = request.ContractData.MeteringpointId,
					PreviousProvider = request.ContractData.PreviousProvider,
					AnnualConsumption = request.ContractData.AnnualConsumption,
					BankDataId = request.ContractData.BankDataId,
					TariffType = request.ContractData.TariffType,
					SaasCustomerId = request.ContractData.SaasCustomerId,
					SaasContractId = request.ContractData.SaasContractId,
					ThirdPartySalespartner = request.ContractData.ThirdPartySalespartner,
					ConsumptionBeforeBatteryInstallation = request.ContractData.ConsumptionBeforeBatteryInstallation,
					OrderDate = request.ContractData.OrderDate,
					FormerSupplierFirstName = request.ContractData.FormerSupplierFirstName,
					FormerSupplierLastName = request.ContractData.FormerSupplierLastName,
					FormerSupplierContractTerminated = request.ContractData.FormerSupplierContractTerminated,
					FormerSupplierContractTerminationDate = request.ContractData.FormerSupplierContractTerminationDate,

					// Contract Master Data ::
					CreatedDateTime = DateTime.Now,
					LastModifiedDateTime = DateTime.Now,
					Status = ContractMasterDataStatus.Wait,
					UserId = request.ContractMasterData.UserId,
					ExternalUserId = request.ContractMasterData.ExternalUserId,
					ExternalContractId = request.ContractMasterData.ExternalContractId,
					ContractDataId = request.ContractMasterData.ContractDataId,
				});
				_context.Database.ExecuteStoredProcedure<ContractBankAddressEntityUDT>(procedure);
				transaction.Commit();
				int ContractMasterDataID = procedure.LastCreatedIdentity;
				return ContractMasterDataID;
			}
            catch (Exception exception)
            {
                Console.WriteLine(exception.ToString());
                // TODO: JW: Minor: rolling back is obsolete (since the transaction is used with a using, it will call Rollback on Dispose if not committed).
                transaction.Rollback();
                throw;
            }
        }

        public void RemoveBankInformation(int masterId)
        {
			try { 
			var masterData = _context.ContractMasterData.FromSql(@"SELECT * FROM [ContractMasterDataView] WHERE id = {0} ", Convert.ToInt64(masterId)).First();
			var contractData = _context.ContractData.FromSql(@"SELECT * FROM [ContractDataView] WHERE id = {0}", Convert.ToInt64(masterData.ContractDataId)).First();
			var bankData = _context.ContractBankData.FromSql("SELECT * FROM [ContractBankDataView] WHERE id = {0} ", Convert.ToInt64(contractData.BankDataId)).First();

			var procedure = new RemoveContractBankData();
			procedure.ParamBankDataUDT = new List<ContractBankDataUDT>();

			procedure.ParamBankDataUDT.Add(new ContractBankDataUDT
			{
				Id = Convert.ToInt32(bankData.Id),
				FirstName = bankData.FirstName,
				LastName = bankData.LastName,
				Iban = bankData.Iban,
				PaymentMethod = bankData.PaymentMethod,
				SepaDateUtc = bankData.SepaDateUtc,
				SepaReference = bankData.SepaReference
			});
			_context.Database.ExecuteStoredProcedure<ContractBankDataUDT>(procedure);
			} catch (Exception e)
			{ 
			}
		}

		public void UpdateStatus(int masterId, string status)
        {
			try
            {

			var result = _context.ContractMasterData.FromSql(@"SELECT * FROM [ContractMasterDataView] WHERE id = {0}", masterId).FirstOrDefault();
			var procedure = new UpdateStatus();
			procedure.ParamMasterDataUDT = new List<ContractMasterDataUDT>();

			procedure.ParamMasterDataUDT.Add(new ContractMasterDataUDT
			{
				Id = result.Id,
				CreatedDateTime = result.CreatedDateTime,
				LastModifiedDateTime = DateTime.Now,
				Status = status,
				UserId = result.UserId,
				ExternalUserId = result.ExternalUserId,
				ExternalContractId = result.ExternalContractId,
				ContractDataId = result.ContractDataId
			});
			_context.Database.ExecuteStoredProcedure<ContractMasterDataUDT>(procedure);

			} catch (Exception e)
            {

            }
		}

		public void UpdateInternalUserId(int masterId, string userId)
        {
			try
			{
				var data = _context.ContractMasterData.FromSql(@"SELECT * FROM [ContractMasterDataView] WHERE id = {0}", masterId).FirstOrDefault();
				if (userId != null)
				{
					var procedure = new UpdateInternalData();
					procedure.ParamInternalMasterDataUDT = new List<ContractMasterDataUDT>();

					procedure.ParamInternalMasterDataUDT.Add(new ContractMasterDataUDT
					{
						Id = Convert.ToInt32(masterId),
						CreatedDateTime = data.CreatedDateTime,
						LastModifiedDateTime = data.LastModifiedDateTime,
						Status = data.Status,
						UserId = long.Parse(userId),
						ExternalUserId = data.ExternalUserId,
						ExternalContractId = data.ExternalContractId,
						ContractDataId = data.ContractDataId
					});
					_context.Database.ExecuteStoredProcedure<ContractMasterDataUDT>(procedure);

				}
			}
			catch (Exception e)
			{

			}

		}
		public void UpdateExternalData(int masterId, string externalUserId, string externalContractId)
        {
			try { 
			var data = _context.ContractMasterData.FromSql(@"SELECT * FROM [ContractMasterDataView] WHERE id = {0}", masterId).FirstOrDefault();
			if (externalUserId != null)
			{
				/**if (externalContractId != null)
				{*/
					var procedure = new UpdateExternalData();
					procedure.ParamExternalMasterDataUDT = new List<ContractMasterDataUDT>();

					procedure.ParamExternalMasterDataUDT.Add(new ContractMasterDataUDT
					{
						Id = Convert.ToInt32(masterId),
						CreatedDateTime = data.CreatedDateTime,
						LastModifiedDateTime = data.LastModifiedDateTime,
						Status = data.Status,
						UserId = data.UserId,
						ExternalUserId = externalUserId,
						ExternalContractId = externalContractId,
						ContractDataId = data.ContractDataId
					});
					_context.Database.ExecuteStoredProcedure<ContractMasterDataUDT>(procedure);
				//}
			}
			} catch (Exception e) { 

			}

		}

        public List<PreliminaryContractModel> GetNeedReSentContract(DateTime? contractAge)
        {
			string query = string.Empty;
			if (contractAge == null)
			{
				query = @"SELECT * FROM [PreliminaryContract]";
			}
			else
			{
				query = Format("SELECT * FROM [PreliminaryContract] where orderDate >= {0}", contractAge);
			}
			     
					var result = _context.ExecuteQuery<PreliminaryContract>(query).ToList();
					var preliminaryContractList = new List<PreliminaryContractModel>();
			         foreach (var item in result)
					 {
			             preliminaryContractList.Add(new PreliminaryContractModel
			             {
			                 Master = new Domain.Entities.ContractMasterData
			                 {
			                     CreatedDateTime = item.createdDateTime,
			                     LastModifiedDateTime = item.lastModifiedDateTime,
			                     Status = item.status,
			                     UserId = item.userId,
			                     ExternalUserId = item.externalUserId,
			                     ExternalContractId = item.externalContractId,
			                     ContractDataId = item.contractDataId
	                         },
			                 Entity = new Domain.Entities.ContractEntity
					         {
			                     IsBusiness = Convert.ToBoolean(item.isBusiness),
			                     IsSmallBusiness = Convert.ToBoolean(item.isSmallBusiness),
			                     CompanyName = item.companyName,
			                     Salutation = item.salutation,
			                     Title = item.title,
			                     FirstName = item.firstName,
			                     LastName = item.lastName,
			                     Birthday = item.birthday,
			                     Telephone = item.telephone,
			                     Email = item.email,
			                     AccountingEmail = item.accountingEmail,
			                     Username = item.username,
			                     TaxNumber = item.taxNumber
                             },
			                 BillAddress = new Domain.Entities.ContractAddress
							 {
								 Street = item.street,
								 HouseNumber = item.houseNumber,
								 Zipcode = item.zipcode,
								 City = item.city,
								 Addition = item.addition
							 },
			                 DeliveryAddress = new Domain.Entities.ContractAddress
							 {
								 Street = item.daStreet,
								 HouseNumber = item.daHouseNumber,
								 Zipcode = item.daZipcode,
								 City = item.daCity,
								 Addition = item.daAddition
							 },
			                 Data = new Domain.Entities.ContractData
							 {
								 ContractEntityId = Convert.ToInt32(item.contractEntityId),
								 DeliveryAddressId = Convert.ToInt32(item.deliveryAddressId),
								 BillingAddressId = Convert.ToInt32(item.billingAddressId),
								 PreferredDeliveryStart = item.preferredDeliveryStart,
								 SubscriptionReason = item.subscriptionReason,
								 MeterId = item.meterId,
								 MeterRole = item.meterRole,
								 MeteringpointId = item.meteringpointId,
								 PreviousProvider = item.previousProvider,
								 AnnualConsumption = Convert.ToDouble(item.annualConsumption),
								 BankDataId = item.bankDataId,
								 TariffType = item.tariffType,
								 SaasCustomerId = item.saasCustomerId,
								 SaasContractId = item.saasContractId,
								 ThirdPartySalespartner = item.thirdPartySalespartner,
								 ConsumptionBeforeBatteryInstallation = item.consumptionBeforeBatteryInstallation,
								 OrderDate = item.orderDate,
								 FormerSupplierFirstName = item.formerSupplierFirstName,
								 FormerSupplierLastName = item.formerSupplierLastName,
								 FormerSupplierContractTerminated = item.formerSupplierContractTerminated,
								 FormerSupplierContractTerminationDate = item.formerSupplierContractTerminationDate,
							 },
			                 BankData = new Domain.Entities.ContractBankData
							 {
								 FirstName = item.firstName,
								 LastName = item.lastName,
								 Iban = item.iban,
								 PaymentMethod = item.paymentMethod,
								 SepaDateUtc = item.SepaDate,
								 SepaReference = item.sepaReference
							 }
			             });
			         }
			return preliminaryContractList;
        }
		
        public Sma.Sp.TariffService.Domain.Entities.ContractMasterData GetContractMasterData(int userId)
        {
			var result = _context.ContractMasterData.FromSql(@"SELECT * FROM [ContractMasterDataView] WHERE userId = {0} AND status = {1}", userId, ContractMasterDataStatus.Complete).LastOrDefault();
			return _mapper.Map<Sma.Sp.TariffService.Domain.Entities.ContractMasterData>(result);
        }

        public Sma.Sp.TariffService.Domain.Entities.ContractMasterData GetByEmail(string email)
        {
			var result = _context.ContractMasterData.FromSql("SELECT * FROM [GetByEmail] WHERE email = {0} AND status = {1}", email, ContractMasterDataStatus.Complete);
			return _mapper.Map<Sma.Sp.TariffService.Domain.Entities.ContractMasterData>(result.Any()
				? result.LastOrDefault()
				: null);
		}
	    
        public List<Sma.Sp.TariffService.Domain.Entities.ContractMasterData> GetIncompleteUsers()
        {
			var result = _context.ContractMasterData.FromSql(@"SELECT * FROM [ContractMasterDataView] WHERE userId is null AND status = {0}",  ContractMasterDataStatus.InComplete).ToList();
            return _mapper.Map<List<Sma.Sp.TariffService.Domain.Entities.ContractMasterData>>(result);
        }

        public List<Domain.Entities.ContractMasterData> GetByUserId(string userId)
        {
			var result = _context.ContractMasterData.FromSql(@"SELECT * FROM [ContractMasterDataView] WHERE userId = {0} AND (externalUserId is not null or externalUserId  = '')", Convert.ToInt64(userId)).ToList();
			return _mapper.Map<List<Sma.Sp.TariffService.Domain.Entities.ContractMasterData>>(result);
        }

        public bool IsValid(string meterId, string lastName, string street, string city, string house,
            string zipcode)
        {
            if (IsNullOrEmpty(house) || IsNullOrEmpty(city)) return false;
            try
            {
				var result = _context.ContractMasterData.FromSql(@"SELECT * FROM [IsValid] WHERE status = {0} AND meterId = {1} AND lastName = {2} AND street = {3} AND city = {4} AND houseNumber = {5} AND zipCode = {6}", ContractMasterDataStatus.Complete, meterId, lastName, street, city, house, zipcode);

                return result.Any();
            }
            catch (Exception ex)
            {
				throw;
            }
        }
    }
}